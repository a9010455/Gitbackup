﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DllUrRobot;

namespace frmUrRobotDemo
{
    public partial class frmUrRobotDemo : Form
    {
        private DllUrRobot.ClsUrRobotConfig g_ClsUrRobotConfig;
        private DllUrRobot.ClsUrRobotControl g_ClsUrRobotControl;
        private CommonBase.Logger.InfoManagerWinForm g_InfoManager;
        
        public frmUrRobotDemo()
        {
            InitializeComponent();
        }

        int kk = 0;

        private void btnTestJson_Click(object sender, EventArgs e)
        {

            ClsSendJson tmpClsSendJson = new ClsSendJson()
            {
                request_time = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                reponse_time = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                cnc_name = "AAS_AR"
            };

            ClsSendGroup tmpClsSendGroup = new ClsSendGroup(
                "Robot_TCP", 0, new double[6] { -840.96, -291.28, 381.12, 2.20, 2.21, 0.01 });
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            tmpClsSendGroup = new ClsSendGroup(
                "Robot_Angle", 0, new double[6] { 8.88, -75.48, 100.95, -114.62, -89.65, 9.24 });
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            tmpClsSendGroup = new ClsSendGroup(
                "Robot_Current", 0, new double[6] { 0.02, -6.46, -5.48, -0.77, -0.03, 0.03 });
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            tmpClsSendGroup = new ClsSendGroup(
                "Robot_Voltage", 0, new double[6] { 47.94, 47.91, 47.88, 47.85, 47.99, 48.08 });
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            tmpClsSendGroup = new ClsSendGroup(
                "Robot_Temperature", 0, new double[6] { 24.47, 23.29, 25.08, 27.14, 29.18, 27.77 });
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            ////
            tmpClsSendGroup = new ClsSendGroup(
                "Axis_Position", 0, 10.5);
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            tmpClsSendGroup = new ClsSendGroup(
                "Axis_Status", 0, true);
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            tmpClsSendGroup = new ClsSendGroup(
                "Axis_PosLimit", 0, false);
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            tmpClsSendGroup = new ClsSendGroup(
                "Axis_NegLimit", 0, true);
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            ////
            tmpClsSendGroup = new ClsSendGroup(
                "2D_Offset", 0, new double[2] { 15.9, 17.8 });
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            tmpClsSendGroup = new ClsSendGroup(
                "2D_Rotate", 0, 0.52);
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            ////
            tmpClsSendGroup = new ClsSendGroup(
                "3D_Offset", 0, new double[2] { 1.59, 4.98 });
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            tmpClsSendGroup = new ClsSendGroup(
                "3D_Rotate", 0, -2.09);
            tmpClsSendJson.data_list.Add(tmpClsSendGroup);

            kk++;

            string ttJson = tmpClsSendJson.ToJsonString();

            System.IO.File.WriteAllText(".\\@tt.json", ttJson);

            DllUrRobot.ClsSendJson ttObject = tmpClsSendJson.ToObject(ttJson);

            this.g_InfoManager.HighLight(ttJson);

            //
            this.g_InfoManager.Error(DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"));

            ////
            //System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            //sw.Restart();
            //tt.SendWebapi("http://192.168.43.230:8081/User", 60000, 60000, ttJson);
            //sw.Stop();
            //this.g_InfoManager.Warning("cost time : " + sw.ElapsedMilliseconds + "(ms)");


            //ClsUrStatus tmpClsUrStatus = new ClsUrStatus();
            //int tcpPoseLength = tmpClsUrStatus.TcpPose.Length;
            //this.g_InfoManager.Warning("tcpPoseLength : " + tcpPoseLength);

        }

        private void frmUrRobotDemo_Load(object sender, EventArgs e)
        {
            this.Text = "UrRobotDemo";

            //
            this.g_InfoManager = new CommonBase.Logger.InfoManagerWinForm(
                ".\\Log\\ctrl\\systemlog",
                ".\\Log\\ctrl\\networklog",
                ".\\Log\\ctrl\\warninglog",
                ".\\Log\\ctrl\\errorlog",
                ".\\Log\\ctrl\\debuglog");

            this.g_InfoManager.SetGeneralTextBox(ref this.rtfCtrlSystem);

            //
            string urConfigPath = @".\UrBootConfig.xml";
            try
            {
                this.g_ClsUrRobotConfig = new DllUrRobot.ClsUrRobotConfig();
                if (System.IO.File.Exists(urConfigPath))
                {
                    this.g_ClsUrRobotConfig.ReadWithoutCrypto(urConfigPath);
                }
                this.g_ClsUrRobotConfig.WriteWithoutCrypto(urConfigPath, true);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + Environment.NewLine + "Create default xml : " + urConfigPath);
                this.g_ClsUrRobotConfig = new DllUrRobot.ClsUrRobotConfig();
                this.g_ClsUrRobotConfig.WriteWithoutCrypto(urConfigPath, true);
            }

            //
            this.g_ClsUrRobotControl = new DllUrRobot.ClsUrRobotControl(this.g_ClsUrRobotConfig);

            this.g_InfoManager.General("frmUrRobotDemo_Load");
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.Connect())
                {
                    this.btnConnect.Enabled = false;

                    this.btnDisconnect.Enabled = true;
                    this.btnPowerOn.Enabled = true;

                    this.timer1.Start();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.Disconnect())
                {
                    this.btnConnect.Enabled = true;

                    this.btnDisconnect.Enabled = false;

                    this.btnPowerOn.Enabled = false;
                    this.btnPowerOff.Enabled = false;
                    this.btnReleaseBreake.Enabled = false;
                    this.btnStop.Enabled = false;

                    this.timer1.Stop();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnPowerOn_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.PowerOn())
                {
                    this.btnPowerOn.Enabled = false;

                    this.btnPowerOff.Enabled = true;
                    this.btnReleaseBreake.Enabled = true;

                    this.btnStop.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnPowerOff_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.PowerOff())
                {
                    this.btnPowerOff.Enabled = false;

                    this.btnPowerOn.Enabled = true;
                    this.btnReleaseBreake.Enabled = false;
                    this.btnStop.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnReleaseBreake_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.BrakeRelease())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.Stop())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void frmUrRobotDemo_FormClosed(object sender, FormClosedEventArgs e)
        {
            // log
            try
            {
                if (this.g_InfoManager != null)
                {
                    this.g_InfoManager.Dispose();
                    this.g_InfoManager = null;
                }
            }
            catch (Exception ex) 
		    {
                Console.WriteLine(ex.ToString());
            }
        }

        private void btnGetRobotPosition_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.IsConnected())
                {
                    this.nudTCPX.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[0]);
                    this.nudTCPY.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[1]);
                    this.nudTCPZ.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[2]);
                    this.nudTCPrX.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[3]);
                    this.nudTCPrY.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[4]);
                    this.nudTCPrZ.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[5]);
                }
                else
                {
                    MessageBox.Show("Please Connect Robot first!", "Warning");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void btnMoveTcpTest_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.IsConnected())
                {
                    double x = (double)this.nudTCPX.Value;
                    double y = (double)this.nudTCPY.Value;
                    double z = (double)this.nudTCPZ.Value;
                    double rx = (double)this.nudTCPrX.Value;
                    double ry = (double)this.nudTCPrY.Value;
                    double rz = (double)this.nudTCPrZ.Value;

                    double tmpAcc = Convert.ToDouble(this.txtAcc.Text);
                    double tmpSpeed = Convert.ToDouble(this.txtSpeed.Text);
                    double tmpTime = 0;
                    double tmpBlendRadius = 0;

                    this.g_ClsUrRobotControl.MoveL_rv(
                        x, y, z, rx, ry, rz, tmpAcc, tmpSpeed, tmpTime, tmpBlendRadius);
                }
                else
                {
                    MessageBox.Show("Please Connect Robot first!", "Warning");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void btnGetMotorAngle_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.IsConnected())
                {
                    this.nudAngleX.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[0]);
                    this.nudAngleY.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[1]);
                    this.nudAngleZ.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[2]);
                    this.nudAnglerX.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[3]);
                    this.nudAnglerY.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[4]);
                    this.nudAnglerZ.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[5]);
                }
                else
                {
                    MessageBox.Show("Please Connect Robot first!", "Warning");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

        }

        private void btnMoveAngleTest_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.IsConnected())
                {
                    double x = (double)this.nudAngleX.Value;
                    double y = (double)this.nudAngleY.Value;
                    double z = (double)this.nudAngleZ.Value;
                    double rx = (double)this.nudAnglerX.Value;
                    double ry = (double)this.nudAnglerY.Value;
                    double rz = (double)this.nudAnglerZ.Value;

                    double tmpAcc = Convert.ToDouble(this.txtAcc.Text);
                    double tmpSpeed = Convert.ToDouble(this.txtSpeed.Text);
                    double tmpBlendRadius = 0;

                    this.g_ClsUrRobotControl.MoveJ(
                        x, y, z, rx, ry, rz, tmpAcc, tmpSpeed, tmpBlendRadius);
                }
                else
                {
                    MessageBox.Show("Please Connect Robot first!", "Warning");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        bool g_mouseClick = false;
        private void threadMouseClick()
        {
            
        }

        private void btnTcpXYZ_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void btnTcpXYZ_MouseUp(object sender, MouseEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                double[] tmpDouble = new double[6];
                for (int i = 0; i < tmpDouble.Length; i++)
                {
                    tmpDouble[i] = this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[i];
                }
                this.lblRpTcp.Text = string.Format("{0}mm\r\n\r\n{1}mm\r\n\r\n{2}mm\r\n\r\n{3}rad\r\n\r\n{4}rad\r\n\r\n{5}rad",
                     tmpDouble[0].ToString("#0.00"),
                     tmpDouble[1].ToString("#0.00"),
                     tmpDouble[2].ToString("#0.00"),
                     tmpDouble[3].ToString("#0.00"),
                     tmpDouble[4].ToString("#0.00"),
                     tmpDouble[5].ToString("#0.00"));

                //
                for (int i = 0; i < tmpDouble.Length; i++)
                {
                    tmpDouble[i] = this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[i];
                }
                this.lblRpAngle.Text = string.Format("{0}°\r\n\r\n{1}°\r\n\r\n{2}°\r\n\r\n{3}°\r\n\r\n{4}°\r\n\r\n{5}°",
                     tmpDouble[0].ToString("#0.00"),
                     tmpDouble[1].ToString("#0.00"),
                     tmpDouble[2].ToString("#0.00"),
                     tmpDouble[3].ToString("#0.00"),
                     tmpDouble[4].ToString("#0.00"),
                     tmpDouble[5].ToString("#0.00"));
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void chkDO0_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkDO1_CheckedChanged(object sender, EventArgs e)
        {

        }

        //



    }
}

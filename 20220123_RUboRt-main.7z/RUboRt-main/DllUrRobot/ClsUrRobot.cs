﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using Newtonsoft.Json;
using System.Net;
using System.IO;

using System.Net.Security;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;

namespace DllUrRobot
{
    public class ClsSendGroup
    {
        public string path { get; set; }
        public int error_code { get; set; }
        public object value { get; set; }

        public ClsSendGroup()
        {
            this.path = "";
            this.error_code = 0;
        }

        public ClsSendGroup(string o_path, int o_error_code, double o_value)
        {
            this.path = o_path;
            this.error_code = o_error_code;
            this.value = o_value;
        }

        public ClsSendGroup(string o_path, int o_error_code, double[] o_value)
        {
            this.path = o_path;
            this.error_code = o_error_code;
            this.value = new double[o_value.Length];

            for (int i = 0; i < o_value.Length; i++)
            {
                var d = (double[])value;
                d[i] = o_value[i];
            }
        }

        public ClsSendGroup(string o_path, int o_error_code, int o_value)
        {
            this.path = o_path;
            this.error_code = o_error_code;
            this.value = o_value;
        }

        public ClsSendGroup(string o_path, int o_error_code, bool o_value)
        {
            this.path = o_path;
            this.error_code = o_error_code;
            this.value = o_value;
        }

        public ClsSendGroup(string o_path, int o_error_code, string o_value)
        {
            this.path = o_path;
            this.error_code = o_error_code;
            this.value = o_value;
        }
    }

    public class ClsSendJson
    {
        public string request_time { get; set; }
        public string reponse_time { get; set; }
        public string cnc_name { get; set; }
        public List<ClsSendGroup> data_list { get; set; }

        public ClsSendJson()
        {
            this.request_time = "";
            this.reponse_time = "";
            this.cnc_name = "";
            this.data_list = new List<ClsSendGroup>();
        }

        public string ToJsonString()
        {
            //return JsonConvert.SerializeObject(this, Newtonsoft.Json.Formatting.Indented);
            return JsonConvert.SerializeObject(this, Newtonsoft.Json.Formatting.None);

        }

        public ClsSendJson ToObject(string o_strJson)
        {
            return JsonConvert.DeserializeObject<ClsSendJson>(o_strJson);
        }

        public void SendWebapi(
            string o_ipAddress,
            int connectTimeout,
            int readWtiteTimeout,
            string o_strJson)
        {
            // Close safty check        
            ServicePointManager.ServerCertificateValidationCallback =
                delegate { return true; };

            // Convert to Byte
            byte[] bs = System.Text.Encoding.UTF8.GetBytes(o_strJson);

            // HttpWebRequest
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(o_ipAddress);

            request.Method = "PUT";
            request.Timeout = connectTimeout;
            request.ReadWriteTimeout = readWtiteTimeout;
            request.ContentType = "application/json";
            request.ContentLength = bs.Length;
            //request.Headers.Set("authorization", "token {apitoken}");

            try
            {
                Stream requestStream = request.GetRequestStream();
                requestStream.Write(bs, 0, bs.Length);
                //requestStream.Close();
                requestStream.Flush();
            }
            catch (Exception ex)
            {
                Console.WriteLine("request" + ex.ToString());
            }

            String responseStr = "";
            try
            {
                WebResponse response = request.GetResponse();

                StreamReader reader = new StreamReader(response.GetResponseStream(), System.Text.Encoding.UTF8);

                responseStr = reader.ReadToEnd();

                Console.WriteLine("responseStr :" + responseStr);

                response.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("[response]" + ex.ToString());
            }
        }
    }

    public class ClsUrStatus
    {
        // Ur Robot
        public double[] TcpPose; // m
        public double[] MotorAngle;
        public double[] MotorCurrent;
        public double[] MotorVoltage;
        public double[] MotorTemperature;
        public int[] MotorDigtalOutput;

        // Axis
        public double AxisPosition;
        public bool AxisStatus;
        public bool AxisPosLimit;
        public bool AxisNegLimit;

        // 2D
        public double[] TwoDOffset;
        public double TwoDRotate;

        // 3D
        public double[] ThreeDOffset;
        public double ThreeDRotate;

        public ClsUrStatus()
        {
            //
            this.TcpPose = new double[6] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
            this.MotorAngle = new double[6] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
            this.MotorCurrent = new double[6] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
            this.MotorVoltage = new double[6] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
            this.MotorTemperature = new double[6] { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
            this.MotorDigtalOutput = new int[8] { 0, 0, 0, 0, 0, 0, 0, 0};

            //
            this.AxisPosition = 0.0;
            this.AxisStatus = true;
            this.AxisPosLimit = false;
            this.AxisNegLimit = false;

            //
            this.TwoDOffset = new double[2] { 0.0, 0.0 };
            this.TwoDRotate = 0.0;

            //
            this.ThreeDOffset = new double[2] { 0.0, 0.0 };
            this.ThreeDRotate = 0.0;
        }
    }

    public class ClsUrRobotConfig : CommonBase.Config.BaseConfig<ClsUrRobotConfig>
    {
        private string classVersion = "ClsUrRobotConfig_202201191304";

        public string IpAddress; // robot ip
        public int CheckMoveStatusTimeOut; // ms

        // upload to webapi
        public bool IsEnablePostToWebapi;
        public string WebapiServerPath; // URL
        public int WebapiConnectTimeout; // ms
        public int WebapiReadWriteTmeout; // ms
        public int SendWebapiDeleyTime; // ms

        public ClsUrRobotConfig()
        {
            this.IpAddress = "192.168.1.2";
            this.CheckMoveStatusTimeOut = 60000;

            this.IsEnablePostToWebapi = true;
            this.WebapiServerPath = "http://192.168.43.230:8081/User";
            this.WebapiConnectTimeout = 60000;
            this.WebapiReadWriteTmeout = 60000;
            this.SendWebapiDeleyTime = 10;
        }

        protected override bool CheckValue(ClsUrRobotConfig tmpConfig)
        {
            //
            this.IpAddress = tmpConfig.IpAddress;

            this.CheckMoveStatusTimeOut = tmpConfig.CheckMoveStatusTimeOut;

            //
            this.IsEnablePostToWebapi = tmpConfig.IsEnablePostToWebapi;
            this.WebapiServerPath = tmpConfig.WebapiServerPath;
            this.WebapiConnectTimeout = tmpConfig.WebapiConnectTimeout;
            this.WebapiReadWriteTmeout = tmpConfig.WebapiReadWriteTmeout;
            this.SendWebapiDeleyTime = tmpConfig.SendWebapiDeleyTime;

            // Read Name
            this.Name = tmpConfig.Name;

            // Read UPDATE
            this.Update = tmpConfig.Update;

            // Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;
        }
    }

    public class ClsUrRobotControl
    {
        private Socket socket29999;
        private Socket socket30003;

        private byte[] dataByte29999;
        private byte[] dataByte30003;

        public ClsUrStatus m_ClsUrStatus;

        private Task getRobotParams;
        private bool getActRobotParams;

        private Task sendWebapiParams;
        private bool sendActWebapiParams;

        //
        private bool isMoveing;
        private bool isStopClick;
        private bool isRobotConnected;

        private ClsUrRobotConfig m_ClsUrRobotConfig;

        public ClsUrRobotControl(ClsUrRobotConfig o_ClsUrRobotConfig)
        {
            this.socket29999 = null;
            this.socket30003 = null;

            this.dataByte29999 = new byte[1024];
            this.dataByte30003 = new byte[2048];

            this.m_ClsUrStatus = new ClsUrStatus();

            this.getActRobotParams = false;
            this.getRobotParams = null;

            this.sendActWebapiParams = false;
            this.sendWebapiParams = null;

            this.isMoveing = false;
            this.isStopClick = false;

            //
            this.m_ClsUrRobotConfig = o_ClsUrRobotConfig;
        }

        private void _taskGetRobotParams()
        {           
            while (this.getActRobotParams)
            {
                try
                {
                    if (this.socket30003 != null)
                    {
                        int dataLength = this.socket30003.Receive(this.dataByte30003);

                        //if (dataLength == 2048)
                        {

                            // TcpPose -> 444
                            for (int i = 0; i < this.m_ClsUrStatus.TcpPose.Length; i++)
                            {
                                // mm
                                if (i == 0 || i == 1 || i == 2)
                                {
                                    this.m_ClsUrStatus.TcpPose[i] =
                                        this._bytesToDouble(this.dataByte30003, 444 + i * 8) * 1000;
                                }
                            }

                            // MotorAngle -> 252
                            for (int i = 0; i < this.m_ClsUrStatus.MotorAngle.Length; i++)
                            {
                                this.m_ClsUrStatus.MotorAngle[i] =
                                    this._bytesToDouble(this.dataByte30003, 252 + i * 8) * 180 / Math.PI;
                            }

                            // MotorCurrent -> 348
                            for (int i = 0; i < this.m_ClsUrStatus.MotorCurrent.Length; i++)
                            {
                                this.m_ClsUrStatus.MotorCurrent[i] =
                                    this._bytesToDouble(this.dataByte30003, 348 + i * 8);
                            }

                            // MotorVoltage -> 996
                            for (int i = 0; i < this.m_ClsUrStatus.MotorVoltage.Length; i++)
                            {
                                this.m_ClsUrStatus.MotorVoltage[i] =
                                    this._bytesToDouble(this.dataByte30003, 996 + i * 8);
                            }

                            // MotorTemperature -> 692
                            for (int i = 0; i < this.m_ClsUrStatus.MotorTemperature.Length; i++)
                            {
                                this.m_ClsUrStatus.MotorTemperature[i] =
                                    this._bytesToDouble(this.dataByte30003, 692 + i * 8);
                            }                            
                        }
                    }
                    else
                    {
                        break;
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
            }

            //
            this._disconnect30003();
        }

        private void _taskSendWebapi()
        {
            while (this.sendActWebapiParams)
            {
                try
                {
                    ClsSendJson tmpClsSendJson = new ClsSendJson()
                    {
                        request_time = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                        reponse_time = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                        cnc_name = "AAS_AR"
                    };

                    ////
                    ClsSendGroup tmpClsSendGroup = new ClsSendGroup(
                        "Robot_TCP", 0, this.m_ClsUrStatus.TcpPose);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    tmpClsSendGroup = new ClsSendGroup(
                        "Robot_Angle", 0, this.m_ClsUrStatus.MotorAngle);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    tmpClsSendGroup = new ClsSendGroup(
                        "Robot_Current", 0, this.m_ClsUrStatus.MotorCurrent);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);
 
                    tmpClsSendGroup = new ClsSendGroup(
                        "Robot_Voltage", 0, this.m_ClsUrStatus.MotorVoltage);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);
        
                    tmpClsSendGroup = new ClsSendGroup(
                        "Robot_Temperature", 0, this.m_ClsUrStatus.MotorTemperature);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    ////
                    tmpClsSendGroup = new ClsSendGroup(
                        "Axis_Position", 0, this.m_ClsUrStatus.AxisPosition);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    tmpClsSendGroup = new ClsSendGroup(
                        "Axis_Status", 0, this.m_ClsUrStatus.AxisStatus);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    tmpClsSendGroup = new ClsSendGroup(
                        "Axis_PosLimit", 0, this.m_ClsUrStatus.AxisPosLimit);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    tmpClsSendGroup = new ClsSendGroup(
                        "Axis_NegLimit", 0, this.m_ClsUrStatus.AxisNegLimit);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    ////
                    tmpClsSendGroup = new ClsSendGroup(
                        "2D_Offset", 0, this.m_ClsUrStatus.TwoDOffset);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    tmpClsSendGroup = new ClsSendGroup(
                        "2D_Rotate", 0, this.m_ClsUrStatus.TwoDRotate);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    ////
                    tmpClsSendGroup = new ClsSendGroup(
                        "3D_Offset", 0, this.m_ClsUrStatus.ThreeDOffset);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    tmpClsSendGroup = new ClsSendGroup(
                        "3D_Rotate", 0, this.m_ClsUrStatus.ThreeDRotate);
                    tmpClsSendJson.data_list.Add(tmpClsSendGroup);

                    //
                    System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                    sw.Restart();

                    tmpClsSendJson.SendWebapi(
                        this.m_ClsUrRobotConfig.WebapiServerPath,
                        this.m_ClsUrRobotConfig.WebapiConnectTimeout,
                        this.m_ClsUrRobotConfig.WebapiReadWriteTmeout,
                        tmpClsSendJson.ToJsonString());

                    sw.Stop();
                    Console.WriteLine("[Task send webapi] cost time : " + sw.ElapsedMilliseconds + "(ms)");

                    //
                    System.Threading.Thread.Sleep(this.m_ClsUrRobotConfig.SendWebapiDeleyTime);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                } 
            }
        }

        private int _startSendWebapi()
        {
            int iRet = 0;

            if (this.m_ClsUrRobotConfig.IsEnablePostToWebapi)
            {
                try
                {
                    if (this.sendWebapiParams == null)
                    {
                        this.sendActWebapiParams = true;
                        this.sendWebapiParams = new Task(this._taskSendWebapi);
                        this.sendWebapiParams.Start();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    iRet = 1;
                }
            }
            else
            {
                Console.WriteLine("[IsEnablePostToWebapi] = " + this.m_ClsUrRobotConfig.IsEnablePostToWebapi);
            }

            return iRet;
        }

        private int _connect29999()
        {
            int iRet = 0;
            string msg = "";
            try
            {

                if (this.socket29999 == null)
                {
                    this.socket29999 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    this.socket29999.Connect(this.m_ClsUrRobotConfig.IpAddress, 29999);
                }

                if (this.socket29999.Connected)
                {
                    Console.WriteLine("29999 Success");

                    string instruct = "PolyscopeVersion" + Environment.NewLine;
                    this.socket29999.Send(Encoding.Default.GetBytes(instruct.ToArray()));

                    //this.socket29999.Send(Encoding.Default.GetBytes("PolyscopeVersion".ToCharArray()));
                    //this.socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));
                    
                    this.socket29999.Receive(this.dataByte29999);
                    msg = this._byteToString(this.dataByte29999);

                    Console.WriteLine("[_connect29999] : " + msg);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                iRet = 1;
            }
            return iRet;
        }

        private int _connect30003()
        {
            int iRet = 1;
            try
            {
                if (this.socket30003 == null)
                {
                    this.socket30003 = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    this.socket30003.Connect(this.m_ClsUrRobotConfig.IpAddress, 30003);
                }

                if (this.socket30003.Connected)
                {
                    Console.WriteLine("30003 Success");

                    iRet = 0;
                    if (this.getRobotParams == null)
                    {
                        this.getActRobotParams = true;
                        this.getRobotParams = new Task(this._taskGetRobotParams);
                        this.getRobotParams.Start();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                iRet = 1;
            }
            return iRet;
        }

        private int _disconnect29999()
        {
            int iRet = 0;
            string msg = "";
            try
            {
                if (this.socket29999 != null)
                {
                    if (this.socket29999.Connected)
                    {
                        string instruct = "quit" + Environment.NewLine;
                        this.socket29999.Send(Encoding.Default.GetBytes(instruct.ToArray()));

                        //this.socket29999.Send(Encoding.Default.GetBytes("quit".ToCharArray()));
                        //this.socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));

                        this.socket29999.Receive(this.dataByte29999);
                        msg = this._byteToString(this.dataByte29999);

                        Console.WriteLine("[_disconnect29999] : " + msg);

                        this.socket29999.Disconnect(true);
                        this.socket29999.Dispose();
                        this.socket29999 = null;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                iRet = 1;
            }
            return iRet;
        }

        private int _disconnect30003()
        {
            int iRet = 0;
            try
            {
                if (this.socket30003 != null)
                {
                    if (this.socket30003.Connected)
                    {
                        this.socket30003.Dispose();
                        this.socket30003 = null;

                        this.getRobotParams.Dispose();
                        this.getRobotParams = null;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                iRet = 1;
            }
            return iRet;
        }

        private double _bytesToDouble(byte[] dataBytes, int startIndex)
        {
            int byteLength = 8;
            byte tVal;
            byte[] tmpByte = new byte[byteLength];
            for (int i = 0; i < byteLength - 1; i++)
            {
                tVal = dataBytes[startIndex + i];
                tmpByte[byteLength - 1 - i] = tVal;
            }

            double rtn = BitConverter.ToDouble(tmpByte, 0);
            return rtn;
        }

        private string _byteToString(byte[] dataByte)
        {
            string tmpString = "";
            try
            {
                int count = 0;
                foreach (var str in dataByte)
                {
                    if (str != 10)
                    {
                        count++;
                    }
                    else
                        break;
                }
                tmpString = new ASCIIEncoding().GetString(dataByte, 0, count);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return tmpString;
        }

        private double _degreeToRadians(double degree)
        {
            return (degree * Math.PI / 180.0);
        }

        private void _rotationVectorToRollPitchYaw(
            double rx, double ry, double rz,
            ref double roll, ref double pitch, ref double yaw)
        {
            double theta = Math.Sqrt(rx * rx + ry * ry + rz * rz);
            double kx = rx / theta;
            double ky = ry / theta;
            double kz = rz / theta;
            double cth = Math.Cos(theta);
            double sth = Math.Sin(theta);
            double vth = 1 - Math.Cos(theta);

            double r11 = kx * kx * vth + cth;
            double r12 = kx * ky * vth - kz * sth;
            double r13 = kx * kz * vth + ky * sth;
            double r21 = kx * ky * vth + kz * sth;
            double r22 = ky * ky * vth + cth;
            double r23 = ky * kz * vth - kx * sth;
            double r31 = kx * kz * vth - ky * sth;
            double r32 = ky * kz * vth + kx * sth;
            double r33 = kz * kz * vth + cth;

            double beta = Math.Atan2(-r31, Math.Sqrt(r11 * r11 + r21 * r21));

            double alpha, gamma;

            if (beta > this._degreeToRadians(89.99))
            {
                beta = this._degreeToRadians(89.99);
                alpha = 0;
                gamma = Math.Atan2(r12, r22);
            }
            else if (beta < -this._degreeToRadians(89.99))
            {
                beta = -this._degreeToRadians(89.99);
                alpha = 0;
                gamma = -Math.Atan2(r12, r22);
            }
            else
            {
                double cb = Math.Cos(beta);
                alpha = Math.Atan2(r21 / cb, r11 / cb);
                gamma = Math.Atan2(r32 / cb, r33 / cb);
            }

            roll = gamma;
            pitch = beta;
            yaw = alpha;
            return;
        }

        private void _rollPitchYawToRorationVector(double roll, double pitch, double yaw,
            ref double rx, ref double ry, ref double rz)
        {
            double alpha = yaw;
            double beta = pitch;
            double gamma = roll;


            double ca = Math.Cos(alpha);
            double cb = Math.Cos(beta);
            double cg = Math.Cos(gamma);
            double sa = Math.Sin(alpha);
            double sb = Math.Sin(beta);
            double sg = Math.Sin(gamma);


            double r11 = ca * cb;
            double r12 = ca * sb * sg - sa * cg;
            double r13 = ca * sb * cg + sa * sg;
            double r21 = sa * cb;
            double r22 = sa * sb * sg + ca * cg;
            double r23 = sa * sb * cg - ca * sg;
            double r31 = -sb;
            double r32 = cb * sg;
            double r33 = cb * cg;


            double theta = Math.Acos((r11 + r22 + r33 - 1) / 2);
            double sth = Math.Sin(theta);
            double kx = (r32 - r23) / (2 * sth);
            double ky = (r13 - r31) / (2 * sth);
            double kz = (r21 - r12) / (2 * sth);

            rx = theta * kx;
            ry = theta * ky;
            rz = theta * kz;
        }

        private void _isRobotMoveTcpOk(double x, double y, double z, 
            double rx, double ry, double rz,
            int timeout)
        {
            try
            {
                System.Diagnostics.Stopwatch tmpStopwatch = new System.Diagnostics.Stopwatch();
                tmpStopwatch.Restart();

                while (true)
                {
                    if (this.isStopClick)
                    {
                        this.isStopClick = false;
                        break;
                    }

                    if (tmpStopwatch.ElapsedMilliseconds > timeout)
                    {
                        Console.WriteLine("[_isRobotMoveTcpOk] timeout : " + timeout);
                        break;
                    }
                  
                    if (Math.Abs(this.m_ClsUrStatus.TcpPose[0] - x) < 5 &&
                        Math.Abs(this.m_ClsUrStatus.TcpPose[1] - y) < 5 &&
                        Math.Abs(this.m_ClsUrStatus.TcpPose[2] - z) < 5 &&

                        Math.Abs(this.m_ClsUrStatus.TcpPose[3] - rx) < 1 &&
                        Math.Abs(this.m_ClsUrStatus.TcpPose[4] - ry) < 1 &&
                        Math.Abs(this.m_ClsUrStatus.TcpPose[5] - rz) < 1)
                    {
                        break;
                    }
                    System.Threading.Thread.Sleep(10);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        private void _isRobotMoveAngleOk(
            double baseAngle, double shoulderAngle, double elbowAngle,
            double wrist1Angle, double wrist2Angle, double wrist3Angle,
            int timeout)
        {
            try
            {
                System.Diagnostics.Stopwatch tmpStopwatch = new System.Diagnostics.Stopwatch();
                tmpStopwatch.Restart();

                while (true)
                {
                    if (this.isStopClick)
                    {
                        this.isStopClick = false;
                        break;
                    }

                    if (tmpStopwatch.ElapsedMilliseconds > timeout)
                    {
                        Console.WriteLine("[_isRobotMoveAngleOk] timeout : " + timeout);
                        break;
                    }

                    if (Math.Abs(this.m_ClsUrStatus.MotorAngle[0] - baseAngle) < 1 &&
                        Math.Abs(this.m_ClsUrStatus.MotorAngle[1] - shoulderAngle) < 1 &&
                        Math.Abs(this.m_ClsUrStatus.MotorAngle[2] - elbowAngle) < 1 &&

                        Math.Abs(this.m_ClsUrStatus.MotorAngle[3] - wrist1Angle) < 1 &&
                        Math.Abs(this.m_ClsUrStatus.MotorAngle[4] - wrist2Angle) < 1 &&
                        Math.Abs(this.m_ClsUrStatus.MotorAngle[5] - wrist3Angle) < 1)
                    {
                        break;
                    }
                    System.Threading.Thread.Sleep(10);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        //
        public bool IsConnected()
        {
            return this.isRobotConnected;
        }

        public bool Connect()
        {
            int iRet = 0;

            try
            {
                // _connect30003
                iRet += this._connect30003();

                // _connect29999
                iRet += this._connect29999();

                // _startSendWebapi
                iRet += this._startSendWebapi();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                iRet = 1;
            }

            if (iRet == 0)
            {
                this.isRobotConnected = true;
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Disconnect()
        {
            int iRet = 0;

            try
            {
                // _connect30003
                this.getActRobotParams = false;

                // _connect29999
                iRet += this._disconnect29999();

                //
                this.sendActWebapiParams = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                iRet = 1;
            }

            if (iRet == 0)
            {
                this.isRobotConnected = false;
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool PowerOn()
        {
            bool bRet = true;
            string msg = "";
            try
            {
                if (this.socket29999 != null)
                {
                    if (this.socket29999.Connected)
                    {
                        string instruct = "power on" + Environment.NewLine;
                        this.socket29999.Send(Encoding.Default.GetBytes(instruct.ToArray()));

                        //this.socket29999.Send(Encoding.Default.GetBytes("power on".ToCharArray()));
                        //this.socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));
                        
                        this.socket29999.Receive(this.dataByte29999);
                        msg = this._byteToString(this.dataByte29999);

                        Console.WriteLine("[PowerOn] : " + msg);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
            }
            return bRet;
        }

        public bool PowerOff()
        {
            bool bRet = true;
            string msg = "";
            try
            {
                if (this.socket29999 != null)
                {
                    if (this.socket29999.Connected)
                    {
                        string instruct = "power off" + Environment.NewLine;
                        this.socket29999.Send(Encoding.Default.GetBytes(instruct.ToArray()));

                        //this.socket29999.Send(Encoding.Default.GetBytes("power off".ToCharArray()));
                        //this.socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));

                        this.socket29999.Receive(this.dataByte29999);
                        msg = this._byteToString(this.dataByte29999);

                        Console.WriteLine("[PowerOff] : " + msg);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
            }
            return bRet;
        }

        public bool BrakeRelease()
        {
            bool bRet = true;
            string msg = "";
            try
            {
                if (this.socket29999 != null)
                {
                    if (this.socket29999.Connected)
                    {
                        string instruct = "brake release" + Environment.NewLine;
                        this.socket29999.Send(Encoding.Default.GetBytes(instruct.ToArray()));

                        //this.socket29999.Send(Encoding.Default.GetBytes("brake release".ToCharArray()));
                        //this.socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));

                        this.socket29999.Receive(this.dataByte29999);
                        msg = this._byteToString(this.dataByte29999);

                        Console.WriteLine("[BrakeRelease] : " + msg);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
            }
            return bRet;
        }

        /// <summary>
        /// this is ur robot to moveL function,
        /// x, y, z : mm
        /// row, pitch, yaw : degree
        /// acclerate : rad/(s^2). velocity : rad/s
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        /// <param name="row"></param>
        /// <param name="pitch"></param>
        /// <param name="yaw"></param>
        /// <param name="acclerate"></param>
        /// <param name="velocity"></param>
        /// <param name="time"></param>
        /// <param name="blendradius"></param>
        /// <returns></returns>
        public bool MoveL(
            double x, double y, double z, double row, double pitch, double yaw,
            double acclerate = 0.3, double velocity = 0.1, double time = 0.0, double blendradius = 0.0)
        {
            bool bRet = true;

            try
            {

                // rpy to rv
                double rx = 0.0;
                double ry = 0.0;
                double rz = 0.0;
                this._rollPitchYawToRorationVector(row, pitch, yaw, ref rx, ref ry, ref rz);

                // mm to m
                double mX = x / 1000.0;
                double mY = y / 1000.0;
                double mZ = z / 1000.0; 

                // 
                string instruct = String.Format("movel(p[{0}, {1}, {2}, {3}, {4}, {5}], a = {6}, v = {7}, t = {8}, r = {9})" + Environment.NewLine,
                    mX, mY, mZ, rx, ry, rz, acclerate, velocity, time, blendradius);

                if (this.socket30003 != null)
                {
                    if (this.socket30003.Connected)
                    {
                        this.socket30003.Send(Encoding.Default.GetBytes(instruct.ToArray()));

                        this.isMoveing = true;

                        this._isRobotMoveTcpOk(x, y, z, rx, ry, rz, this.m_ClsUrRobotConfig.CheckMoveStatusTimeOut);

                        this.isMoveing = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
                this.isMoveing = false;
            }

            return bRet;
        }

        public bool MoveL_rv(
            double x, double y, double z, double rX, double rY, double rZ,
            double acclerate = 0.3, double velocity = 0.1, double time = 0.0, double blendradius = 0.0)
        {
            bool bRet = true;

            try
            {
                // mm to m
                double mX = x / 1000.0;
                double mY = y / 1000.0;
                double mZ = z / 1000.0;

                //
                string instruct = String.Format("movel(p[{0}, {1}, {2}, {3}, {4}, {5}], a = {6}, v = {7}, t = {8}, r = {9})" + Environment.NewLine,
                    mX, mY, mZ, rX, rY, rZ, acclerate, velocity, time, blendradius);

                if (this.socket30003 != null)
                {
                    if (this.socket30003.Connected)
                    {
                        this.socket30003.Send(Encoding.Default.GetBytes(instruct.ToArray()));

                        this.isMoveing = true;

                        this._isRobotMoveTcpOk(
                            x, y, z,
                            rX, rY, rZ,
                            this.m_ClsUrRobotConfig.CheckMoveStatusTimeOut);

                        this.isMoveing = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
                this.isMoveing = false;
            }

            return bRet;
        }

        public bool MoveJ(
            double baseAngle, double shoulderAngle, double elbowAngle,
            double wrist1Angle, double wrist2Angle, double wrist3Angle,
            double acclerate = 0.3, double velocity = 0.1, double blendradius = 0.0)
        {
            bool bRet = true;

            try
            {
                //
                string instruct = String.Format("movej(p[{0}, {1}, {2}, {3}, {4}, {5}], a = {6}, v = {7}, r = {8})" + Environment.NewLine,
                    baseAngle, shoulderAngle, elbowAngle, wrist1Angle, wrist2Angle, wrist3Angle, acclerate, velocity, blendradius);

                if (this.socket30003 != null)
                {
                    if (this.socket30003.Connected)
                    {
                        this.socket30003.Send(Encoding.Default.GetBytes(instruct.ToArray()));

                        this.isMoveing = true;

                        this._isRobotMoveAngleOk(
                            baseAngle, shoulderAngle, elbowAngle,
                            wrist1Angle, wrist2Angle, wrist3Angle,
                            this.m_ClsUrRobotConfig.CheckMoveStatusTimeOut);

                        this.isMoveing = false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
            }

            return bRet;
        }

        public bool Stop()
        {
            bool bRet = true;
            string msg = "";
            try
            {
                if (this.socket29999 != null)
                {
                    string instruct = "stop" + Environment.NewLine;
                    this.socket29999.Send(Encoding.Default.GetBytes(instruct.ToArray()));

                    //this.socket29999.Send(Encoding.Default.GetBytes("stop".ToCharArray()));
                    //this.socket29999.Send(Encoding.Default.GetBytes("\n".ToCharArray()));

                    this.socket29999.Receive(this.dataByte29999);
                    msg = _byteToString(this.dataByte29999);

                    if (this.isMoveing)
                    {
                        this.isStopClick = true;
                    }
                    Console.WriteLine("[Stop] : " + msg);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
            }
            return bRet;
        }

        public bool SetDigitalOutput(int channel, bool onOff)
        {
            bool bRet = true;

            try
            {
                string instruct = string.Format("set_digital_out({0},{1})" + Environment.NewLine,
                    channel, onOff.ToString());

                this.socket30003.Send(Encoding.Default.GetBytes(instruct.ToArray()));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
            }
            return bRet;
        }

        public void RvToRpy(
            double rx, double ry, double rz,
            ref double roll, ref double pitch, ref double yaw)
        {
            this._rotationVectorToRollPitchYaw(rx, ry, rz, ref roll, ref pitch, ref yaw);
        }

        public bool SetAxisData(
            double o_position,
            bool o_status,
            bool o_posLimit,
            bool o_negLimit)
        {
            bool bRet = true;
            try
            {
                this.m_ClsUrStatus.AxisPosition = o_position;
                this.m_ClsUrStatus.AxisStatus = o_status;
                this.m_ClsUrStatus.AxisPosLimit = o_posLimit;
                this.m_ClsUrStatus.AxisNegLimit = o_negLimit;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
            }
            return bRet;
        }

        public bool SetTwoDData(double[] o_offset, double o_rotate)
        {
            bool bRet = true;
            try
            {
                if (o_offset.Length >= 2)
                {
                    this.m_ClsUrStatus.TwoDOffset[0] = o_offset[0];
                    this.m_ClsUrStatus.TwoDOffset[1] = o_offset[1];
                    this.m_ClsUrStatus.TwoDRotate = o_rotate;
                }
                else
                {
                    Console.WriteLine("[SetTwoDData] o_offset data less than 2");
                    bRet = false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
            }
            return bRet;
        }

        public bool SetThreeDData(double[] o_offset, double o_rotate)
        {
            bool bRet = true;
            try
            {
                if (o_offset.Length >= 2)
                {
                    this.m_ClsUrStatus.ThreeDOffset[0] = o_offset[0];
                    this.m_ClsUrStatus.ThreeDOffset[1] = o_offset[1];
                    this.m_ClsUrStatus.ThreeDRotate = o_rotate;
                }
                else
                {
                    Console.WriteLine("[SetThreeDData] o_offset data less than 2");
                    bRet = false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                bRet = false;
            }
            return bRet;
        }
    }
}

#pragma once

using namespace System;
using namespace System::IO;
using namespace System::ComponentModel;
using namespace System::Collections::Generic;
using namespace Newtonsoft::Json;
using namespace System::Security::Cryptography;

namespace AASDetector
{
	ref class ConfigObj
	{
	public:
		property String^ name;
		property int Size;
		property double exp;
		ConfigObj();
	};

	ref class ConfigObjList
	{
	public:
		property List<ConfigObj^>^ cameras;
		ConfigObjList();
		void add(ConfigObj^ obj);
	};


	public class ConfigConvert
	{
	public:
		
		generic <class T>
			static
				void Write(Object^ obj, String^ Filename);
		generic <class T>
			static
				void Write(Object^ obj, String^ Filename, bool encode);

		generic <class T>
			where T : gcnew()
			static
				T Read(String^ Filename);

		generic <class T>
			where T : gcnew()
			static
				T Read(String^ Filename, bool encode);

	private:

		static String^ DESEncrypt(String^ data, String^ key, String^ iv);

		static String^ DESDecrypt(String^ data, String^ key, String^ iv);
	};

}

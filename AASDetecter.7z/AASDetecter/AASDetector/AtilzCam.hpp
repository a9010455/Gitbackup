#pragma once
#include "mil.h"
#include <vector>

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Drawing::Imaging;
using namespace System::Collections::Generic;
using namespace System::Diagnostics;


ref class AtilzCam
{
	MIL_ID _milsys = M_NULL;
    MIL_ID _milContainer = M_NULL;
    MIL_ID _milDigitizer = M_NULL;

public:
    AtilzCam::AtilzCam(MIL_ID milsys)
	{
		_milsys = milsys;
	}
	bool AtilzCam::Initail()
	{
		bool state = false;
        MIL_ID Container;
        state = Alloc3dDisplayAndContainer(_milsys, Container);
        _milContainer = Container;
        _milDigitizer =  MdigAlloc(_milsys, M_DEFAULT, MIL_TEXT("M_DEFAULT"), M_DEFAULT, M_NULL);
        MdigControlFeature(_milDigitizer, M_FEATURE_VALUE, MIL_TEXT("UserSetSelector"), M_TYPE_STRING, MIL_TEXT("UserSet0"));


		return state;
	}
    MIL_ID AtilzCam::Capture()
    {
        MdigGrab(_milDigitizer, _milContainer);
        MIL_ID ComponentId = MbufInquireContainer(_milContainer, M_COMPONENT_RANGE, M_COMPONENT_ID, M_NULL);
        MIL_ID Depthmap = MbufClone(ComponentId, _milsys, M_DEFAULT,
            M_DEFAULT, M_DEFAULT, M_DEFAULT, M_DEFAULT, M_NULL);
        MbufCopy(ComponentId, Depthmap);
        MIL_INT band = MbufInquire(Depthmap, M_SIZE_BAND, M_NULL);
        MIL_INT Width = MbufInquire(Depthmap, M_SIZE_X, M_NULL);
        MIL_INT Height = MbufInquire(Depthmap, M_SIZE_Y, M_NULL);
        MIL_INT bit = MbufInquire(Depthmap, M_SIZE_BIT, M_NULL);
        return Depthmap;
    }
    AtilzCam::~AtilzCam()
    {
        if (_milContainer != M_NULL)
        {
            MbufFree(_milContainer);
            _milContainer = M_NULL;
        }
    }

    bool AtilzCam::Alloc3dDisplayAndContainer(MIL_ID MilSystem, MIL_ID &MilContainerDisp)
    {
        // First we check if the system is local
        if (MsysInquire(MilSystem, M_LOCATION, M_NULL) != M_LOCAL)
        {
            MosPrintf(MIL_TEXT("This example requires a 3D display which is not supported on a remote system.\n"));
            MosPrintf(MIL_TEXT("Please select a local system as the default.\n"));
            return false;
        }

        MappControl(M_DEFAULT, M_ERROR, M_PRINT_DISABLE);
        MilContainerDisp = MbufAllocContainer(MilSystem, M_PROC | M_GRAB | M_DISP, M_DEFAULT, M_NULL);
        if (MilContainerDisp == M_NULL)
        {
            MIL_STRING ErrorMessage;
            MIL_STRING ErrorMessageSub1;
            MappGetError(M_DEFAULT, M_GLOBAL + M_MESSAGE, ErrorMessage);
            MappGetError(M_DEFAULT, M_GLOBAL_SUB_1 + M_MESSAGE, ErrorMessageSub1);
            MosPrintf(MIL_TEXT("\nThe current system does not support the 3D display:\n"));
            MosPrintf(MIL_TEXT("   %s\n"), ErrorMessage.c_str());
            MosPrintf(MIL_TEXT("   %s\n"), ErrorMessageSub1.c_str());
            if (MilContainerDisp != M_NULL)
            {
                MbufFree(MilContainerDisp);
            }
            return false;
        }
        MappControl(M_DEFAULT, M_ERROR, M_PRINT_ENABLE);

        return true;
    }
};
#pragma once
#include "ConfigConvert.h"
#include "BootConfig.hpp"
#include "Loger.hpp"
#include "mil.h"

using namespace System;
using namespace System::IO;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Drawing::Imaging;
using namespace System::Collections::Generic;
using namespace System::Diagnostics;
using namespace AASDetector;

namespace AASDetector
{
	ref class SystemObj
	{

	public:
		BootConfig^ bootConfig = gcnew BootConfig();
		AOIConfig^ aoiConfig = gcnew AOIConfig();
		Loger^ sysLoger = gcnew Loger();
		MIL_ID MilApplication = M_NULL;
		MIL_ID MilSystem = M_NULL;

	public:

		SystemObj(void)
		{

		}

		bool AllocateSystem()
		{
			try
			{
				String^ workPath = System::Windows::Forms::Application::StartupPath;
				String^ bootConfingPath = workPath +"\\BootConfig.json";
				String^ AoiConfingPath = workPath + "\\AoiConfig.json";

				aoiConfig = ConfigConvert::Read<AOIConfig^>(AoiConfingPath);
				bootConfig = ConfigConvert::Read<BootConfig^>(bootConfingPath);
				if (!Directory::Exists(bootConfig->LogPath))
					Directory::CreateDirectory(bootConfig->LogPath);

				if (!Directory::Exists(bootConfig->RecipePath))
					Directory::CreateDirectory(bootConfig->RecipePath);

				if (!Directory::Exists(bootConfig->ImagePath))
					Directory::CreateDirectory(bootConfig->ImagePath);

				sysLoger->Open(bootConfig->LogPath, "Sys.log");

				MIL_ID app, sys;
				MappAlloc(M_NULL, M_DEFAULT, &app);
				///* Allocate a MIL system. */
				MsysAlloc(M_DEFAULT, MIL_TEXT("M_DEFAULT"), M_DEFAULT, M_DEFAULT, &sys);

				this->MilApplication = app;
				this->MilSystem = sys;
			}
			catch (Exception^ ex)
			{
				return false;
			}
			return true;
			
		}

	protected:

		~SystemObj()
		{
			delete bootConfig;
			delete sysLoger;
		}

	};
}




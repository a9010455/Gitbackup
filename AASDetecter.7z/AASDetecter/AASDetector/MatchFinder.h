#pragma once
#include <Mil.h>
#include <vcclr.h>

namespace AASDetector {
	public enum class MatchFinderMode
	{
		ModeFinder=0,
		PatternMatch,
	};
	public enum class MatchFinderResult
	{
		MatchResult = 0,
		Score,
		Angle,
		PosX,
		PosY
	};
	public ref class MatchFinder {
		
	private:
		
		bool _IsInital = false;
		MIL_ID _milsystem = M_NULL;
		MIL_ID _GoldenImage = M_NULL;
		MIL_ID _MatchContext = M_NULL;	
		MatchFinderMode _Mode;

		double _Angle = 0;
		double _Score = 0;
		double _PosX = 0;
		double _PosY = 0;
		bool _MatchResult = false;
		bool _IsCalculate = false;
		double	_RemoveBorderRatio = 0.125;
		void ResetContext();
	public:
		int  Location_TH = 0;
		MatchFinder(MIL_ID milsystem,MIL_ID GoldenImage, MatchFinderMode mode);
		~MatchFinder();
		bool Preprocess();
		int Calculate(MIL_ID TargetImage, MIL_ID Mil_GraphicList);
		double GetResult(MatchFinderResult Resultparam);
		void SetMethodMode(MatchFinderMode method);
		void Preproc(MIL_ID InputImage, MIL_ID OutputImage);
	};

	
}

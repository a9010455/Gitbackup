
#include "ConfigConvert.h"

using namespace System::Collections::Generic;

namespace AASDetector
{
	ConfigObj::ConfigObj()
	{
		name = "abc";
		Size = 0;
		exp = 0.5;
	}


	ConfigObjList::ConfigObjList()
	{
		cameras = gcnew List< ConfigObj^>();
	}
	void ConfigObjList::add(ConfigObj^ obj)
	{
		this->cameras->Add(obj);
	}


	generic <class T>
			void ConfigConvert::Write(Object^ obj, String^ Filename)
		{
			Write<T>(obj, Filename, false);
		}
	generic <class T>
		void ConfigConvert::Write(Object^ obj, String^ Filename, bool encode)
	{
		StreamWriter^ file;
		try
		{
			T objconvert = safe_cast<T>(obj);

			file = File::CreateText(Filename);
			String^ json = JsonConvert::SerializeObject(objconvert, Newtonsoft::Json::Formatting::Indented);
			if (encode)
				json = DESEncrypt(json, "12345678", "12345678");

			file->Write(json);

			file->Close();

		}
		catch (Exception^ ex)
		{
			throw ex;
		}
		finally
		{
			delete file;
		}

	}

	generic <class T>
		where T : gcnew()
			T ConfigConvert::Read(String^ Filename)
		{
			return Read<T>(Filename, false);
		}

	generic <class T>
		where T : gcnew()
			T ConfigConvert::Read(String^ Filename, bool encode)
		{
			bool is_success = true;
			T obj;
			StreamReader^ file;
			try
			{
				if (!File::Exists(Filename))
				{
					T temp = gcnew T();
					Write<T>(temp, Filename, encode);
				}

				file = File::OpenText(Filename);
				String^ json = file->ReadToEnd();
				if (encode)
					json = DESDecrypt(json, "12345678", "12345678");
				obj = JsonConvert::DeserializeObject<T>(json);

				file->Close();
			}
			catch (Exception^ ex)
			{
				is_success = false;
				throw ex;
			}
			finally
			{
				delete file;
			}
			if (is_success)
			{
				Write<T>(obj, Filename, encode);
			}
			return obj;
		}


	String^ ConfigConvert::DESEncrypt(String^ data, String^ key, String^ iv)
	{
		auto byKey = System::Text::Encoding::ASCII->GetBytes(key);
		auto byIV = System::Text::Encoding::ASCII->GetBytes(iv);

		DESCryptoServiceProvider^ cryptoProvider = gcnew DESCryptoServiceProvider();
		int i = cryptoProvider->KeySize;
		MemoryStream^ ms = gcnew MemoryStream();
		CryptoStream^ cst = gcnew CryptoStream(ms, cryptoProvider->CreateEncryptor(byKey, byIV), CryptoStreamMode::Write);

		StreamWriter^ sw = gcnew StreamWriter(cst);
		sw->Write(data);
		sw->Flush();
		cst->FlushFinalBlock();
		sw->Flush();
		return Convert::ToBase64String(ms->GetBuffer(), 0, (int)ms->Length);
	}

	String^ ConfigConvert::DESDecrypt(String^ data, String^ key, String^ iv)
	{
		auto byKey = System::Text::Encoding::ASCII->GetBytes(key);
		auto byIV = System::Text::Encoding::ASCII->GetBytes(iv);


		try
		{
			auto byEnc = Convert::FromBase64String(data);
			DESCryptoServiceProvider^ cryptoProvider = gcnew DESCryptoServiceProvider();
			MemoryStream^ ms = gcnew MemoryStream(byEnc);
			CryptoStream^ cst = gcnew CryptoStream(ms, cryptoProvider->CreateDecryptor(byKey, byIV), CryptoStreamMode::Read);
			StreamReader^ sr = gcnew StreamReader(cst);
			return sr->ReadToEnd();
		}
		catch (Exception^ ex)
		{
			return nullptr;
		}

	}

}
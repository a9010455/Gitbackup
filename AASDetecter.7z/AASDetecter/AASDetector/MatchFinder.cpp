
#include "MatchFinder.h"
using namespace AASDetector;
	
MatchFinder::MatchFinder(MIL_ID milsystem,MIL_ID GoldenImage, MatchFinderMode mode)
{
	if (GoldenImage != M_NULL)
	{
		this->_milsystem = milsystem;
		this->_Mode = mode;
		this->_GoldenImage=MbufClone(GoldenImage,this->_milsystem, M_DEFAULT, M_DEFAULT, M_DEFAULT, M_DEFAULT, M_DEFAULT, M_NULL);
		MbufCopy(GoldenImage, this->_GoldenImage);
	}
}
MatchFinder::~MatchFinder()
{
	this->_milsystem = M_NULL;
	MbufFree(this->_GoldenImage);
	this->_GoldenImage = M_NULL;
	ResetContext();
}
bool MatchFinder::Preprocess() {
	bool susFlag = true;
	this->_IsCalculate = false;
	MIL_INT imageW, imageH, imageBand;
	MbufInquire(this->_GoldenImage, M_SIZE_BAND, &imageBand);
	MbufInquire(this->_GoldenImage, M_SIZE_X, &imageW);
	MbufInquire(this->_GoldenImage, M_SIZE_Y, &imageH);
	MIL_ID TempImage;
	MbufAlloc2d(this->_milsystem, imageW, imageH, 8 + M_UNSIGNED, M_IMAGE + M_PROC + M_DISP, &TempImage);
	if (imageBand > 1)
	{
		MimConvert(this->_GoldenImage, TempImage, M_RGB_TO_Y);
	}
	else
	{
		MbufCopy(this->_GoldenImage, TempImage);
	}
	Preproc(TempImage, TempImage);
	switch (this->_Mode)
	{
	case MatchFinderMode::ModeFinder: 
	{
		this->_MatchContext = MmodAlloc(this->_milsystem, M_GEOMETRIC, M_DEFAULT, M_NULL);

		
		MmodDefine(this->_MatchContext, M_IMAGE, TempImage, M_DEFAULT, M_DEFAULT, M_DEFAULT, M_DEFAULT);
		MmodControl(this->_MatchContext, M_ALL, M_ANGLE_DELTA_NEG, 45);
		MmodControl(this->_MatchContext, M_ALL, M_ANGLE_DELTA_POS, 45);
		MmodControl(this->_MatchContext, M_ALL, M_ACCEPTANCE, 20);
		MmodControl(this->_MatchContext, M_ALL, M_CERTAINTY, 50);
		MmodControl(this->_MatchContext, M_CONTEXT, M_SHARED_EDGES, M_ENABLE);

		//�p�G�S���S�x�A�^��false
		MIL_INT NbModelEdges = MmodInquire(this->_MatchContext, 0, M_NUMBER_OF_CHAINED_EDGELS, M_NULL);
		if (NbModelEdges == 0)
		{
			MosPrintf(MIL_TEXT("Invalid template image. The resulting model is empty.\n\n"));
			susFlag = false;
		}
		MmodControl(this->_MatchContext, M_DEFAULT, M_NUMBER, 1);
		MmodPreprocess(this->_MatchContext, M_DEFAULT);
		break;
	}
		
	case MatchFinderMode::PatternMatch:
	{
		/* Allocate a normalized pattern matching context. */
		this->_MatchContext = MpatAlloc(this->_milsystem, M_NORMALIZED, M_DEFAULT,M_NULL);

		/* Define a regular model. */
		MpatDefine(this->_MatchContext, M_REGULAR_MODEL, TempImage, M_DEFAULT,
			M_DEFAULT, M_DEFAULT, M_DEFAULT, M_DEFAULT);

		/* Set the search accuracy to high. */
		MpatControl(this->_MatchContext, M_DEFAULT, M_ACCURACY, M_HIGH);
		MpatControl(this->_MatchContext, M_DEFAULT, M_SEARCH_ANGLE_TOLERANCE, M_AUTO);
		/* Set the search model speed to high. */
		MpatControl(this->_MatchContext, M_DEFAULT, M_SPEED, M_HIGH);

		MpatControl(this->_MatchContext, M_DEFAULT, M_SEARCH_ANGLE_MODE, M_ENABLE);
		/* Set the search model range angle. */
		MpatControl(this->_MatchContext, M_DEFAULT, M_SEARCH_ANGLE_DELTA_NEG, 45);
		MpatControl(this->_MatchContext, M_DEFAULT, M_SEARCH_ANGLE_DELTA_POS, 45);
		MpatControl(this->_MatchContext, M_DEFAULT, M_SEARCH_ANGLE_ACCURACY, 0.25);

		MpatControl(this->_MatchContext, M_DEFAULT, M_ACCEPTANCE, 10);
		/* Set the search model angle interpolation mode to bilinear. */
		MpatControl(this->_MatchContext, M_DEFAULT, M_SEARCH_ANGLE_INTERPOLATION_MODE, M_BILINEAR);
		/* Preprocess the model. */
		MpatPreprocess(this->_MatchContext, M_DEFAULT, this->_GoldenImage);
		break;
	}	
	}
	MbufFree(TempImage);
	this->_IsInital = susFlag;
	return susFlag;
}

int MatchFinder::Calculate(
	MIL_ID TargetImage,
	MIL_ID Mil_GraphicList)
{
	int AreaOfSum = 0;
	if (TargetImage == M_NULL || !this->_IsInital)
	{
		this->_IsCalculate = false;
		return -1;
	}
	this->_IsCalculate = true;
	MIL_INT imageW, imageH, imageBand;
	MbufInquire(TargetImage, M_SIZE_BAND, &imageBand);
	MbufInquire(TargetImage, M_SIZE_X, &imageW);
	MbufInquire(TargetImage, M_SIZE_Y, &imageH);
	MIL_ID TempImage;
	MbufAlloc2d(this->_milsystem, imageW, imageH, 8 + M_UNSIGNED, M_IMAGE + M_PROC + M_DISP, &TempImage);
	if (imageBand > 1)
	{
		MimConvert(TargetImage, TempImage, M_RGB_TO_Y);
	}
	else
	{
		MbufCopy(TargetImage, TempImage);
	}
	Preproc(TempImage, TempImage);
	switch (this->_Mode)
	{
#pragma region ModeFinder
	case MatchFinderMode::ModeFinder:
	{
		MIL_ID MilModResult;

		MIL_INT		TempImgSizeX;
		MIL_INT		TempImgSizeY;
		MbufInquire(this->_GoldenImage, M_SIZE_X, &TempImgSizeX);
		MbufInquire(this->_GoldenImage, M_SIZE_Y, &TempImgSizeY);


		MmodAllocResult(this->_milsystem, M_DEFAULT, &MilModResult);
		
		MmodFind(this->_MatchContext, TempImage, MilModResult);

		// Get the number of occurrences.
		MIL_INT NbOfOccurrences;
		MmodGetResult(MilModResult, M_GENERAL, M_NUMBER + M_TYPE_MIL_INT, &NbOfOccurrences);
		//If Find object , get locate and warpping
		if (NbOfOccurrences > 0)
		{
			this->_MatchResult = true;
			MIL_DOUBLE XPosition = 0, YPosition = 0,score=0, angle=0;
			//���X��쪺��T
			MgraColor(M_DEFAULT, M_COLOR_GREEN);
			for (MIL_INT i = 0; i < NbOfOccurrences; i++)
			{
				if (Mil_GraphicList != M_NULL)
				{
					MmodDraw(M_DEFAULT, MilModResult, Mil_GraphicList, M_DRAW_BOX, i, M_DEFAULT);
					MmodDraw(M_DEFAULT, MilModResult, Mil_GraphicList, M_DRAW_POSITION, i, M_DEFAULT);
				}
			}
			MmodGetResult(MilModResult, M_DEFAULT, M_POSITION_X, &XPosition);
			MmodGetResult(MilModResult, M_DEFAULT, M_POSITION_Y, &YPosition);
			MmodGetResult(MilModResult, M_DEFAULT, M_SCORE + M_TYPE_MIL_DOUBLE, &score);
			MmodGetResult(MilModResult, M_DEFAULT, M_ANGLE + M_TYPE_MIL_DOUBLE, &angle);
			this->_Score = score;
			this->_Angle = angle;
			this->_PosX = XPosition;
			this->_PosY = YPosition;

			if (Mil_GraphicList != M_NULL)
			{
				MgraArcFill(M_DEFAULT, Mil_GraphicList, XPosition, YPosition, 2, 2, 0, 360);
			}

		}

		else
		{
			this->_MatchResult = false;
			this->_Score = 0;
			this->_Angle = 0;
		}

		MmodFree(MilModResult);
		break;
	}
#pragma endregion

#pragma region PatternMatch
	case MatchFinderMode::PatternMatch:
	{
		MIL_ID MilpatResult;

		MIL_INT	TempImgSizeX;
		MIL_INT	TempImgSizeY;
		MbufInquire(this->_GoldenImage, M_SIZE_X, &TempImgSizeX);
		MbufInquire(this->_GoldenImage, M_SIZE_Y, &TempImgSizeY);


		MpatAllocResult(this->_milsystem, M_DEFAULT, &MilpatResult);

		MpatFind(this->_MatchContext, TempImage, MilpatResult);

		// Get the number of occurrences.
		MIL_INT NbOfOccurrences;
		MpatGetResult(MilpatResult, M_GENERAL, M_NUMBER + M_TYPE_MIL_INT, &NbOfOccurrences);
		//If Find object , get locate and warpping
		if (NbOfOccurrences > 0)
		{
			this->_MatchResult = true;
			MIL_DOUBLE XPosition = 0, YPosition = 0, score = 0, angle = 0;
			//���X��쪺��T
			MgraColor(M_DEFAULT, M_COLOR_GREEN);
			for (MIL_INT i = 0; i < NbOfOccurrences; i++)
			{
				if (Mil_GraphicList != M_NULL)
				{
					MpatDraw(M_DEFAULT, MilpatResult, Mil_GraphicList, M_DRAW_BOX, i, M_DEFAULT);
					MpatDraw(M_DEFAULT, MilpatResult, Mil_GraphicList, M_DRAW_POSITION, i, M_DEFAULT);
				}
			}
			MpatGetResult(MilpatResult, M_DEFAULT, M_POSITION_X, &XPosition);
			MpatGetResult(MilpatResult, M_DEFAULT, M_POSITION_Y, &YPosition);
			MpatGetResult(MilpatResult, M_DEFAULT, M_ANGLE + M_TYPE_MIL_DOUBLE, &angle);
			MpatGetResult(MilpatResult, M_DEFAULT, M_SCORE + M_TYPE_MIL_DOUBLE, &angle);
			this->_Score = score;
			this->_Angle = angle;
			this->_PosX = XPosition;
			this->_PosY = YPosition;

			if (Mil_GraphicList != M_NULL)
			{
				MgraArcFill(M_DEFAULT, Mil_GraphicList, XPosition, YPosition, 2, 2, 0, 360);

			}

			else
			{
				this->_MatchResult = false;
				this->_Score = 0;
				this->_Angle = 0;
			}

			MpatFree(MilpatResult);
			break;
		}
	}
#pragma endregion

	}
	MbufFree(TempImage);
	return AreaOfSum;
}
double MatchFinder::GetResult(MatchFinderResult Resultparam) 
{
	if (!_IsCalculate)
		return -1;
	switch (Resultparam)
	{
	case MatchFinderResult::MatchResult:
	{
		if (this->_MatchResult)
			return 1;
		else
			return 0;
		break;
	}

	case MatchFinderResult::Score:
		return this->_Score;
		break;	
	case MatchFinderResult::Angle:
		return this->_Angle;
		break;

	case MatchFinderResult::PosX:
		return this->_PosX;
		break;

	case MatchFinderResult::PosY:
		return this->_PosY;
		break;

	default:
		break;
	}
}
void MatchFinder::SetMethodMode(MatchFinderMode method) {
	ResetContext();
	this->_Mode = method;
}
void MatchFinder::ResetContext()
{
	this->_IsInital = false;
	this->_IsCalculate = false;
	switch (this->_Mode)
	{
	case MatchFinderMode::ModeFinder:
	{
		if (this->_MatchContext)
		{
			MmodFree(this->_MatchContext);
			this->_MatchContext = M_NULL;
		}

		break;
	}

	case MatchFinderMode::PatternMatch:
	{
		if (this->_MatchContext)
		{
			MpatFree(this->_MatchContext);
			this->_MatchContext = M_NULL;
			break;
		}

	}
	}
}
void MatchFinder::Preproc(MIL_ID InputImage, MIL_ID OutputImage)
{
	if (InputImage != M_NULL && OutputImage != M_NULL)
	{
		MIL_INT imageW, imageH, imageBand;
		MbufInquire(InputImage, M_SIZE_BAND, &imageBand);
		MbufInquire(InputImage, M_SIZE_X, &imageW);
		MbufInquire(InputImage, M_SIZE_Y, &imageH);
		if (Location_TH>0)
		{
			//[1] ImgProc - median filter 
			MimRank(InputImage, OutputImage, M_3X3_RECT + M_OVERSCAN_DISABLE, M_MEDIAN, M_GRAYSCALE);

			//[2] ImgProc - EDGE_DETECT_SOBEL
			MimConvolve(OutputImage, OutputImage, M_EDGE_DETECT_SOBEL_FAST + M_OVERSCAN_DISABLE);

			//[3] ImgProc - Binarize
			MimBinarize(OutputImage, OutputImage, M_FIXED + M_GREATER, Location_TH, M_NULL);

			//[4] ImgProc - Clear Rim
			MgraColor(M_DEFAULT, M_COLOR_BLACK);

			//ImgProc - Clear Rim Up
			MgraRect(M_DEFAULT, OutputImage, 0, 0, imageW - 1, 0);
			//ImgProc - Clear Rim Bottom
			MgraRect(M_DEFAULT, OutputImage, 0, imageH - 1, imageW - 1, imageH - 1);
			//ImgProc - Clear Rim Left
			MgraRect(M_DEFAULT, OutputImage, 0, 0, 0, imageH - 1);
			//ImgProc - Clear Rim Right
			MgraRect(M_DEFAULT, OutputImage, imageW - 1, 0, imageW - 1, imageH - 1);

			//[5] ImgProc - Dilation
			MimDilate(OutputImage, OutputImage, 5, M_BINARY);
		}

	}
}


// ColorDeMura.cpp: �D�n�M���ɡC
#include "CameraSetting.hpp"

using namespace AASDetector;
using namespace System::Diagnostics;

[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	Process	^				current = Process::GetCurrentProcess();
	array< Process ^ >	^	processes = Process::GetProcessesByName(current->ProcessName);

	bool					ProcessIsOpened = false;
	for (int cnt_i = 0; cnt_i < processes->Length; cnt_i++) {

		if (processes[cnt_i]->Id != current->Id) {
			ProcessIsOpened = true;
			break;
		}
	}

	if (!ProcessIsOpened) {

		Application::EnableVisualStyles();
		Application::SetCompatibleTextRenderingDefault(false);

		Application::Run(gcnew CameraSetting());

	}
	else {

		System::Windows::Forms::MessageBox::Show("Application Already Opened.",
			"Open Error",
			System::Windows::Forms::MessageBoxButtons::OK,
			System::Windows::Forms::MessageBoxIcon::Error);
	}

	return 0;
}
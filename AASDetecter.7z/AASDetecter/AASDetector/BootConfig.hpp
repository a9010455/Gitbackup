#pragma once
#include "ConfigConvert.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Drawing::Imaging;
using namespace System::Collections::Generic;
using namespace System::Diagnostics;

namespace AASDetector
{
	ref class BootConfig
	{
	public:
		property String^ RecipePath;
		property String^ ImagePath;
		property String^ LogPath;
		BootConfig()
		{
			RecipePath = String::Empty;
			LogPath = String::Empty;
			RecipePath = ".\\Recipe";
			ImagePath = ".\\Image";
			LogPath = ".\\Log";
		}


	protected:

		~BootConfig()
		{

		}




	};

	ref class AOIConfig
	{
		String^ golden2DImagePath;
		String^ golden3DImagePath;
	public:

		[Category("GoldenPath")]
		property String^ Golden2DImagePath
		{
			String^ get() { return golden2DImagePath; }
		};
		[Category("GoldenPath")]
		property String^ Golden3DImagePath
		{
			String^ get() { return golden3DImagePath; }
		};
		[Category("Image Golden Setting")]
		property int Point2D_X;
		[Category("Image Golden Setting")]
		property int Point2D_Y;
		[Category("Image Golden Setting")]
		property int Point3D_X;
		[Category("Image Golden Setting")]
		property int Point3D_Y;

		[Category("Robot Golden Setting")]
		property int RobotLocaltion2D_X;
		[Category("Robot Golden Setting")]
		property int RobotLocaltion2D_Y;
		[Category("Robot Golden Setting")]
		property int RobotLocaltion2D_Z;
		[Category("Robot Golden Setting")]
		property int RobotLocaltion3D_X;
		[Category("Robot Golden Setting")]
		property int RobotLocaltion3D_Y;
		[Category("Robot Golden Setting")]
		property int RobotLocaltion3D_Z;
		AOIConfig()
		{
			String^ workPath = System::Windows::Forms::Application::StartupPath;
			Point2D_X = -1;
			Point2D_Y = -1;
			Point3D_X = -1;
			Point3D_Y = -1;
			golden2DImagePath = workPath +"\\Image2D.tif";
			golden3DImagePath = workPath + "\\Image3D.tif";

			RobotLocaltion2D_X = -1;
			RobotLocaltion2D_Y = -1;
			RobotLocaltion2D_Z = -1;
			RobotLocaltion3D_X = -1;
			RobotLocaltion3D_Y = -1;
			RobotLocaltion3D_Z = -1;
		}
		void AOIConfig::Save()
		{
			String^ workPath = System::Windows::Forms::Application::StartupPath;
			String^ AoiConfingPath = workPath + "\\AoiConfig.json";
			ConfigConvert::Write<AOIConfig^>(this, AoiConfingPath);
		}

	protected:

		~AOIConfig()
		{

		}

	};
}




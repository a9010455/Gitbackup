#pragma once
#include <msclr\lock.h>

using namespace System;
using namespace System::IO;
using namespace System::Collections::Generic;
using namespace System::Text;
using namespace System::Threading::Tasks;
using namespace System::Drawing;
using namespace System::Windows::Forms;

using namespace Microsoft::Win32::SafeHandles;
using namespace System::Runtime::InteropServices;

namespace AASDetector {

    enum LogerLevel
    {
        HIGH,
        GENERAL,
        WARNING,
        GREEN,
        BLUE
    };

	public ref class Loger
	{
	public:
		 delegate void MessageDelegate(
             RichTextBox^% textbox, Color color, String^ message);
	private :
        static Object^ _thisLock = gcnew Object();

        static int MAX_LOGLINE = 1000;

        String^ logPath;
        String^ logFilename;
        DateTime^ logDate;
        StreamWriter^ logFile;
        RichTextBox^ messagebox;
        Color color = SystemColors::ControlText;


    public:
		 Loger()
		 {
             this->logPath = String::Empty;
             this->logFilename = String::Empty;
             this->logDate = DateTime::Now;
		 }

		 ~Loger()
		 {
             //	���� SteamWriter �Ŷ�
             if (this->logFile->BaseStream != nullptr)
             {
                 Close();
                 delete this->logFile;
             }
		 }

    public :
        void SetLevel(LogerLevel level)
        {
            switch (level)
            {
            case AASDetector::HIGH:
                color = Color::Red;
                break;
            case AASDetector::GENERAL:
                color = SystemColors::ControlText;
                break;
            case AASDetector::WARNING:
                color = Color::DarkOrange;
                break;
            case AASDetector::GREEN:
                color = Color::Green;
                break;
            case AASDetector::BLUE:
                color = Color::Blue;
                break;
            default:
                break;
            }
        }
        void Open(String^ path, String^ filename)
         {
             String^ stringDate = String::Empty;

             this->logDate = DateTime::Now;
             this->logFilename = filename;
             this->logPath = path;

             try
             {
                 stringDate = String::Format("{0:yyyyMMdd}", this->logDate);

                 //	�}���ɮ�
                 this->logFile = File::AppendText(
                     String::Format("{0}\\{1}_{2}.log",
                         this->logPath, this->logFilename, stringDate));

                 //	�]�w�۰ʲM�� - ����Ƽg�J�ɷ|�۰ʱN���F�s�X�����A�~����L���A���M��
                 this->logFile->AutoFlush = true;

                 //	�g�J�ɮ׶}�Үɶ�
                 this->logFile->WriteLine(
                     "=============== LOG START - {0:yyyy}.{0:MM}.{0:dd} {0:HH}:{0:mm}:{0:ss}:{0:ffff} ===============",
                     this->logDate);
             }
             catch (System::Exception^ ex)
             {
                 throw ex;
             }
         }

         //	Close
    public:
        void Close()
         {
             DateTime logCloseDate = DateTime::Now;

             try
             {
                 //	�g�J�ɮ������ɶ�
                 this->logFile->WriteLine(
                     "===============   LOG END - {0:yyyy}.{0:MM}.{0:dd} {0:HH}:{0:mm}:{0:ss}:{0:ffff} ===============",
                     logCloseDate);

                 this->logFile->Close();
             }
             catch (System::Exception^ ex)
             {
                 //	�Y�O�w�Юe�q�����ɡA�����ɮצ��i��|�y���ҥ~�ƥ�
                 throw ex;
             }
         }

         //	Write
    public:
        void Write(String^ message)
         {


             try
             {            

                 msclr::lock l(_thisLock);
                 DateTime^ writeTime = DateTime::Now;
                 TimeSpan^ ts = gcnew TimeSpan(writeTime->Day - this->logDate->Day);

                 //	Log�ݨC�Ѧ۰ʧ�s
                 //	�P�_��Ƽg�J�ɶ��O�_�M�ɮ׮ɶ��P�@��
                 if (ts->Days != 0)
                 {
                     //	��Ƽg�J����M�ɮפ�����P�ѡA�����ɮ׭��s�}��
                     this->logFile->WriteLine("Data write Date is not same as File Date. Close file and Open a new file.");
                     this->Close();
                     this->Open(this->logPath, this->logFilename);
                 }
                 String^ logmessage = String::Format("{0:yyyy}/{0:MM}/{0:dd}, {0:HH}:{0:mm}:{0:ss}:{0:ffff} - {1}",
                     writeTime, message);
                 this->logFile->WriteLine(logmessage);

                 //	�T�{�O�_�������q�X
                 if (this->messagebox != nullptr)
                 {
                     this->MessageToTextBox(
                         this->messagebox, this->color, logmessage);
                 }
                 l.release();
             }
             catch (System::Exception^ ex)
             {
                 throw ex;
             }
         }

    public:
        void SetTextBox(RichTextBox^ %textbox)
        {
            if (textbox == nullptr)
            {
                throw gcnew ArgumentNullException();
            }

            this->messagebox = textbox;
        }
    public:
        void unSetTextBox()
        {
            this->messagebox = nullptr;
        }
    private:
        void MessageToTextBox(RichTextBox^ %textbox, Color color, String^ message)
        {
            if (textbox->InvokeRequired)
            {
                MessageDelegate^ action = gcnew MessageDelegate(this, &Loger::MessageToTextBox);

                textbox->BeginInvoke(action, textbox, color, message);
            }
            else
            {
                //	����
                if (textbox->Lines->Length > 0)
                    textbox->AppendText("\n");

                //	��J�T��

                textbox->SelectionColor = color;
                textbox->AppendText(message);

                //	�Y�O�W�L�̤j�W���A�R���Ĥ@��A��L�O�d
                if (textbox->Lines->Length > MAX_LOGLINE)
                {
                    String^ fullString;

                    textbox->Select(
                        textbox->GetFirstCharIndexFromLine(1),
                        textbox->TextLength);
                    fullString = textbox->SelectedRtf;
                    textbox->Rtf = fullString;
                }

                //	���в���̫�
                textbox->SelectionStart = textbox->TextLength;
                textbox->ScrollToCaret();
            }
        }
	};
}

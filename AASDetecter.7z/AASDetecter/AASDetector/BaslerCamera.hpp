#include "mil.h"
#include "SystemObj.hpp"

#pragma once
using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Drawing::Imaging;
using namespace System::Collections::Generic;
using namespace System::Diagnostics;
using namespace Basler::Pylon;
using namespace MILBaseTool;

ref class ImageData
{

public:
	MIL_ID image = M_NULL;

public:

	ImageData(void)
	{

	}
protected:

	~ImageData()
	{
		MbufFree(image);
	}

};
delegate void ImageGrabbed_Callback(ImageData^ imageData);

ref class BaslerCamera
{
private:
	static double MAX_DISPLAY_FPS = 10;
	int continuousIntervalTimes = -1;
	Stopwatch^ stopWatch = gcnew Stopwatch();
	Stopwatch^ captureWatch = gcnew Stopwatch();
	Bitmap^ bmpForShow = nullptr;
	SystemObj^ sysobj = nullptr;
	ImageData^ imageData = gcnew ImageData();
	MILDisplay^ disp = nullptr;
	bool IsSnap = false;

public:
	Camera^ camera = nullptr;
	PixelDataConverter^ converter = gcnew PixelDataConverter();
	BackgroundWorker^ shotThread;
	Panel^ picturebox = nullptr;

	event EventHandler^ _ConnectionLost;
	event EventHandler^ _CameraOpened;
	event EventHandler^ _CameraClosed;
	event EventHandler^ _GrabStarted;
	event ImageGrabbed_Callback^ _ImageGrabbed;
	event EventHandler^ _GrabStopped;


public:

	BaslerCamera(SystemObj^ obj )
	{
		sysobj = obj;
	}

protected:

	~BaslerCamera()
	{
		this->DestroyCamera();
	}

public:

	void Open(String^ serialnumber)
	{
		// Destroy the old camera object.
		if (camera != nullptr)
		{
			DestroyCamera();
		}
		try
		{
			camera = gcnew Camera(serialnumber);

			camera->CameraOpened += gcnew EventHandler<EventArgs^>(Basler::Pylon::Configuration::SoftwareTrigger);
			camera->ConnectionLost += gcnew EventHandler<EventArgs^>(this, &BaslerCamera::OnConnectionLost);
			camera->CameraOpened += gcnew EventHandler<EventArgs^>(this, &BaslerCamera::OnCameraOpened);
			camera->CameraClosed += gcnew EventHandler<EventArgs^>(this, &BaslerCamera::OnCameraClosed);
			camera->StreamGrabber->GrabStarted += gcnew EventHandler<EventArgs^>(this, &BaslerCamera::OnGrabStarted);
			camera->StreamGrabber->ImageGrabbed += gcnew EventHandler<ImageGrabbedEventArgs^>(this, &BaslerCamera::OnImageGrabbed);
			camera->StreamGrabber->GrabStopped += gcnew EventHandler<GrabStopEventArgs^>(this, &BaslerCamera::OnGrabStopped);
			camera->Parameters[PLCameraInstance::GrabCameraEvents]->SetValue(true);
			camera->Open();
			if(camera->Parameters[PLCamera::AcquisitionFrameRateAbs]->IsWritable)
				camera->Parameters[PLCamera::AcquisitionFrameRateAbs]->SetValue(camera->Parameters[PLCamera::AcquisitionFrameRateAbs]->GetMaximum());
			else if(camera->Parameters[PLCamera::AcquisitionFrameRate]->IsWritable)
				camera->Parameters[PLCamera::AcquisitionFrameRate]->SetValue(camera->Parameters[PLCamera::AcquisitionFrameRate]->GetMaximum());
		}

		catch (Exception^ exception)
		{
			this->DestroyCamera();
			throw exception;
		}
	}

	void Close()
	{
		try
		{
			if (camera != nullptr)
			{
				camera->Close();
				delete camera;
			}
		}
		catch (Exception^ exception)
		{
			throw exception;
		}
	}

	void SetPictureBox(Panel^ %pb, MILDisplay^ % mildisp)
	{
		picturebox = pb;
		disp = mildisp;
	}

	void DestroyCamera()
	{
		// Destroy the camera object.
		try
		{
			if (camera != nullptr)
			{
				camera->Close();
				delete camera;
			}
		}
		catch (Exception^ exception)
		{
			throw exception;
		}
		
		// Destroy the converter object.
		if (converter != nullptr)
		{
			delete converter;
		}
		picturebox = nullptr;
	}

public:

	void OnConnectionLost(Object^ sender, EventArgs^ e)
	{
		_ConnectionLost(sender, e);
	}


	// Occurs when the connection to a camera device is opened.
	void OnCameraOpened(Object^ sender, EventArgs^ e)
	{
		Console::WriteLine("CameraOpen");
		_CameraOpened(sender, e);
	}


	// Occurs when the connection to a camera device is closed.
	void OnCameraClosed(Object^ sender, EventArgs^ e)
	{
		_CameraClosed(sender, e);
	}


	// Occurs when a camera starts grabbing.
	void OnGrabStarted(Object^ sender, EventArgs^ e)
	{
		_GrabStarted(sender, e);
	}

	// Occurs when an image has been acquired and is ready to be processed.
	void OnImageGrabbed(Object^ sender, ImageGrabbedEventArgs^ e)
	{
		if (picturebox != nullptr)
		{
			if (picturebox->InvokeRequired)
			{
				// If called from a different thread, we must use the Invoke method to marshal the call to the proper GUI thread.
				// The grab result will be disposed after the event call. Clone the event arguments for marshaling to the GUI thread.
				picturebox->BeginInvoke(gcnew EventHandler<ImageGrabbedEventArgs^>(this, &BaslerCamera::OnImageGrabbed), sender, e->Clone());
				return;
			}
		}

		try
		{
			// Get the grab result.
			IGrabResult^ grabResult = e->GrabResult;

			// Check if the image can be displayed.
			if (grabResult->IsValid)
			{

				Bitmap^ bitmap = gcnew Bitmap(grabResult->Width, grabResult->Height,
					PixelFormat::Format24bppRgb);
				// Lock the bits of the bitmap.
				BitmapData^ bmpData = bitmap->LockBits(
					Rectangle(0, 0, bitmap->Width, bitmap->Height),
					ImageLockMode::ReadWrite, bitmap->PixelFormat);
				// Place the pointer to the buffer of the bitmap.
				converter->OutputPixelFormat = PixelType::RGB8planar;
				IntPtr ptrBmp = bmpData->Scan0;
				converter->Convert(ptrBmp, bmpData->Stride * bitmap->Height, grabResult);
				bitmap->UnlockBits(bmpData);


				if (imageData->image == M_NULL)
				{
					this->imageData->image = MbufAllocColor(sysobj->MilSystem, 3,
						grabResult->Width, grabResult->Height, 8 + M_UNSIGNED,
						M_IMAGE + M_DISP + M_PROC,
						M_NULL);
				}
				unsigned char*  pImgGrab = reinterpret_cast<unsigned char*>(ptrBmp.ToPointer());
				MbufPutColor(imageData->image, M_PLANAR, M_ALL_BANDS, pImgGrab);

				 //Reduce the number of displayed images to a reasonable amount if the camera is acquiring images very fast.
				if (!stopWatch->IsRunning || stopWatch->ElapsedMilliseconds > (1.0/ MAX_DISPLAY_FPS)*1000)
				{
					stopWatch->Restart();
					//�����]�w��ܵ����ɡA�~�B��
					if (picturebox != nullptr)
					{
						disp->Image = imageData->image;
					}
				}
				_ImageGrabbed(imageData);
				delete bitmap;
			}
		}
		catch (Exception^ exception)
		{
			Console::WriteLine(exception->StackTrace);
		}
		finally
		{
			// Dispose the grab result if needed for returning it to the grab loop.
			e->DisposeGrabResultIfClone();
		}


	}

	// Occurs when a camera has stopped grabbing.
	void OnGrabStopped(Object^ sender, GrabStopEventArgs^ e)
	{

		// If the grabbed stop due to an error, display the error message.
		if (e->Reason != GrabStopReason::UserRequest)
		{
			MessageBox::Show("A grab error occured:\n" + e->ErrorMessage, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}

		_GrabStopped(sender, e);
	}


	void OneShot()
	{
		try
		{
			IsSnap = true;
			camera->Parameters[PLCamera::AcquisitionMode]->SetValue(PLCamera::AcquisitionMode->SingleFrame);
			camera->StreamGrabber->Start(1,GrabStrategy::LatestImages, GrabLoop::ProvidedByStreamGrabber);

			if (shotThread == nullptr)
			{
				shotThread = gcnew BackgroundWorker();
				shotThread->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &BaslerCamera::shotThread_DoWork);
			}

			if (shotThread->IsBusy)
				MessageBox::Show("Camera is continuous shoting.");
			else
			{
				shotThread->RunWorkerAsync(camera);
			}

		}
		catch (Exception^ exception)
		{
			Console::WriteLine(exception);
			Console::WriteLine(exception->StackTrace);
		}
	}

	void ContinuousShot()
	{
		ContinuousShot(-1);
	}

	void ContinuousShot(int intervalTime)
	{
		try
		{
			IsSnap = false;
			stopWatch->Reset();
			stopWatch->Start();
			continuousIntervalTimes = intervalTime;

			if (continuousIntervalTimes != -1)
			{
				captureWatch->Reset();
				captureWatch->Start();
			}			
			camera->Parameters[PLCamera::AcquisitionMode]->SetValue(PLCamera::AcquisitionMode->Continuous);
			camera->StreamGrabber->Start(GrabStrategy::LatestImages, GrabLoop::ProvidedByStreamGrabber);
			if (shotThread == nullptr)
			{
				shotThread = gcnew BackgroundWorker();
				shotThread->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &BaslerCamera::shotThread_DoWork);
			}

			if (shotThread->IsBusy)
				MessageBox::Show("Camera is continuous shoting.");
			else
			{
				shotThread->RunWorkerAsync(camera);
			}
		}
		catch (Exception^ exception)
		{
			Console::WriteLine(exception);
			Console::WriteLine(exception->StackTrace);
		}
	}

	void CameraStop()
	{
		try
		{
			IsSnap = false;
			camera->StreamGrabber->Stop();
			stopWatch->Stop();
		}
		catch (Exception^ exception)
		{
			Console::WriteLine(exception);
			Console::WriteLine(exception->StackTrace);
		}
	}

private: 
	System::Void shotThread_DoWork(System::Object^ sender, System::ComponentModel::DoWorkEventArgs^ e)
	{
		try
		{
			Camera^ ca = (Camera^)e->Argument;

			while (ca->StreamGrabber->IsGrabbing)
			{
				if (!captureWatch->IsRunning)
				{
					if (ca->WaitForFrameTriggerReady(1000, TimeoutHandling::ThrowException))
					{
						ca->ExecuteSoftwareTrigger();
					}
				}
				else if (captureWatch->ElapsedMilliseconds > continuousIntervalTimes)
				{
					captureWatch->Restart();
					if (ca->WaitForFrameTriggerReady(1000, TimeoutHandling::ThrowException))
					{
						ca->ExecuteSoftwareTrigger();
					}
				}
			}
			
		}
		catch (Exception^ exception)
		{

		}
		finally
		{
			captureWatch->Stop();
		}

	}



};


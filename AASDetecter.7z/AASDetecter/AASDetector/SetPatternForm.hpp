#pragma once
#include "Mil.h"
#include "MatchFinder.h"
#include "SystemObj.hpp"


using namespace MILBaseTool;

namespace AASDetector {
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// SetPatternForm ���K�n
	/// </summary>
	public ref class SetPatternForm : public System::Windows::Forms::Form
	{
	private:

		MILDisplay^ milDisplaySrc;
		MILDisplay^ milDisplayModel;
		MILDisplay^ milDisplayProc;
		SystemObj^ systemObj;

		MIL_ID MilModelImage = M_NULL;
		MIL_ID Mil_GraphicList = M_NULL;
		MatchFinder^ matchfinder;
		bool _isAtizCam = false;


	private: System::Windows::Forms::RichTextBox^ richTextBox1;
	private: System::Windows::Forms::Label^ label1;
		   bool is_initial = false;

	public:
		property bool IsSaved;
		SetPatternForm(MIL_ID image, SystemObj^ sysObj, bool isAtizCam)
		{
			InitializeComponent();
			//
			//TODO:  �b���[�J�غc�禡�{���X
			//
			systemObj = sysObj;
			milDisplaySrc = gcnew MILDisplay(panel_Source);
			milDisplaySrc->MilSystem = this->systemObj->MilSystem;
			milDisplaySrc->SupportROIMeun = true;

			milDisplayModel = gcnew MILDisplay(panel_model);
			milDisplayModel->MilSystem = this->systemObj->MilSystem;

			milDisplayProc = gcnew MILDisplay(panel_proc);
			milDisplayProc->MilSystem = this->systemObj->MilSystem;
			this->Mil_GraphicList = MgraAllocList(this->systemObj->MilSystem, M_DEFAULT, M_NULL);

			milDisplaySrc->Image = image;
			_isAtizCam = isAtizCam;
			if (_isAtizCam)
			{
				label1->Text = "SetMode:3DCam";
			}
			IsSaved = false;
		}

	protected:
		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
		~SetPatternForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TabControl^ TabControl;
	protected:
	private: System::Windows::Forms::TabPage^ tab_src;
	private: System::Windows::Forms::Panel^ panel_Source;
	private: System::Windows::Forms::TabPage^ tab_proc;
	private: System::Windows::Forms::Panel^ panel_proc;
	private: System::Windows::Forms::Button^ btn_proc1;
	private: System::Windows::Forms::Button^ btn_initial;
	private: System::Windows::Forms::Button^ btn_genModel;
	private: System::Windows::Forms::Button^ btn_loadModel;
	private: System::Windows::Forms::Panel^ panel_model;
	private: System::Windows::Forms::Button^ btn_SaveModel;

	private:
		/// <summary>
		/// �]�p�u��һݪ��ܼơC
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边�ק�
		/// �o�Ӥ�k�����e�C
		/// </summary>
		void InitializeComponent(void)
		{
			this->TabControl = (gcnew System::Windows::Forms::TabControl());
			this->tab_src = (gcnew System::Windows::Forms::TabPage());
			this->panel_Source = (gcnew System::Windows::Forms::Panel());
			this->tab_proc = (gcnew System::Windows::Forms::TabPage());
			this->panel_proc = (gcnew System::Windows::Forms::Panel());
			this->btn_proc1 = (gcnew System::Windows::Forms::Button());
			this->btn_initial = (gcnew System::Windows::Forms::Button());
			this->btn_genModel = (gcnew System::Windows::Forms::Button());
			this->btn_loadModel = (gcnew System::Windows::Forms::Button());
			this->panel_model = (gcnew System::Windows::Forms::Panel());
			this->btn_SaveModel = (gcnew System::Windows::Forms::Button());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->TabControl->SuspendLayout();
			this->tab_src->SuspendLayout();
			this->tab_proc->SuspendLayout();
			this->SuspendLayout();
			// 
			// TabControl
			// 
			this->TabControl->Controls->Add(this->tab_src);
			this->TabControl->Controls->Add(this->tab_proc);
			this->TabControl->Location = System::Drawing::Point(13, 13);
			this->TabControl->Margin = System::Windows::Forms::Padding(4);
			this->TabControl->Name = L"TabControl";
			this->TabControl->SelectedIndex = 0;
			this->TabControl->Size = System::Drawing::Size(564, 323);
			this->TabControl->TabIndex = 30;
			// 
			// tab_src
			// 
			this->tab_src->Controls->Add(this->panel_Source);
			this->tab_src->Location = System::Drawing::Point(4, 25);
			this->tab_src->Margin = System::Windows::Forms::Padding(4);
			this->tab_src->Name = L"tab_src";
			this->tab_src->Padding = System::Windows::Forms::Padding(4);
			this->tab_src->Size = System::Drawing::Size(556, 294);
			this->tab_src->TabIndex = 0;
			this->tab_src->Text = L"Src";
			this->tab_src->UseVisualStyleBackColor = true;
			// 
			// panel_Source
			// 
			this->panel_Source->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel_Source->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel_Source->Location = System::Drawing::Point(4, 4);
			this->panel_Source->Margin = System::Windows::Forms::Padding(4);
			this->panel_Source->Name = L"panel_Source";
			this->panel_Source->Size = System::Drawing::Size(548, 286);
			this->panel_Source->TabIndex = 2;
			// 
			// tab_proc
			// 
			this->tab_proc->Controls->Add(this->panel_proc);
			this->tab_proc->Location = System::Drawing::Point(4, 25);
			this->tab_proc->Margin = System::Windows::Forms::Padding(4);
			this->tab_proc->Name = L"tab_proc";
			this->tab_proc->Padding = System::Windows::Forms::Padding(4);
			this->tab_proc->Size = System::Drawing::Size(556, 294);
			this->tab_proc->TabIndex = 1;
			this->tab_proc->Text = L"Proc";
			this->tab_proc->UseVisualStyleBackColor = true;
			// 
			// panel_proc
			// 
			this->panel_proc->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel_proc->Dock = System::Windows::Forms::DockStyle::Fill;
			this->panel_proc->Location = System::Drawing::Point(4, 4);
			this->panel_proc->Margin = System::Windows::Forms::Padding(4);
			this->panel_proc->Name = L"panel_proc";
			this->panel_proc->Size = System::Drawing::Size(548, 286);
			this->panel_proc->TabIndex = 3;
			// 
			// btn_proc1
			// 
			this->btn_proc1->Location = System::Drawing::Point(13, 336);
			this->btn_proc1->Margin = System::Windows::Forms::Padding(4);
			this->btn_proc1->Name = L"btn_proc1";
			this->btn_proc1->Size = System::Drawing::Size(560, 38);
			this->btn_proc1->TabIndex = 28;
			this->btn_proc1->Text = L"Run";
			this->btn_proc1->UseVisualStyleBackColor = true;
			this->btn_proc1->Click += gcnew System::EventHandler(this, &SetPatternForm::btn_proc1_Click);
			// 
			// btn_initial
			// 
			this->btn_initial->Location = System::Drawing::Point(710, 285);
			this->btn_initial->Margin = System::Windows::Forms::Padding(4);
			this->btn_initial->Name = L"btn_initial";
			this->btn_initial->Size = System::Drawing::Size(112, 42);
			this->btn_initial->TabIndex = 24;
			this->btn_initial->Text = L"Initial";
			this->btn_initial->UseVisualStyleBackColor = true;
			this->btn_initial->Click += gcnew System::EventHandler(this, &SetPatternForm::btn_initial_Click);
			// 
			// btn_genModel
			// 
			this->btn_genModel->Location = System::Drawing::Point(589, 285);
			this->btn_genModel->Margin = System::Windows::Forms::Padding(4);
			this->btn_genModel->Name = L"btn_genModel";
			this->btn_genModel->Size = System::Drawing::Size(115, 42);
			this->btn_genModel->TabIndex = 25;
			this->btn_genModel->Text = L"CreateModel";
			this->btn_genModel->UseVisualStyleBackColor = true;
			this->btn_genModel->Click += gcnew System::EventHandler(this, &SetPatternForm::btn_genModel_Click);
			// 
			// btn_loadModel
			// 
			this->btn_loadModel->Location = System::Drawing::Point(710, 335);
			this->btn_loadModel->Margin = System::Windows::Forms::Padding(4);
			this->btn_loadModel->Name = L"btn_loadModel";
			this->btn_loadModel->Size = System::Drawing::Size(112, 42);
			this->btn_loadModel->TabIndex = 26;
			this->btn_loadModel->Text = L"LoadModel";
			this->btn_loadModel->UseVisualStyleBackColor = true;
			this->btn_loadModel->Click += gcnew System::EventHandler(this, &SetPatternForm::btn_loadModel_Click);
			// 
			// panel_model
			// 
			this->panel_model->Location = System::Drawing::Point(596, 50);
			this->panel_model->Margin = System::Windows::Forms::Padding(4);
			this->panel_model->Name = L"panel_model";
			this->panel_model->Size = System::Drawing::Size(212, 212);
			this->panel_model->TabIndex = 23;
			// 
			// btn_SaveModel
			// 
			this->btn_SaveModel->Location = System::Drawing::Point(589, 335);
			this->btn_SaveModel->Margin = System::Windows::Forms::Padding(4);
			this->btn_SaveModel->Name = L"btn_SaveModel";
			this->btn_SaveModel->Size = System::Drawing::Size(115, 42);
			this->btn_SaveModel->TabIndex = 27;
			this->btn_SaveModel->Text = L"SaveModel";
			this->btn_SaveModel->UseVisualStyleBackColor = true;
			this->btn_SaveModel->Click += gcnew System::EventHandler(this, &SetPatternForm::btn_SaveModel_Click);
			// 
			// richTextBox1
			// 
			this->richTextBox1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->richTextBox1->Location = System::Drawing::Point(12, 380);
			this->richTextBox1->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(564, 153);
			this->richTextBox1->TabIndex = 31;
			this->richTextBox1->Text = L"";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"�з���", 13.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->label1->Location = System::Drawing::Point(613, 434);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(179, 24);
			this->label1->TabIndex = 32;
			this->label1->Text = L"SetMode:2DCam";
			// 
			// SetPatternForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(849, 546);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->richTextBox1);
			this->Controls->Add(this->TabControl);
			this->Controls->Add(this->btn_proc1);
			this->Controls->Add(this->btn_initial);
			this->Controls->Add(this->btn_genModel);
			this->Controls->Add(this->btn_loadModel);
			this->Controls->Add(this->panel_model);
			this->Controls->Add(this->btn_SaveModel);
			this->Name = L"SetPatternForm";
			this->Text = L"SetPatternForm";
			this->TopMost = true;
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &SetPatternForm::SetPatternForm_FormClosing);
			this->TabControl->ResumeLayout(false);
			this->tab_src->ResumeLayout(false);
			this->tab_proc->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	void SetInitialState(bool state)
	{
		this->is_initial = state;
		this->btn_initial->Enabled = !state;
	}
	private: System::Void btn_genModel_Click(System::Object^ sender, System::EventArgs^ e) 
	{
		MIL_ID Image = M_NULL, GrayImage = M_NULL;
		MIL_INT imageW, imageH, imageBand;

		Image = milDisplaySrc->Image;

		MbufInquire(Image, M_SIZE_X, &imageW);
		MbufInquire(Image, M_SIZE_Y, &imageH);
		MbufInquire(Image, M_SIZE_BAND, &imageBand);

		MbufAlloc2d(this->systemObj->MilSystem, imageW, imageH,
			8 + M_UNSIGNED, M_IMAGE + M_PROC + M_DISP, &GrayImage);
		if (imageBand > 1)
		{
			MimConvert(Image, GrayImage, M_RGB_TO_Y);
		}
		else
		{
			MbufCopy(Image, GrayImage);
		}

		if (this->MilModelImage)
		{
			MbufFree(this->MilModelImage);
			MilModelImage = M_NULL;
		}
		this->MilModelImage = MbufAlloc2d(this->systemObj->MilSystem, MbufInquire(Image, M_SIZE_X, M_NULL),
			MbufInquire(Image, M_SIZE_Y, M_NULL),
			8 + M_UNSIGNED, M_IMAGE + M_PROC + M_DISP, M_NULL);
		MbufCopy(GrayImage, this->MilModelImage);

		milDisplayModel->Image = this->MilModelImage;
		MbufFree(Image);
		MbufFree(GrayImage);
		SetInitialState(false);
	}
	private: System::Void btn_initial_Click(System::Object^ sender, System::EventArgs^ e) 
	{
		if (this->MilModelImage)
		{
			if (this->matchfinder != nullptr)
				delete this->matchfinder;

			MatchFinderMode mode = MatchFinderMode::ModeFinder;

			//modelFinder check imageSize 16~4096
			MIL_INT imageW, imageH, imageBand;
			MbufInquire(this->MilModelImage, M_SIZE_X, &imageW);
			MbufInquire(this->MilModelImage, M_SIZE_Y, &imageH);
			if (imageW > 4096 || imageW < 16 || imageH>4096 || imageH < 16)//error
			{
				MessageBox::Show(String::Format("GoldenSize Error�GRange 16~4096\nWidth:{0},Height:{1}", imageW, imageH));
				return;
			}

			Stopwatch^ watch = gcnew Stopwatch();
			watch->Restart();
			this->matchfinder = gcnew MatchFinder(this->systemObj->MilSystem, this->MilModelImage, mode);
			this->matchfinder->Preprocess();
			watch->Stop();

			richTextBox1->Clear();
			richTextBox1->Text = richTextBox1->Text + "Initail Time�G" + watch->ElapsedMilliseconds.ToString() + " ms" + Environment::NewLine;
			SetInitialState(true);
		}
		else
		{
			MessageBox::Show("Please Set Golden Image");
		}
	}
	private: System::Void btn_SaveModel_Click(System::Object^ sender, System::EventArgs^ e)
	{
		try
		{
			String^ path = systemObj->aoiConfig->Golden2DImagePath;
			if (_isAtizCam)
			{
				path = systemObj->aoiConfig->Golden3DImagePath;
			}
			if (this->MilModelImage)
			{
				pin_ptr<const wchar_t> wch = PtrToStringChars(path);
				MbufSave(wch, this->MilModelImage);
				IsSaved = true;
				MessageBox::Show("�x�s���\");
			}
		}
		catch (Exception^ ex)
		{
			throw ex;
		}
		finally
		{
		}

	}
	private: System::Void btn_loadModel_Click(System::Object^ sender, System::EventArgs^ e) 
	{
		try
		{
			String^ path = systemObj->aoiConfig->Golden2DImagePath;
			if (_isAtizCam)
			{
				path = systemObj->aoiConfig->Golden3DImagePath;
			}
			if (!File::Exists(path))
			{
				MessageBox::Show(path + "���s�b");
				return;
			}

			MIL_ID temp;
			//	Free Image Buff
			if (this->MilModelImage)
			{
				MbufFree(this->MilModelImage);
				this->MilModelImage = M_NULL;
			}
			//	Allocate and Load Image
			String^ ImgPath;
			MIL_INT ImgSizeX;
			MIL_INT ImgSizeY;
			MIL_INT ImgBand;

			ImgPath = path;
			pin_ptr<const wchar_t> wch = PtrToStringChars(ImgPath);
			MbufRestoreW(wch, this->systemObj->MilSystem, &temp);

			MbufInquire(temp, M_SIZE_BAND, &ImgBand);
			MbufInquire(temp, M_SIZE_X, &ImgSizeX);
			MbufInquire(temp, M_SIZE_Y, &ImgSizeY);

			this->MilModelImage = MbufAlloc2d(this->systemObj->MilSystem,
				ImgSizeX,
				ImgSizeY,
				8 + M_UNSIGNED,
				M_IMAGE + M_PROC + M_DISP,
				M_NULL);

			if (ImgBand == 1)
			{
				MbufCopy(temp, this->MilModelImage);
			}
			else if (ImgBand == 3)
			{
				MimConvert(temp, this->MilModelImage, M_RGB_TO_Y);
			}
			else
			{
				throw gcnew Exception(String::Format("Unknow Image Band.[{0}]", ImgBand));
			}
			MbufFree(temp);

			milDisplayModel->Image = this->MilModelImage;
			SetInitialState(false);
		}
		catch (Exception^ ex)
		{
			throw ex;
		}
		finally
		{
		}
	}
private: System::Void btn_proc1_Click(System::Object^ sender, System::EventArgs^ e) 
{
	if (!this->is_initial)
	{
		MessageBox::Show("Please Initial the Difference");
		return;
	}
	MIL_ID Image = M_NULL, GrayImage = M_NULL;
	MIL_INT imageW, imageH, imageBand;

	Image = milDisplaySrc->Image;

	MbufInquire(Image, M_SIZE_X, &imageW);
	MbufInquire(Image, M_SIZE_Y, &imageH);
	MbufInquire(Image, M_SIZE_BAND, &imageBand);

	MbufAlloc2d(this->systemObj->MilSystem, imageW, imageH,
		8 + M_UNSIGNED, M_IMAGE + M_PROC + M_DISP, &GrayImage);
	if (imageBand > 1)
	{
		MimConvert(Image, GrayImage, M_RGB_TO_Y);
	}
	else
	{
		MbufCopy(Image, GrayImage);
	}
	MgraClear(M_DEFAULT, this->Mil_GraphicList);
	milDisplayProc->GraphicList = this->Mil_GraphicList;


	Stopwatch^ watch = gcnew Stopwatch();
	watch->Restart();

	matchfinder->Calculate(GrayImage, this->Mil_GraphicList);

	watch->Stop();

	bool match = matchfinder->GetResult(MatchFinderResult::MatchResult);
	double score = matchfinder->GetResult(MatchFinderResult::Score);
	double angle = matchfinder->GetResult(MatchFinderResult::Angle);
	double posx = matchfinder->GetResult(MatchFinderResult::PosX);
	double posy = matchfinder->GetResult(MatchFinderResult::PosY);

	richTextBox1->Clear();
	richTextBox1->Text = richTextBox1->Text + "match�G" + match.ToString() + Environment::NewLine;
	richTextBox1->Text = richTextBox1->Text + "score�G" + score.ToString() + Environment::NewLine;
	richTextBox1->Text = richTextBox1->Text + "angle�G" + angle.ToString() + Environment::NewLine;
	richTextBox1->Text = richTextBox1->Text + "PosX�G" + posx.ToString() + Environment::NewLine;
	richTextBox1->Text = richTextBox1->Text + "PosY�G" + posy.ToString() + Environment::NewLine;
	richTextBox1->Text = richTextBox1->Text + Environment::NewLine + Environment::NewLine + Environment::NewLine +
		"Calculate Time�G" + watch->ElapsedMilliseconds.ToString() + " ms" + Environment::NewLine;

	milDisplayProc->Image = GrayImage;
	this->TabControl->SelectedIndex = 1;
	MbufFree(Image);
	MbufFree(GrayImage);
}
private: System::Void SetPatternForm_FormClosing(System::Object^ sender, System::Windows::Forms::FormClosingEventArgs^ e) 
{
	if (this->matchfinder != nullptr)
		delete this->matchfinder;

	if (this->MilModelImage)
	{
		MbufFree(MilModelImage);
	}
	if (milDisplaySrc)
	{
		delete milDisplaySrc;
	}
	if (milDisplayModel)
	{
		delete milDisplayModel;
	}
	if (milDisplayProc)
	{
		delete milDisplayProc;
	}

	if (Mil_GraphicList)
	{
		MgraFree(Mil_GraphicList);
	}
}
};
}

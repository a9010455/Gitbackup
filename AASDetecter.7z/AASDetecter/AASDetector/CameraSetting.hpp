﻿#pragma once
#include "BaslerCamera.hpp"
#include "SystemObj.hpp"
#include "Mil.h"
#include "MatchFinder.h"
#include "AtilzCam.hpp"
#include "SetPatternForm.hpp"
	

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::Drawing::Imaging;
using namespace System::Collections::Generic;
using namespace System::Diagnostics;
using namespace System::IO;
using namespace MILBaseTool;


namespace AASDetector {

	enum Camera_UI_STATE
	{
		INITIAL,
		CAM_OPEN,
		CAM_COMTINUIOUS
	};

	/// <summary>
	/// CameraSetting 的摘要
	/// </summary>
	public ref class CameraSetting : public System::Windows::Forms::Form
	{

	private: System::Windows::Forms::ComboBox^ cbx_cameraList;
	private: System::Windows::Forms::Button^ btn_ContinuousShot;
	private: System::Windows::Forms::Button^ btn_CameraStop;
	private: System::Windows::Forms::Button^ btn_OneShot;
	private: System::Windows::Forms::Button^ btn_CameraOpen;
	private: System::Windows::Forms::Button^ btn_CameraClose;
	private: System::Windows::Forms::RichTextBox^ rtb_result1;

	private: System::Windows::Forms::Panel^ panel_model;
	private: System::Windows::Forms::Button^ btn_load_image;
	private: System::Windows::Forms::Panel^ panel_Source;
	private: System::Windows::Forms::Button^ btn_3dCamCapture;
	private: System::Windows::Forms::Panel^ panel_3d;
	private: System::Windows::Forms::Button^ btn_image2DSet;
	private: System::Windows::Forms::Button^ btn_image3DSet;
	private: System::Windows::Forms::Button^ btn_proc1;
	private: System::Windows::Forms::Panel^ panel_model3D;

	private: System::Windows::Forms::Button^ btn_proc2;
	private: System::Windows::Forms::Button^ btn_System_initail;
	private: System::Windows::Forms::Button^ btn_System_free;
	private: System::Windows::Forms::RichTextBox^ richTextBox_log;
	private: System::Windows::Forms::PropertyGrid^ propertyGridConfig;
	private: System::Windows::Forms::RichTextBox^ rtb_result2;

	protected:

	protected:

	private:
		/// <summary>
		/// 設計工具所需的變數。
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
		/// 這個方法的內容。
		/// </summary>
		void InitializeComponent(void)
		{
			this->cbx_cameraList = (gcnew System::Windows::Forms::ComboBox());
			this->btn_ContinuousShot = (gcnew System::Windows::Forms::Button());
			this->btn_CameraStop = (gcnew System::Windows::Forms::Button());
			this->btn_OneShot = (gcnew System::Windows::Forms::Button());
			this->btn_CameraOpen = (gcnew System::Windows::Forms::Button());
			this->btn_CameraClose = (gcnew System::Windows::Forms::Button());
			this->rtb_result1 = (gcnew System::Windows::Forms::RichTextBox());
			this->panel_model = (gcnew System::Windows::Forms::Panel());
			this->btn_load_image = (gcnew System::Windows::Forms::Button());
			this->panel_Source = (gcnew System::Windows::Forms::Panel());
			this->btn_3dCamCapture = (gcnew System::Windows::Forms::Button());
			this->panel_3d = (gcnew System::Windows::Forms::Panel());
			this->btn_image2DSet = (gcnew System::Windows::Forms::Button());
			this->btn_image3DSet = (gcnew System::Windows::Forms::Button());
			this->btn_proc1 = (gcnew System::Windows::Forms::Button());
			this->panel_model3D = (gcnew System::Windows::Forms::Panel());
			this->btn_proc2 = (gcnew System::Windows::Forms::Button());
			this->btn_System_initail = (gcnew System::Windows::Forms::Button());
			this->btn_System_free = (gcnew System::Windows::Forms::Button());
			this->richTextBox_log = (gcnew System::Windows::Forms::RichTextBox());
			this->propertyGridConfig = (gcnew System::Windows::Forms::PropertyGrid());
			this->rtb_result2 = (gcnew System::Windows::Forms::RichTextBox());
			this->SuspendLayout();
			// 
			// cbx_cameraList
			// 
			this->cbx_cameraList->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->cbx_cameraList->FormattingEnabled = true;
			this->cbx_cameraList->Location = System::Drawing::Point(9, 52);
			this->cbx_cameraList->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->cbx_cameraList->Name = L"cbx_cameraList";
			this->cbx_cameraList->Size = System::Drawing::Size(201, 23);
			this->cbx_cameraList->TabIndex = 0;
			// 
			// btn_ContinuousShot
			// 
			this->btn_ContinuousShot->Location = System::Drawing::Point(40, 200);
			this->btn_ContinuousShot->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->btn_ContinuousShot->Name = L"btn_ContinuousShot";
			this->btn_ContinuousShot->Size = System::Drawing::Size(133, 56);
			this->btn_ContinuousShot->TabIndex = 2;
			this->btn_ContinuousShot->Text = L"Start";
			this->btn_ContinuousShot->UseVisualStyleBackColor = true;
			this->btn_ContinuousShot->Click += gcnew System::EventHandler(this, &CameraSetting::btn_ContinuousShot_Click);
			// 
			// btn_CameraStop
			// 
			this->btn_CameraStop->Location = System::Drawing::Point(40, 262);
			this->btn_CameraStop->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->btn_CameraStop->Name = L"btn_CameraStop";
			this->btn_CameraStop->Size = System::Drawing::Size(133, 56);
			this->btn_CameraStop->TabIndex = 2;
			this->btn_CameraStop->Text = L"Stop";
			this->btn_CameraStop->UseVisualStyleBackColor = true;
			this->btn_CameraStop->Click += gcnew System::EventHandler(this, &CameraSetting::btn_CameraStop_Click);
			// 
			// btn_OneShot
			// 
			this->btn_OneShot->Location = System::Drawing::Point(40, 138);
			this->btn_OneShot->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->btn_OneShot->Name = L"btn_OneShot";
			this->btn_OneShot->Size = System::Drawing::Size(133, 56);
			this->btn_OneShot->TabIndex = 2;
			this->btn_OneShot->Text = L"OneShot";
			this->btn_OneShot->UseVisualStyleBackColor = true;
			this->btn_OneShot->Click += gcnew System::EventHandler(this, &CameraSetting::btn_OneShot_Click);
			// 
			// btn_CameraOpen
			// 
			this->btn_CameraOpen->Location = System::Drawing::Point(40, 81);
			this->btn_CameraOpen->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->btn_CameraOpen->Name = L"btn_CameraOpen";
			this->btn_CameraOpen->Size = System::Drawing::Size(133, 51);
			this->btn_CameraOpen->TabIndex = 3;
			this->btn_CameraOpen->Text = L"Open";
			this->btn_CameraOpen->UseVisualStyleBackColor = true;
			this->btn_CameraOpen->Click += gcnew System::EventHandler(this, &CameraSetting::btn_CameraOpen_Click);
			// 
			// btn_CameraClose
			// 
			this->btn_CameraClose->Location = System::Drawing::Point(40, 324);
			this->btn_CameraClose->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->btn_CameraClose->Name = L"btn_CameraClose";
			this->btn_CameraClose->Size = System::Drawing::Size(133, 56);
			this->btn_CameraClose->TabIndex = 2;
			this->btn_CameraClose->Text = L"Close";
			this->btn_CameraClose->UseVisualStyleBackColor = true;
			this->btn_CameraClose->Click += gcnew System::EventHandler(this, &CameraSetting::btn_CameraClose_Click);
			// 
			// rtb_result1
			// 
			this->rtb_result1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->rtb_result1->Location = System::Drawing::Point(904, 226);
			this->rtb_result1->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->rtb_result1->Name = L"rtb_result1";
			this->rtb_result1->Size = System::Drawing::Size(242, 115);
			this->rtb_result1->TabIndex = 6;
			this->rtb_result1->Text = L"";
			// 
			// panel_model
			// 
			this->panel_model->Location = System::Drawing::Point(820, 6);
			this->panel_model->Margin = System::Windows::Forms::Padding(4);
			this->panel_model->Name = L"panel_model";
			this->panel_model->Size = System::Drawing::Size(212, 212);
			this->panel_model->TabIndex = 15;
			// 
			// btn_load_image
			// 
			this->btn_load_image->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->btn_load_image->Location = System::Drawing::Point(264, 333);
			this->btn_load_image->Margin = System::Windows::Forms::Padding(4);
			this->btn_load_image->Name = L"btn_load_image";
			this->btn_load_image->Size = System::Drawing::Size(548, 38);
			this->btn_load_image->TabIndex = 21;
			this->btn_load_image->Text = L"Load";
			this->btn_load_image->UseVisualStyleBackColor = true;
			this->btn_load_image->Click += gcnew System::EventHandler(this, &CameraSetting::btn_load_image_Click);
			// 
			// panel_Source
			// 
			this->panel_Source->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel_Source->Location = System::Drawing::Point(264, 43);
			this->panel_Source->Margin = System::Windows::Forms::Padding(4);
			this->panel_Source->Name = L"panel_Source";
			this->panel_Source->Size = System::Drawing::Size(548, 288);
			this->panel_Source->TabIndex = 2;
			// 
			// btn_3dCamCapture
			// 
			this->btn_3dCamCapture->Location = System::Drawing::Point(264, 413);
			this->btn_3dCamCapture->Name = L"btn_3dCamCapture";
			this->btn_3dCamCapture->Size = System::Drawing::Size(133, 40);
			this->btn_3dCamCapture->TabIndex = 23;
			this->btn_3dCamCapture->Text = L"3D Capture";
			this->btn_3dCamCapture->UseVisualStyleBackColor = true;
			this->btn_3dCamCapture->Click += gcnew System::EventHandler(this, &CameraSetting::btn_3dCamCapture_Click);
			// 
			// panel_3d
			// 
			this->panel_3d->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->panel_3d->Location = System::Drawing::Point(264, 458);
			this->panel_3d->Margin = System::Windows::Forms::Padding(4);
			this->panel_3d->Name = L"panel_3d";
			this->panel_3d->Size = System::Drawing::Size(548, 288);
			this->panel_3d->TabIndex = 24;
			// 
			// btn_image2DSet
			// 
			this->btn_image2DSet->Location = System::Drawing::Point(179, 84);
			this->btn_image2DSet->Name = L"btn_image2DSet";
			this->btn_image2DSet->Size = System::Drawing::Size(45, 48);
			this->btn_image2DSet->TabIndex = 26;
			this->btn_image2DSet->Text = L"Set";
			this->btn_image2DSet->UseVisualStyleBackColor = true;
			this->btn_image2DSet->Click += gcnew System::EventHandler(this, &CameraSetting::btn_image2DSet_Click);
			// 
			// btn_image3DSet
			// 
			this->btn_image3DSet->Location = System::Drawing::Point(403, 415);
			this->btn_image3DSet->Name = L"btn_image3DSet";
			this->btn_image3DSet->Size = System::Drawing::Size(45, 38);
			this->btn_image3DSet->TabIndex = 26;
			this->btn_image3DSet->Text = L"Set";
			this->btn_image3DSet->UseVisualStyleBackColor = true;
			this->btn_image3DSet->Click += gcnew System::EventHandler(this, &CameraSetting::btn_image3DSet_Click);
			// 
			// btn_proc1
			// 
			this->btn_proc1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->btn_proc1->Location = System::Drawing::Point(820, 226);
			this->btn_proc1->Margin = System::Windows::Forms::Padding(4);
			this->btn_proc1->Name = L"btn_proc1";
			this->btn_proc1->Size = System::Drawing::Size(77, 56);
			this->btn_proc1->TabIndex = 20;
			this->btn_proc1->Text = L"Run";
			this->btn_proc1->UseVisualStyleBackColor = true;
			this->btn_proc1->Click += gcnew System::EventHandler(this, &CameraSetting::btn_proc1_Click);
			// 
			// panel_model3D
			// 
			this->panel_model3D->Location = System::Drawing::Point(820, 382);
			this->panel_model3D->Margin = System::Windows::Forms::Padding(4);
			this->panel_model3D->Name = L"panel_model3D";
			this->panel_model3D->Size = System::Drawing::Size(212, 212);
			this->panel_model3D->TabIndex = 15;
			// 
			// btn_proc2
			// 
			this->btn_proc2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->btn_proc2->Location = System::Drawing::Point(820, 631);
			this->btn_proc2->Margin = System::Windows::Forms::Padding(4);
			this->btn_proc2->Name = L"btn_proc2";
			this->btn_proc2->Size = System::Drawing::Size(77, 56);
			this->btn_proc2->TabIndex = 20;
			this->btn_proc2->Text = L"Run";
			this->btn_proc2->UseVisualStyleBackColor = true;
			this->btn_proc2->Click += gcnew System::EventHandler(this, &CameraSetting::btn_proc2_Click);
			// 
			// btn_System_initail
			// 
			this->btn_System_initail->Location = System::Drawing::Point(15, 6);
			this->btn_System_initail->Name = L"btn_System_initail";
			this->btn_System_initail->Size = System::Drawing::Size(84, 41);
			this->btn_System_initail->TabIndex = 27;
			this->btn_System_initail->Text = L"System Initail";
			this->btn_System_initail->UseVisualStyleBackColor = true;
			this->btn_System_initail->Click += gcnew System::EventHandler(this, &CameraSetting::btn_System_initail_Click);
			// 
			// btn_System_free
			// 
			this->btn_System_free->Location = System::Drawing::Point(126, 6);
			this->btn_System_free->Name = L"btn_System_free";
			this->btn_System_free->Size = System::Drawing::Size(84, 41);
			this->btn_System_free->TabIndex = 27;
			this->btn_System_free->Text = L"System Free";
			this->btn_System_free->UseVisualStyleBackColor = true;
			this->btn_System_free->Click += gcnew System::EventHandler(this, &CameraSetting::btn_System_free_Click);
			// 
			// richTextBox_log
			// 
			this->richTextBox_log->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->richTextBox_log->Location = System::Drawing::Point(9, 461);
			this->richTextBox_log->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->richTextBox_log->Name = L"richTextBox_log";
			this->richTextBox_log->Size = System::Drawing::Size(248, 285);
			this->richTextBox_log->TabIndex = 28;
			this->richTextBox_log->Text = L"";
			// 
			// propertyGridConfig
			// 
			this->propertyGridConfig->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->propertyGridConfig->Location = System::Drawing::Point(1152, 47);
			this->propertyGridConfig->Name = L"propertyGridConfig";
			this->propertyGridConfig->Size = System::Drawing::Size(389, 416);
			this->propertyGridConfig->TabIndex = 29;
			// 
			// rtb_result2
			// 
			this->rtb_result2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->rtb_result2->Location = System::Drawing::Point(904, 631);
			this->rtb_result2->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->rtb_result2->Name = L"rtb_result2";
			this->rtb_result2->Size = System::Drawing::Size(242, 115);
			this->rtb_result2->TabIndex = 6;
			this->rtb_result2->Text = L"";
			// 
			// CameraSetting
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1643, 754);
			this->Controls->Add(this->propertyGridConfig);
			this->Controls->Add(this->richTextBox_log);
			this->Controls->Add(this->panel_Source);
			this->Controls->Add(this->btn_System_free);
			this->Controls->Add(this->btn_System_initail);
			this->Controls->Add(this->btn_image3DSet);
			this->Controls->Add(this->btn_image2DSet);
			this->Controls->Add(this->panel_3d);
			this->Controls->Add(this->btn_3dCamCapture);
			this->Controls->Add(this->btn_load_image);
			this->Controls->Add(this->btn_proc2);
			this->Controls->Add(this->btn_proc1);
			this->Controls->Add(this->panel_model3D);
			this->Controls->Add(this->panel_model);
			this->Controls->Add(this->rtb_result2);
			this->Controls->Add(this->rtb_result1);
			this->Controls->Add(this->btn_CameraOpen);
			this->Controls->Add(this->btn_CameraClose);
			this->Controls->Add(this->btn_CameraStop);
			this->Controls->Add(this->btn_OneShot);
			this->Controls->Add(this->btn_ContinuousShot);
			this->Controls->Add(this->cbx_cameraList);
			this->Margin = System::Windows::Forms::Padding(3, 2, 3, 2);
			this->Name = L"CameraSetting";
			this->Text = L"AAS";
			this->ResumeLayout(false);

		}
#pragma endregion

	private : 
		delegate void UpdatePbxCallBack(ImageData^ bmp , MILDisplay^ box);
		void UpdatePbx(ImageData^ bmp, MILDisplay^ box)
		{
			if (this->InvokeRequired)
			{
				UpdatePbxCallBack^ myUpdate = gcnew UpdatePbxCallBack(this,&CameraSetting::UpdatePbx);
				this->Invoke(myUpdate, bmp, box);
			}
			else
			{
				box->Image = bmp->image;
			}
		}

		delegate void UpdatePbxMILCallBack(MIL_ID image, MILDisplay^ box);
		void UpdatePbxMIL(MIL_ID image, MILDisplay^ box)
		{
			if (this->InvokeRequired)
			{
				UpdatePbxMILCallBack^ myUpdate = gcnew UpdatePbxMILCallBack(this, &CameraSetting::UpdatePbxMIL);
				this->Invoke(myUpdate, image, box);
			}
			else
			{
				box->Image = image;
			}
		}

	private:
		BaslerCamera^ basler;
		MILDisplay^ milDisplaySrc;
		MILDisplay^ milDisplayModel2D;

		MILDisplay^ milDisplay3DSource;
		MILDisplay^ milDisplayModel3D;
		SystemObj^ systemObj = gcnew SystemObj();
		MIL_ID Mil_GraphicList2D = M_NULL;
		MIL_ID Mil_GraphicList3D = M_NULL;
		MatchFinder^ matchfinder2D;
		MatchFinder^ matchfinder3D;
		bool is_AOI_initial = false;
		bool is_Capture_3D = false;
		AtilzCam^ cam3d = nullptr;

	public:
		CameraSetting()
		{
			InitializeComponent();
			UpdateDeviceList();
			SettingUi(Camera_UI_STATE::INITIAL);

			systemObj->AllocateSystem();
			systemObj->sysLoger->SetTextBox(this->richTextBox_log);

			systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
			systemObj->sysLoger->Write("[CameraSetting]--Form Opening");

			cam3d = gcnew AtilzCam(systemObj->MilSystem);
			bool state = cam3d->Initail();
			systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
			systemObj->sysLoger->Write("[CameraSetting]--3D Camera Initial:," + state);

			milDisplaySrc = gcnew MILDisplay(panel_Source);
			milDisplaySrc->MilSystem = this->systemObj->MilSystem;
			milDisplaySrc->SupportROIMeun = true;

			milDisplayModel2D = gcnew MILDisplay(panel_model);
			milDisplayModel2D->MilSystem = this->systemObj->MilSystem;

			this->Mil_GraphicList2D = MgraAllocList(this->systemObj->MilSystem, M_DEFAULT, M_NULL);
			
			milDisplay3DSource = gcnew MILDisplay(panel_3d);
			milDisplay3DSource->MilSystem = this->systemObj->MilSystem;
			milDisplay3DSource->SupportROIMeun = true;

			milDisplayModel3D = gcnew MILDisplay(panel_model3D);
			milDisplayModel3D->MilSystem = this->systemObj->MilSystem;

			this->Mil_GraphicList3D = MgraAllocList(this->systemObj->MilSystem, M_DEFAULT, M_NULL);
			InitialAOISystem();
			propertyGridConfig->SelectedObject = this->systemObj->aoiConfig;
			PropertyGridSetting();
		}

	protected:
		/// <summary>
		/// 清除任何使用中的資源。
		/// </summary>
		~CameraSetting()
		{
			if (components)
			{
				delete components;
			}
			this->DestroyCamera();
			systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
			systemObj->sysLoger->Write("[CameraSetting]--From Closing");
			if (milDisplaySrc)
			{
				delete milDisplaySrc;
			}
			if (systemObj)
			{
				delete systemObj;
			}
			if (cam3d)
			{
				delete cam3d;
			}
		}
	private:
		void DestroyCamera()
		{
			try
			{
				if (basler != nullptr)
				{
					basler->Close();
					delete basler;
				}
			}
			catch (Exception^ exception)
			{
				Console::WriteLine(exception);
				Console::WriteLine(exception->StackTrace);
			}
		}

	public:
		void UpdateDeviceList()
		{
			try
			{
				this->cbx_cameraList->Items->Clear();
				this->cbx_cameraList->SelectedIndex = -1;
				// Ask the camera finder for a list of camera devices.
				List<ICameraInfo^>^ allCameras = CameraFinder::Enumerate();

				// Loop over all cameras found.
				for (int i = 0; i < allCameras->Count; i++)
				{
					ICameraInfo^ cameraInfo = allCameras[i];
					String ^ tag = cameraInfo[CameraInfoKey::SerialNumber];
					this->cbx_cameraList->Items->Add(tag);
				}

			}
			catch (Exception^ exception)
			{
				Console::WriteLine(exception);
			}
		}

		ref struct SaveInfo
		{
			Bitmap^ bmp;
			String^ Savename;
		};

		const wchar_t* ConvSysStrToWChar(System::String^ Str)
		{
			pin_ptr<const wchar_t> wch = PtrToStringChars(Str);
			return wch;
		}


	private:
		void SettingUi(Camera_UI_STATE state)
		{
			switch (state)
			{
			case Camera_UI_STATE::INITIAL:
				this->cbx_cameraList->Enabled = true;
				this->btn_CameraOpen->Enabled = true;
				this->btn_ContinuousShot->Enabled = false;
				this->btn_OneShot->Enabled = false;
				this->btn_CameraStop->Enabled = false;
				this->btn_CameraClose->Enabled = false;
				break;
			case Camera_UI_STATE::CAM_OPEN:
				this->cbx_cameraList->Enabled = false;
				this->btn_CameraOpen->Enabled = false;
				this->btn_ContinuousShot->Enabled = true;
				this->btn_OneShot->Enabled = true;
				this->btn_CameraStop->Enabled = false;
				this->btn_CameraClose->Enabled = true;
				break;
			case Camera_UI_STATE::CAM_COMTINUIOUS:
				this->cbx_cameraList->Enabled = false;
				this->btn_CameraOpen->Enabled = false;
				this->btn_ContinuousShot->Enabled = false;
				this->btn_OneShot->Enabled = false;
				this->btn_CameraStop->Enabled = true;
				this->btn_CameraClose->Enabled = true;
				break;
			default:
				break;
			}
		}
		void InitialAOISystem()
		{
			try
			{
				if (is_AOI_initial)
				{
					FreeAOISystem();
				}
				MIL_ID temp2D = Load_model(systemObj->aoiConfig->Golden2DImagePath);
				initial_Finder(matchfinder2D, temp2D);
				milDisplayModel2D->Image = temp2D;
				MbufFree(temp2D);

				MIL_ID temp3D = Load_model(systemObj->aoiConfig->Golden3DImagePath);
				initial_Finder(matchfinder3D, temp3D);
				milDisplayModel3D->Image = temp3D;
				MbufFree(temp3D);

				this->is_AOI_initial = true;
				btn_System_initail->Enabled = false;
				btn_System_free->Enabled = true;

				systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
				systemObj->sysLoger->Write("[InitialAOISystem]--AOISystem Initial Success");
			}
			catch (const std::exception&)
			{
				systemObj->sysLoger->SetLevel(LogerLevel::WARNING);
				systemObj->sysLoger->Write("[InitialAOISystem]--AOISystem Initial Fail");
			}

		}

		void FreeAOISystem()
		{
			is_AOI_initial = false;
			delete milDisplayModel2D;
			delete milDisplayModel3D;
			MgraClear(M_DEFAULT, this->Mil_GraphicList2D);
			MgraClear(M_DEFAULT, this->Mil_GraphicList3D);
			btn_System_initail->Enabled = true;
			btn_System_free->Enabled = false;
			systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
			systemObj->sysLoger->Write("[InitialAOISystem]--AOISystem Free Success");
		}
		void PropertyGridSetting()
		{
			for each (Control ^ control in propertyGridConfig->Controls)
			{
				Type^ pType = control->GetType();
				Type^ pType2 = ToolStrip::typeid;
				if (pType == pType2)
				{
					ToolStrip^ toolStrip = (ToolStrip^)control;
					ToolStripButton^ _tsbMode = gcnew System::Windows::Forms::ToolStripButton();
					_tsbMode->CheckOnClick = true;
					_tsbMode->Checked = true;
					//_tsbMode->DisplayStyle = System::Windows::Forms::ToolStripItemDisplayStyle::Image;
					_tsbMode->Name = "btn_Config_Save";
					_tsbMode->Size = System::Drawing::Size(23, 22);
					_tsbMode->Text = "Save";
					_tsbMode->ToolTipText = "Save Mode";
					_tsbMode->Click += gcnew System::EventHandler(this, &CameraSetting::SaveAOIConfig);
					toolStrip->Items->AddRange(gcnew array<System::Windows::Forms::ToolStripItem^,1>{
					  _tsbMode });
				}
			}
		}
		private: System::Void SaveAOIConfig(System::Object^ sender, System::EventArgs^ e)
		{
			systemObj->aoiConfig->Save();
			MessageBox::Show("Save Success");
		}
		void SaveimageAsyn(Bitmap^ image, String^ filename)
		{
			BackgroundWorker^ bgw = gcnew BackgroundWorker();
			bgw->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &CameraSetting::Save_DoWork);
			SaveInfo^ info = gcnew SaveInfo();
			info->bmp = image;
			info->Savename = filename;
			bgw->RunWorkerAsync(info);
		}
		System::Void Save_DoWork(System::Object^ sender, System::ComponentModel::DoWorkEventArgs^ e)
		{
			try
			{
				SaveInfo^ info = (SaveInfo^)e->Argument;
				if (info->bmp != nullptr)
				{
					info->bmp->Save(info->Savename);
					systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
					systemObj->sysLoger->Write("[CameraSetting]--Camera SaveImage," + info->Savename);
				}
				delete info;
			}
			catch (Exception^ ex)
			{
				systemObj->sysLoger->SetLevel(LogerLevel::HIGH);
				systemObj->sysLoger->Write("[CameraSetting]--Camera SaveImage Error," + ex->StackTrace->ToString());
			}

		}

	private: System::Void btn_CameraOpen_Click(System::Object^ sender, System::EventArgs^ e) 
	{
		if (basler != nullptr)
		{
			delete basler;
		}
		try
		{
			ComboBox^ cbx = (ComboBox^)cbx_cameraList;
			int selectIndex = cbx->SelectedIndex;
			if (selectIndex != -1)
			{
				String^ serialnumber = cbx->SelectedItem->ToString();
				basler = gcnew BaslerCamera(systemObj);
				basler->SetPictureBox(panel_Source,milDisplaySrc);
				basler->Open(serialnumber);
				basler->_ImageGrabbed += gcnew ImageGrabbed_Callback(this, &CameraSetting::OnGrabImage);
				SettingUi(Camera_UI_STATE::CAM_OPEN);

				systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
				systemObj->sysLoger->Write("[CameraSetting]--Open Camera," + serialnumber);
			}

		}

		catch (Exception^ exception)
		{
			Console::WriteLine(exception);
			Console::WriteLine(exception->StackTrace);
			this->DestroyCamera();
		}
		finally
		{

		}
	}
	private: System::Void btn_OneShot_Click(System::Object^ sender, System::EventArgs^ e)
	{
		try
		{
			systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
			systemObj->sysLoger->Write("[CameraSetting]--Camera OnShot Start");
			basler->OneShot();
			systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
			systemObj->sysLoger->Write("[CameraSetting]--Camera OnShot Stop");
		}
		catch (Exception^ exception)
		{
			Console::WriteLine(exception);
			Console::WriteLine(exception->StackTrace);
		}
	}

	private: System::Void btn_ContinuousShot_Click(System::Object^ sender, System::EventArgs^ e) 
	{
		try
		{
			basler->ContinuousShot();
			SettingUi(Camera_UI_STATE::CAM_COMTINUIOUS);

			systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
			systemObj->sysLoger->Write("[CameraSetting]--Camera Comtinuious Start");
		}
		catch (Exception^ exception)
		{
			Console::WriteLine(exception);
			Console::WriteLine(exception->StackTrace);
			SettingUi(Camera_UI_STATE::CAM_OPEN);
		}

	}


	void OnGrabImage(ImageData^ e)
	{
		//UpdatePbx(e, milDisplaySrc);
		//milDisplaySrc->Image = e->image;
	}

	private: System::Void btn_CameraStop_Click(System::Object^ sender, System::EventArgs^ e) 
	{
		try
		{
			basler->CameraStop();
			SettingUi(Camera_UI_STATE::CAM_OPEN);

			systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
			systemObj->sysLoger->Write("[CameraSetting]--Camera Stop");
		}
		catch (Exception^ exception)
		{
			Console::WriteLine(exception);
			Console::WriteLine(exception->StackTrace);
			SettingUi(Camera_UI_STATE::INITIAL);
		}
	}

private: 
	System::Void btn_CameraClose_Click(System::Object^ sender, System::EventArgs^ e) 
	{
		try
		{
			if (basler != nullptr)
			{
				basler->CameraStop();
				System::Threading::Thread::Sleep(10);
				delete basler;
			}

			SettingUi(Camera_UI_STATE::INITIAL);
			systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
			systemObj->sysLoger->Write("[CameraSetting]--Camera Close");

		}
		catch (Exception^ exception)
		{
			Console::WriteLine(exception);
			Console::WriteLine(exception->StackTrace);

		}
	}

private:
	void initial_Finder(MatchFinder^ %finder ,MIL_ID model)
{
	try
	{
		if (model)
		{
			if (finder != nullptr)
				delete finder;

			MatchFinderMode mode = MatchFinderMode::ModeFinder;
			//modelFinder check imageSize 16~4096
			MIL_INT imageW, imageH, imageBand;
			MbufInquire(model, M_SIZE_X, &imageW);
			MbufInquire(model, M_SIZE_Y, &imageH);
			if (imageW > 4096 || imageW < 16 || imageH>4096 || imageH < 16)//error
			{
				MessageBox::Show(String::Format("GoldenSize Error：Range 16~4096\nWidth:{0},Height:{1}", imageW, imageH));
				return;
			}
			finder = gcnew MatchFinder(this->systemObj->MilSystem, model, mode);
			finder->Preprocess();
		}
		else
		{
			MessageBox::Show("Please Set Golden Image");
		}
	}
	catch (Exception^ ex)
	{
		throw ex;
	}
}

	MIL_ID Load_model(String^ path)
	{
		try
		{
			MIL_ID temp;
			//	Allocate and Load Image
			String^ ImgPath;
			MIL_INT ImgSizeX;
			MIL_INT ImgSizeY;
			MIL_INT ImgBand;

			ImgPath = path;
			pin_ptr<const wchar_t> wch = PtrToStringChars(ImgPath);
			MbufRestoreW(wch, this->systemObj->MilSystem, &temp);

			MbufInquire(temp, M_SIZE_BAND, &ImgBand);
			MbufInquire(temp, M_SIZE_X, &ImgSizeX);
			MbufInquire(temp, M_SIZE_Y, &ImgSizeY);

			MIL_ID modelImage = MbufAlloc2d(this->systemObj->MilSystem,
				ImgSizeX,
				ImgSizeY,
				8 + M_UNSIGNED,
				M_IMAGE + M_PROC + M_DISP,
				M_NULL);

			if (ImgBand == 1)
			{
				MbufCopy(temp, modelImage);
			}
			else if (ImgBand == 3)
			{
				MimConvert(temp, modelImage, M_RGB_TO_Y);
			}
			else
			{
				throw gcnew Exception(String::Format("Unknow Image Band.[{0}]", ImgBand));
			}
			MbufFree(temp);
			return modelImage;
		}
		catch (Exception^ ex)
		{
			throw ex;
		}
		finally
		{
		}
	}
private: System::Void btn_proc1_Click(System::Object^ sender, System::EventArgs^ e) {
	if (!this->is_AOI_initial)
	{
		MessageBox::Show("Please Initial the AOI system");
		return;
	}
	MIL_ID Image = M_NULL, GrayImage = M_NULL;
	MIL_INT imageW, imageH, imageBand;

	Image = milDisplaySrc->Image;

	MbufInquire(Image, M_SIZE_X, &imageW);
	MbufInquire(Image, M_SIZE_Y, &imageH);
	MbufInquire(Image, M_SIZE_BAND, &imageBand);

	MbufAlloc2d(this->systemObj->MilSystem, imageW, imageH,
		8 + M_UNSIGNED, M_IMAGE + M_PROC + M_DISP, &GrayImage);
	if (imageBand > 1)
	{
		MimConvert(Image, GrayImage, M_RGB_TO_Y);
	}
	else
	{
		MbufCopy(Image, GrayImage);
	}
	MgraClear(M_DEFAULT, this->Mil_GraphicList2D);
	milDisplaySrc->GraphicList = this->Mil_GraphicList2D;


	Stopwatch^ watch = gcnew Stopwatch();
	watch->Restart();

	matchfinder2D->Calculate(GrayImage, this->Mil_GraphicList2D);

	watch->Stop();

	bool match = matchfinder2D->GetResult(MatchFinderResult::MatchResult);
	double score = matchfinder2D->GetResult(MatchFinderResult::Score);
	double angle = matchfinder2D->GetResult(MatchFinderResult::Angle);
	double posx = matchfinder2D->GetResult(MatchFinderResult::PosX);
	double posy = matchfinder2D->GetResult(MatchFinderResult::PosY);


	rtb_result1->Clear();
	rtb_result1->Text = rtb_result1->Text + "match：" + match.ToString() + Environment::NewLine;
	rtb_result1->Text = rtb_result1->Text + "score：" + score.ToString() + Environment::NewLine;
	rtb_result1->Text = rtb_result1->Text + "angle：" + angle.ToString() + Environment::NewLine;
	rtb_result1->Text = rtb_result1->Text + "PosX：" + posx.ToString() + Environment::NewLine;
	rtb_result1->Text = rtb_result1->Text + "PosY：" + posy.ToString() + Environment::NewLine;
	rtb_result1->Text = rtb_result1->Text + Environment::NewLine + Environment::NewLine + Environment::NewLine +
		"Calculate Time：" + watch->ElapsedMilliseconds.ToString() + " ms" + Environment::NewLine;

	MbufFree(Image);
	MbufFree(GrayImage);
}
private: System::Void btn_load_image_Click(System::Object^ sender, System::EventArgs^ e) {
	OpenFileDialog^ obj_OFD = nullptr;
	try
	{
		obj_OFD = gcnew OpenFileDialog();
		obj_OFD->Filter = "Image file (*.jpg;*.bmp;*.png;*.tif)|*.jpg;*.bmp;*.png;*.tif;*.tiff";
		obj_OFD->Multiselect = false;

		if (obj_OFD->ShowDialog() == ::DialogResult::OK)
		{
			MIL_ID Milimage = M_NULL;
			//	Free Image Buff
			if (Milimage)
			{
				MbufFree(Milimage);
				Milimage = M_NULL;
			}
			//	Allocate and Load Image
			String^ ImgPath;
			MIL_INT ImgSizeX;
			MIL_INT ImgSizeY;
			MIL_INT ImgBits;
			MIL_INT ImgSign;
			MIL_INT ImgBand;

			ImgPath = obj_OFD->FileName;

			MbufDiskInquire(ConvSysStrToWChar(ImgPath),
				M_SIZE_X,
				&ImgSizeX);
			MbufDiskInquire(ConvSysStrToWChar(ImgPath),
				M_SIZE_Y,
				&ImgSizeY);
			MbufDiskInquire(ConvSysStrToWChar(ImgPath),
				M_SIZE_BIT,
				&ImgBits);
			MbufDiskInquire(ConvSysStrToWChar(ImgPath),
				M_SIGN,
				&ImgSign);
			MbufDiskInquire(ConvSysStrToWChar(ImgPath),
				M_SIZE_BAND,
				&ImgBand);

			if (ImgBand == 1)
			{
				Milimage = MbufAlloc2d(this->systemObj->MilSystem,
					ImgSizeX,
					ImgSizeY,
					ImgBits + ImgSign,
					M_IMAGE + M_PROC + M_DISP,
					M_NULL);

			}
			else if (ImgBand == 3)
			{
				Milimage = MbufAllocColor(this->systemObj->MilSystem,
					3,
					ImgSizeX,
					ImgSizeY,
					ImgBits + ImgSign,
					M_IMAGE + M_PROC + M_DISP,
					M_NULL);
			}
			else
			{
				throw gcnew Exception(String::Format("Unknow Image Band.[{0}]", ImgBand));
			}

			MbufLoad(ConvSysStrToWChar(ImgPath), Milimage);
			milDisplaySrc->Image = Milimage;
			MbufFree(Milimage);
		}
	}
	catch (Exception^ ex)
	{
		throw ex;
	}
	finally
	{
		if (obj_OFD)
		{
			delete obj_OFD;
			obj_OFD = nullptr;
		}
	}
}
private: System::Void btn_3dCamCapture_Click(System::Object^ sender, System::EventArgs^ e) 
{
	if (is_Capture_3D != true)
	{
		is_Capture_3D = true;
		Task^ tasl=Task::Factory->StartNew(gcnew Action(this, &CameraSetting::Capture3D));
	}
	else
	{
		MessageBox::Show("3D Cam is Catpuring");
	}
}

private: System::Void Capture3D()
{
	systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
	systemObj->sysLoger->Write("[Capture3D]--Start");
	MIL_ID MilDepthMap = cam3d->Capture();
	MIL_ID MilRemapped8BitImage;
	MbufAlloc2d(systemObj->MilSystem,
		MbufInquire(MilDepthMap, M_SIZE_X, M_NULL),
		MbufInquire(MilDepthMap, M_SIZE_Y, M_NULL),
		8, M_IMAGE + M_PROC + M_DISP, &MilRemapped8BitImage);

	MbufClear(MilRemapped8BitImage, 0);

	// Remap 16-bit depth map to 8 bit.   
	MimShift(MilDepthMap, MilRemapped8BitImage, -8);
	UpdatePbxMIL(MilRemapped8BitImage, milDisplay3DSource);
	MbufFree(MilRemapped8BitImage);

	systemObj->sysLoger->SetLevel(LogerLevel::BLUE);
	systemObj->sysLoger->Write("[Capture3D]--Stop");
	is_Capture_3D = false;
}

private: System::Void btn_image2DSet_Click(System::Object^ sender, System::EventArgs^ e) 
{
	if (milDisplaySrc->Image != M_NULL)
	{
		SetPatternForm^ form = gcnew SetPatternForm(milDisplaySrc->Image,systemObj,false);
		form->ShowDialog();
		if (form->IsSaved)
		{
			InitialAOISystem();
		}
	}
}
private: System::Void btn_image3DSet_Click(System::Object^ sender, System::EventArgs^ e) 
{
	if (milDisplay3DSource->Image != M_NULL)
	{
		SetPatternForm^ form = gcnew SetPatternForm(milDisplay3DSource->Image, systemObj,true);
		form->ShowDialog();
		if (form->IsSaved)
		{
			InitialAOISystem();
		}
	}
}
private: System::Void btn_proc2_Click(System::Object^ sender, System::EventArgs^ e) 
{
	if (!this->is_AOI_initial)
	{
		MessageBox::Show("Please Initial the system");
		return;
	}
	MIL_ID Image = M_NULL, GrayImage = M_NULL;
	MIL_INT imageW, imageH, imageBand;

	Image = milDisplay3DSource->Image;

	MbufInquire(Image, M_SIZE_X, &imageW);
	MbufInquire(Image, M_SIZE_Y, &imageH);
	MbufInquire(Image, M_SIZE_BAND, &imageBand);

	MbufAlloc2d(this->systemObj->MilSystem, imageW, imageH,
		8 + M_UNSIGNED, M_IMAGE + M_PROC + M_DISP, &GrayImage);
	if (imageBand > 1)
	{
		MimConvert(Image, GrayImage, M_RGB_TO_Y);
	}
	else
	{
		MbufCopy(Image, GrayImage);
	}
	MgraClear(M_DEFAULT, this->Mil_GraphicList3D);
	milDisplay3DSource->GraphicList = this->Mil_GraphicList3D;

	Stopwatch^ watch = gcnew Stopwatch();
	watch->Restart();

	matchfinder3D->Calculate(GrayImage, this->Mil_GraphicList3D);

	watch->Stop();

	bool match = matchfinder3D->GetResult(MatchFinderResult::MatchResult);
	double score = matchfinder3D->GetResult(MatchFinderResult::Score);
	double angle = matchfinder3D->GetResult(MatchFinderResult::Angle);
	double posx = matchfinder3D->GetResult(MatchFinderResult::PosX);
	double posy = matchfinder3D->GetResult(MatchFinderResult::PosY);

	rtb_result2->Clear();
	rtb_result2->Text = rtb_result2->Text + "match：" + match.ToString() + Environment::NewLine;
	rtb_result2->Text = rtb_result2->Text + "score：" + score.ToString() + Environment::NewLine;
	rtb_result2->Text = rtb_result2->Text + "angle：" + angle.ToString() + Environment::NewLine;
	rtb_result2->Text = rtb_result2->Text + "PosX：" + posx.ToString() + Environment::NewLine;
	rtb_result2->Text = rtb_result2->Text + "PosY：" + posy.ToString() + Environment::NewLine;
	rtb_result2->Text = rtb_result2->Text + Environment::NewLine + Environment::NewLine + Environment::NewLine +
		"Calculate Time：" + watch->ElapsedMilliseconds.ToString() + " ms" + Environment::NewLine;
	MbufFree(Image);
	MbufFree(GrayImage);
}
private: System::Void btn_System_free_Click(System::Object^ sender, System::EventArgs^ e) 
{
	FreeAOISystem();
}
private: System::Void btn_System_initail_Click(System::Object^ sender, System::EventArgs^ e) 
{
	InitialAOISystem();
}
};
}

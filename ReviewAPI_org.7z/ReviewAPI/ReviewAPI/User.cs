﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReviewAPI
{
    public class User
    {
        public string UserId { get; set; }
        public string Product { get; set; }
        public string LastTime { get; set; }
    }
}

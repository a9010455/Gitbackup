﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Web.Http;
using System.Collections;

namespace ReviewAPI
{

    public class UsersController:ApiController
    {
        public string sqlColString;
        public string ConnString;
        public string sqlString;
        public string sqlSecString;
        public SqlCommand cmd;
        public SqlDataReader dr;
        public SqlConnection Conn;
        public SqlConnectionStringBuilder Builder;

        public String GetAddSql(string tbName, string UserID)
        {
            string Id;
            String col;
            ArrayList opTbCol = new ArrayList();
            String sqlPamString;
            try
            {
                ConnectDBInfo();
                Conn.Open();
                if (tbName.Equals("opList")) // For opList insert
                {
                    sqlString = "select column_name from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME ='" + "opList" + "';";
                    cmd = new SqlCommand(sqlString, Conn);
                    dr = cmd.ExecuteReader();
                    col = dr.GetName(0);

                    sqlColString = " IF NOT EXISTS(select * from opList where userid = '" + UserID + "') Insert into opList(\"";
                    sqlPamString = " values('" + UserID + "', "; // +DateTime.Now.Year + "/" + DateTime.Now.Month + "/" + DateTime.Now.Day + "', ";
                    //get all of columns' name in opList
                    while (dr.Read())
                    {
                        for (int i = 0; i < dr.FieldCount; i++)
                        {
                            opTbCol.Add(dr.GetValue(i).ToString());
                        }
                    }
                    //combine SQL cmd
                    for (int i = 0; i < opTbCol.Count; i++)
                    {
                        if (i == 0)
                        {
                            sqlColString += opTbCol[i] + "\" ,";
                        }
                        else if ((i + 1) == opTbCol.Count)
                        {
                            sqlColString += "\"" + opTbCol[i] + "\" )";
                            sqlPamString += "' " + DateTime.Now.Year + "/" + DateTime.Now.Month + "/" + DateTime.Now.Day + "' );"; //" '');";

                        }
                        else
                        {
                            sqlColString += "\"" + opTbCol[i] + "\" ,";
                            sqlPamString += "' " + DateTime.Now.Year + "/" + DateTime.Now.Month + "/" + DateTime.Now.Day + "', "; //"'', "; // +DateTime.Now.Year + "/" + DateTime.Now.Month + "/" + DateTime.Now.Day + "', "; 
                        }
                    }

                    sqlColString = sqlColString + sqlPamString;
                }
            }
            catch (Exception ex)
            {
                Console.Write("Func: GetAddSql, " + "Exception" + ex.GetType().ToString() + " ,tbName:" +tbName + " ,UserID: " +UserID);
            }
            finally
            {
                Conn.Close();
            }

            return sqlColString;
        }

        // ex: /api/Users?Id=1507055&product=L133X1
        public User GetLastTime(string Id, string product) 
        {   
            string exeSqlStr;
            string AddRes;
            bool UsrIDExist = false;
            string colFlag ="";
            string getResult;
            DateTime getTime;
            var usr = new User();
            usr.UserId = Id;
            usr.Product = product;

            try {
                sqlString = "";
                sqlString = " IF EXISTS(SELECT * From opList Where userid =" + Id + ") ";
                sqlString += " SELECT 'T' as RESULT ";
                sqlString += " ELSE SELECT 'F' as RESULT;";
                colFlag = ExeSQLSt(sqlString, "S"); // check column exist or not
                if (colFlag.Equals("F"))
                {
                    UsrIDExist = false;
                    Console.WriteLine("Exception: UserID " + usr.UserId + " not found.");

                    //Add User ID
                    Console.WriteLine("Start Add UserID " + usr.UserId );
                    exeSqlStr = GetAddSql("opList",Id) ;
                    AddRes = ExeSQLSt(sqlColString, "A");
                    Console.WriteLine("End Add UserID " + usr.UserId + " Result: " + AddRes);
                }
                else{
                    UsrIDExist = true;
                }

                sqlString = "";
                sqlString = "IF (SELECT COL_LENGTH('opList', '" + product + "')) IS NOT NULL ";
                sqlString += " SELECT 'T' as RESULT ";
                sqlString += " ELSE SELECT 'F' as RESULT;";
                colFlag = ExeSQLSt(sqlString, "S"); // check column exist or not

                if (colFlag.Equals("T") && UsrIDExist)
                {
                    sqlSecString = " IF EXISTS(SELECT * From opList Where userid =" + Id + ") ";
                    sqlSecString += "  SELECT \"" + product + "\" From opList Where userid=" + Id + " ";
                    sqlSecString += " ELSE SELECT 'NO DATA' as Result ";

                    getResult = ExeSQLSt(sqlSecString, "S"); // get result
                    if (!getResult.ToUpper().Equals("NO DATA"))
                    {
                        getTime = getTime = Convert.ToDateTime(getResult);
                        usr.LastTime = getTime.ToString("yyyy-MM-dd");
                        // Update time
                        colFlag = ExeSQLSt("Update opList Set \"" + product + "\" = GetDate()  Where userid = '" + Id + "' ;", "U");
                    }
                    else {
                        usr.LastTime = getResult;
                    }

                }
                else {
                    usr.LastTime = "No Data";
                }
               

            }catch(Exception ex){
                Console.WriteLine("Func: GetLastTime, " + "Exception" + ex.GetType().ToString() + " ,ID:" + Id + " ,Product: " + product);
            }

            return usr;
        }

        private string ExeSQLSt(string sql, string flag) 
        {
            string res="Fail";
            string col;
            try { 
                ConnectDBInfo();
                Conn.Open(); // connect to DB
                cmd = new SqlCommand(sql, Conn);
                if (flag.ToUpper().Equals("S")) { // search data
                    dr = cmd.ExecuteReader();
                    col = dr.GetName(0);

                    if (dr.Read())
                        res = dr.GetValue(0).ToString();

                }else if(flag.ToUpper().Equals("U")){ // update
                    cmd.ExecuteNonQuery();
                    res = "Finish";
                }
                else if (flag.ToUpper().Equals("A"))
                { // Add
                    cmd.ExecuteNonQuery();
                    res = "Add Finish";
                }
                cmd.Dispose(); //release
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Func: ExeSQLSt, " + "Exception" + ex.GetType().ToString());
            }finally{
                Conn.Close(); // close connection
            }
            return res;
        }

        private void ConnectDBInfo()
        {
            try
            {

                // Setting DB connection info
                Builder = new SqlConnectionStringBuilder();
                Builder.DataSource = "localhost";           //SQL Server IP address,若預設port不同,可以在ip後面用逗號再加port號
                Builder.InitialCatalog = "ReviewInfoDB";    //SQL Server DB name
                Builder.UserID = "sa";                      //SQL Server account
                Builder.Password = "sa";                    //SQL Server pwd

                ConnString = Builder.ConnectionString;
                Conn = new SqlConnection(ConnString);
            }
            catch (Exception ex)
            {
                Console.Write("Func: ConnectDBInfo, " + "Exception" + ex.GetType().ToString());
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmUrRobotDemo
{
    public partial class frmUrRobotDemo : Form
    {
        private DllUrRobot.ClsUrRobotConfig g_ClsUrRobotConfig;
        private DllUrRobot.ClsUrRobotControl g_ClsUrRobotControl;
        private CommonBase.Logger.InfoManagerWinForm g_InfoManager;
        
        public frmUrRobotDemo()
        {
            InitializeComponent();
        }

        private void btnTestJson_Click(object sender, EventArgs e)
        {
            DllUrRobot.ClsTestJson tt = new DllUrRobot.ClsTestJson();

            DllUrRobot.group aa = new DllUrRobot.group(
                "", 0, new double[] { 9.0, 2.1, 3.3 });
            tt.data_list.Add(aa);

            aa = new DllUrRobot.group(
                "", 0, "kkk");
            tt.data_list.Add(aa);

            aa = new DllUrRobot.group(
                "", 0, 0.98);
            tt.data_list.Add(aa);

           string ttJson = tt.ToJsonString();

            System.IO.File.WriteAllText(".\\@tt.json", ttJson);

            DllUrRobot.ClsTestJson ttObject = tt.ToObject(ttJson);

           this.g_InfoManager.HighLight(ttJson);
        }

        private void frmUrRobotDemo_Load(object sender, EventArgs e)
        {
            this.Text = "UrRobotDemo";

            //
            this.g_InfoManager = new CommonBase.Logger.InfoManagerWinForm(
                ".\\Log\\ctrl\\systemlog",
                ".\\Log\\ctrl\\networklog",
                ".\\Log\\ctrl\\warninglog",
                ".\\Log\\ctrl\\errorlog",
                ".\\Log\\ctrl\\debuglog");

            this.g_InfoManager.SetGeneralTextBox(ref this.rtfCtrlSystem);

            //
            string urConfigPath = @".\UrBootConfig.xml";
            try
            {

                this.g_ClsUrRobotConfig = new DllUrRobot.ClsUrRobotConfig();
                if (!System.IO.File.Exists(urConfigPath))
                {
                    this.g_ClsUrRobotConfig.WriteWithoutCrypto(urConfigPath, true);
                }
                else
                {
                    this.g_ClsUrRobotConfig.ReadWithoutCrypto(urConfigPath);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                this.g_ClsUrRobotConfig = new DllUrRobot.ClsUrRobotConfig();
                this.g_ClsUrRobotConfig.WriteWithoutCrypto(urConfigPath, true);
            }

            //
            this.g_ClsUrRobotControl = new DllUrRobot.ClsUrRobotControl(this.g_ClsUrRobotConfig);

            this.g_InfoManager.General("frmUrRobotDemo_Load");
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.Connect())
                {
                    this.btnConnect.Enabled = false;

                    this.btnDisconnect.Enabled = true;
                    this.btnPowerOn.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.Disconnect())
                {
                    this.btnConnect.Enabled = true;

                    this.btnDisconnect.Enabled = false;

                    this.btnPowerOn.Enabled = false;
                    this.btnPowerOff.Enabled = false;
                    this.btnReleaseBreake.Enabled = false;
                    this.btnStop.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnPowerOn_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.PowerOn())
                {
                    this.btnPowerOn.Enabled = false;

                    this.btnPowerOff.Enabled = true;
                    this.btnReleaseBreake.Enabled = true;

                    this.btnStop.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnPowerOff_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.PowerOff())
                {
                    this.btnPowerOff.Enabled = false;

                    this.btnPowerOn.Enabled = true;
                    this.btnReleaseBreake.Enabled = false;
                    this.btnStop.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnReleaseBreake_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.BrakeRelease())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.Stop())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void frmUrRobotDemo_FormClosed(object sender, FormClosedEventArgs e)
        {
            // log
            try
            {
                if (this.g_InfoManager != null)
                {
                    this.g_InfoManager.Dispose();
                    this.g_InfoManager = null;
                }
            }
            catch (Exception ex) 
		    {
                Console.WriteLine(ex.ToString());
            }
        }

        private void btnGetRobotPosition_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.IsConnected())
                {
                    this.nudTCPX.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[0]);
                    this.nudTCPY.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[1]);
                    this.nudTCPZ.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[2]);
                    this.nudTCPrX.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[3]);
                    this.nudTCPrY.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[4]);
                    this.nudTCPrZ.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.TcpPose[5]);
                }
                else
                {
                    MessageBox.Show("Please Connect Robot first!", "Warning");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void btnMoveTcpTest_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.IsConnected())
                {
                    double x = (double)this.nudTCPX.Value;
                    double y = (double)this.nudTCPY.Value;
                    double z = (double)this.nudTCPZ.Value;
                    double rx = (double)this.nudTCPrX.Value;
                    double ry = (double)this.nudTCPrY.Value;
                    double rz = (double)this.nudTCPrZ.Value;

                    double tmpAcc = Convert.ToDouble(this.txtAcc.Text);
                    double tmpSpeed = Convert.ToDouble(this.txtSpeed.Text);
                    double tmpTime = 0;
                    double tmpBlendRadius = 0;

                    this.g_ClsUrRobotControl.MoveL_rv(
                        x, y, z, rx, ry, rz, tmpAcc, tmpSpeed, tmpTime, tmpBlendRadius);
                }
                else
                {
                    MessageBox.Show("Please Connect Robot first!", "Warning");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void btnGetMotorAngle_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.IsConnected())
                {
                    this.nudAngleX.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[0] * 180 / Math.PI);
                    this.nudAngleY.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[1] * 180 / Math.PI);
                    this.nudAngleZ.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[2] * 180 / Math.PI);
                    this.nudAnglerX.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[3] * 180 / Math.PI);
                    this.nudAnglerY.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[4] * 180 / Math.PI);
                    this.nudAnglerZ.Value = Convert.ToDecimal(this.g_ClsUrRobotControl.m_ClsUrStatus.MotorAngle[5] * 180 / Math.PI);
                }
                else
                {
                    MessageBox.Show("Please Connect Robot first!", "Warning");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

        }

        private void btnMoveAngleTest_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsUrRobotControl.IsConnected())
                {
                    double x = (double)this.nudAngleX.Value;
                    double y = (double)this.nudAngleY.Value;
                    double z = (double)this.nudAngleZ.Value;
                    double rx = (double)this.nudAnglerX.Value;
                    double ry = (double)this.nudAnglerY.Value;
                    double rz = (double)this.nudAnglerZ.Value;

                    double tmpAcc = Convert.ToDouble(this.txtAcc.Text);
                    double tmpSpeed = Convert.ToDouble(this.txtSpeed.Text);
                    double tmpBlendRadius = 0;

                    this.g_ClsUrRobotControl.MoveJ(
                        x, y, z, rx, ry, rz, tmpAcc, tmpSpeed, tmpBlendRadius);
                }
                else
                {
                    MessageBox.Show("Please Connect Robot first!", "Warning");
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        bool g_mouseClick = false;
        private void threadMouseClick()
        {
            
        }

        private void btnTcpXYZ_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void btnTcpXYZ_MouseUp(object sender, MouseEventArgs e)
        {

        }

        //



    }
}

import Inference_T
Inference_T.main()
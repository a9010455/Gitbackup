﻿
namespace frmUrRobotDemo
{
    partial class frmUrRobotDemo
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTestJson = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.btnPowerOn = new System.Windows.Forms.Button();
            this.btnPowerOff = new System.Windows.Forms.Button();
            this.btnReleaseBreake = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.rtfCtrlSystem = new System.Windows.Forms.RichTextBox();
            this.btnTcpXp = new System.Windows.Forms.Button();
            this.btnTcpXm = new System.Windows.Forms.Button();
            this.btnTcpYm = new System.Windows.Forms.Button();
            this.btnTcpYp = new System.Windows.Forms.Button();
            this.btnTcpZm = new System.Windows.Forms.Button();
            this.btnTcpZp = new System.Windows.Forms.Button();
            this.btnTcpRzm = new System.Windows.Forms.Button();
            this.btnTcpRzp = new System.Windows.Forms.Button();
            this.btnTcpRym = new System.Windows.Forms.Button();
            this.btnTcpRyp = new System.Windows.Forms.Button();
            this.btnTcpRxm = new System.Windows.Forms.Button();
            this.btnTcpRxp = new System.Windows.Forms.Button();
            this.gbxTcpPosition = new System.Windows.Forms.GroupBox();
            this.btnGetRobotPosition = new System.Windows.Forms.Button();
            this.btnMoveTcpTest = new System.Windows.Forms.Button();
            this.nudTCPrZ = new System.Windows.Forms.NumericUpDown();
            this.nudTCPrY = new System.Windows.Forms.NumericUpDown();
            this.nudTCPrX = new System.Windows.Forms.NumericUpDown();
            this.nudTCPZ = new System.Windows.Forms.NumericUpDown();
            this.nudTCPY = new System.Windows.Forms.NumericUpDown();
            this.nudTCPX = new System.Windows.Forms.NumericUpDown();
            this.lblTpRyTitle = new System.Windows.Forms.Label();
            this.lblTpRzTitle = new System.Windows.Forms.Label();
            this.lblTpYTitle = new System.Windows.Forms.Label();
            this.lblTpRxTitle = new System.Windows.Forms.Label();
            this.lblTpZTitle = new System.Windows.Forms.Label();
            this.lblTpXTitle = new System.Windows.Forms.Label();
            this.gbxAnglePosition = new System.Windows.Forms.GroupBox();
            this.btnGetMotorAngle = new System.Windows.Forms.Button();
            this.btnMoveAngleTest = new System.Windows.Forms.Button();
            this.lblApWrist3Title = new System.Windows.Forms.Label();
            this.lblApWrist2Title = new System.Windows.Forms.Label();
            this.lblApWrist1Title = new System.Windows.Forms.Label();
            this.lblApElbowTitle = new System.Windows.Forms.Label();
            this.lblApShoulderTitle = new System.Windows.Forms.Label();
            this.lblApBaseTitle = new System.Windows.Forms.Label();
            this.nudAnglerZ = new System.Windows.Forms.NumericUpDown();
            this.nudAnglerY = new System.Windows.Forms.NumericUpDown();
            this.nudAnglerX = new System.Windows.Forms.NumericUpDown();
            this.nudAngleZ = new System.Windows.Forms.NumericUpDown();
            this.nudAngleY = new System.Windows.Forms.NumericUpDown();
            this.nudAngleX = new System.Windows.Forms.NumericUpDown();
            this.gbxRobotParams = new System.Windows.Forms.GroupBox();
            this.lblRpAngle = new System.Windows.Forms.Label();
            this.lblRpAngleTitle = new System.Windows.Forms.Label();
            this.lblRpTcp = new System.Windows.Forms.Label();
            this.lblRpTcpTitle = new System.Windows.Forms.Label();
            this.lblRpTitle = new System.Windows.Forms.Label();
            this.lblAccTitle = new System.Windows.Forms.Label();
            this.lblSpeedTitle = new System.Windows.Forms.Label();
            this.txtAcc = new System.Windows.Forms.TextBox();
            this.txtSpeed = new System.Windows.Forms.TextBox();
            this.gbxTcpPosition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPrZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPrY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPrX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPX)).BeginInit();
            this.gbxAnglePosition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnglerZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnglerY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnglerX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngleZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngleY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngleX)).BeginInit();
            this.gbxRobotParams.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTestJson
            // 
            this.btnTestJson.Location = new System.Drawing.Point(602, 13);
            this.btnTestJson.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnTestJson.Name = "btnTestJson";
            this.btnTestJson.Size = new System.Drawing.Size(87, 28);
            this.btnTestJson.TabIndex = 0;
            this.btnTestJson.Text = "TestJson";
            this.btnTestJson.UseVisualStyleBackColor = true;
            this.btnTestJson.Click += new System.EventHandler(this.btnTestJson_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(12, 12);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(100, 50);
            this.btnConnect.TabIndex = 1;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Enabled = false;
            this.btnDisconnect.Location = new System.Drawing.Point(118, 13);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(100, 50);
            this.btnDisconnect.TabIndex = 2;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // btnPowerOn
            // 
            this.btnPowerOn.Enabled = false;
            this.btnPowerOn.Location = new System.Drawing.Point(12, 68);
            this.btnPowerOn.Name = "btnPowerOn";
            this.btnPowerOn.Size = new System.Drawing.Size(100, 50);
            this.btnPowerOn.TabIndex = 3;
            this.btnPowerOn.Text = "PowerOn";
            this.btnPowerOn.UseVisualStyleBackColor = true;
            this.btnPowerOn.Click += new System.EventHandler(this.btnPowerOn_Click);
            // 
            // btnPowerOff
            // 
            this.btnPowerOff.Enabled = false;
            this.btnPowerOff.Location = new System.Drawing.Point(118, 69);
            this.btnPowerOff.Name = "btnPowerOff";
            this.btnPowerOff.Size = new System.Drawing.Size(100, 50);
            this.btnPowerOff.TabIndex = 4;
            this.btnPowerOff.Text = "PowerOff";
            this.btnPowerOff.UseVisualStyleBackColor = true;
            this.btnPowerOff.Click += new System.EventHandler(this.btnPowerOff_Click);
            // 
            // btnReleaseBreake
            // 
            this.btnReleaseBreake.Enabled = false;
            this.btnReleaseBreake.Location = new System.Drawing.Point(12, 124);
            this.btnReleaseBreake.Name = "btnReleaseBreake";
            this.btnReleaseBreake.Size = new System.Drawing.Size(100, 50);
            this.btnReleaseBreake.TabIndex = 5;
            this.btnReleaseBreake.Text = "Release Breake";
            this.btnReleaseBreake.UseVisualStyleBackColor = true;
            this.btnReleaseBreake.Click += new System.EventHandler(this.btnReleaseBreake_Click);
            // 
            // btnStop
            // 
            this.btnStop.BackColor = System.Drawing.Color.Red;
            this.btnStop.Enabled = false;
            this.btnStop.Location = new System.Drawing.Point(118, 125);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(100, 50);
            this.btnStop.TabIndex = 6;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = false;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // rtfCtrlSystem
            // 
            this.rtfCtrlSystem.BackColor = System.Drawing.SystemColors.Info;
            this.rtfCtrlSystem.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtfCtrlSystem.Location = new System.Drawing.Point(602, 48);
            this.rtfCtrlSystem.Name = "rtfCtrlSystem";
            this.rtfCtrlSystem.Size = new System.Drawing.Size(351, 621);
            this.rtfCtrlSystem.TabIndex = 7;
            this.rtfCtrlSystem.Text = "";
            // 
            // btnTcpXp
            // 
            this.btnTcpXp.Location = new System.Drawing.Point(16, 389);
            this.btnTcpXp.Name = "btnTcpXp";
            this.btnTcpXp.Size = new System.Drawing.Size(40, 40);
            this.btnTcpXp.TabIndex = 8;
            this.btnTcpXp.Text = "X+";
            this.btnTcpXp.UseVisualStyleBackColor = true;
            // 
            // btnTcpXm
            // 
            this.btnTcpXm.Location = new System.Drawing.Point(62, 389);
            this.btnTcpXm.Name = "btnTcpXm";
            this.btnTcpXm.Size = new System.Drawing.Size(40, 40);
            this.btnTcpXm.TabIndex = 9;
            this.btnTcpXm.Text = "X-";
            this.btnTcpXm.UseVisualStyleBackColor = true;
            // 
            // btnTcpYm
            // 
            this.btnTcpYm.Location = new System.Drawing.Point(36, 435);
            this.btnTcpYm.Name = "btnTcpYm";
            this.btnTcpYm.Size = new System.Drawing.Size(40, 40);
            this.btnTcpYm.TabIndex = 11;
            this.btnTcpYm.Text = "Y-";
            this.btnTcpYm.UseVisualStyleBackColor = true;
            // 
            // btnTcpYp
            // 
            this.btnTcpYp.Location = new System.Drawing.Point(36, 343);
            this.btnTcpYp.Name = "btnTcpYp";
            this.btnTcpYp.Size = new System.Drawing.Size(40, 40);
            this.btnTcpYp.TabIndex = 10;
            this.btnTcpYp.Text = "Y+";
            this.btnTcpYp.UseVisualStyleBackColor = true;
            // 
            // btnTcpZm
            // 
            this.btnTcpZm.Location = new System.Drawing.Point(62, 297);
            this.btnTcpZm.Name = "btnTcpZm";
            this.btnTcpZm.Size = new System.Drawing.Size(40, 40);
            this.btnTcpZm.TabIndex = 13;
            this.btnTcpZm.Text = "Z-";
            this.btnTcpZm.UseVisualStyleBackColor = true;
            // 
            // btnTcpZp
            // 
            this.btnTcpZp.Location = new System.Drawing.Point(16, 297);
            this.btnTcpZp.Name = "btnTcpZp";
            this.btnTcpZp.Size = new System.Drawing.Size(40, 40);
            this.btnTcpZp.TabIndex = 12;
            this.btnTcpZp.Text = "Z+";
            this.btnTcpZp.UseVisualStyleBackColor = true;
            this.btnTcpZp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btnTcpXYZ_MouseDown);
            this.btnTcpZp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btnTcpXYZ_MouseUp);
            // 
            // btnTcpRzm
            // 
            this.btnTcpRzm.Location = new System.Drawing.Point(62, 491);
            this.btnTcpRzm.Name = "btnTcpRzm";
            this.btnTcpRzm.Size = new System.Drawing.Size(40, 40);
            this.btnTcpRzm.TabIndex = 19;
            this.btnTcpRzm.Text = "RZ-";
            this.btnTcpRzm.UseVisualStyleBackColor = true;
            // 
            // btnTcpRzp
            // 
            this.btnTcpRzp.Location = new System.Drawing.Point(16, 491);
            this.btnTcpRzp.Name = "btnTcpRzp";
            this.btnTcpRzp.Size = new System.Drawing.Size(40, 40);
            this.btnTcpRzp.TabIndex = 18;
            this.btnTcpRzp.Text = "RZ+";
            this.btnTcpRzp.UseVisualStyleBackColor = true;
            // 
            // btnTcpRym
            // 
            this.btnTcpRym.Location = new System.Drawing.Point(36, 629);
            this.btnTcpRym.Name = "btnTcpRym";
            this.btnTcpRym.Size = new System.Drawing.Size(40, 40);
            this.btnTcpRym.TabIndex = 17;
            this.btnTcpRym.Text = "Y-";
            this.btnTcpRym.UseVisualStyleBackColor = true;
            // 
            // btnTcpRyp
            // 
            this.btnTcpRyp.Location = new System.Drawing.Point(36, 537);
            this.btnTcpRyp.Name = "btnTcpRyp";
            this.btnTcpRyp.Size = new System.Drawing.Size(40, 40);
            this.btnTcpRyp.TabIndex = 16;
            this.btnTcpRyp.Text = "Y+";
            this.btnTcpRyp.UseVisualStyleBackColor = true;
            // 
            // btnTcpRxm
            // 
            this.btnTcpRxm.Location = new System.Drawing.Point(62, 583);
            this.btnTcpRxm.Name = "btnTcpRxm";
            this.btnTcpRxm.Size = new System.Drawing.Size(40, 40);
            this.btnTcpRxm.TabIndex = 15;
            this.btnTcpRxm.Text = "X-";
            this.btnTcpRxm.UseVisualStyleBackColor = true;
            // 
            // btnTcpRxp
            // 
            this.btnTcpRxp.Location = new System.Drawing.Point(16, 583);
            this.btnTcpRxp.Name = "btnTcpRxp";
            this.btnTcpRxp.Size = new System.Drawing.Size(40, 40);
            this.btnTcpRxp.TabIndex = 14;
            this.btnTcpRxp.Text = "X+";
            this.btnTcpRxp.UseVisualStyleBackColor = true;
            // 
            // gbxTcpPosition
            // 
            this.gbxTcpPosition.Controls.Add(this.btnGetRobotPosition);
            this.gbxTcpPosition.Controls.Add(this.btnMoveTcpTest);
            this.gbxTcpPosition.Controls.Add(this.nudTCPrZ);
            this.gbxTcpPosition.Controls.Add(this.nudTCPrY);
            this.gbxTcpPosition.Controls.Add(this.nudTCPrX);
            this.gbxTcpPosition.Controls.Add(this.nudTCPZ);
            this.gbxTcpPosition.Controls.Add(this.nudTCPY);
            this.gbxTcpPosition.Controls.Add(this.nudTCPX);
            this.gbxTcpPosition.Controls.Add(this.lblTpRyTitle);
            this.gbxTcpPosition.Controls.Add(this.lblTpRzTitle);
            this.gbxTcpPosition.Controls.Add(this.lblTpYTitle);
            this.gbxTcpPosition.Controls.Add(this.lblTpRxTitle);
            this.gbxTcpPosition.Controls.Add(this.lblTpZTitle);
            this.gbxTcpPosition.Controls.Add(this.lblTpXTitle);
            this.gbxTcpPosition.Location = new System.Drawing.Point(269, 413);
            this.gbxTcpPosition.Name = "gbxTcpPosition";
            this.gbxTcpPosition.Size = new System.Drawing.Size(137, 257);
            this.gbxTcpPosition.TabIndex = 43;
            this.gbxTcpPosition.TabStop = false;
            this.gbxTcpPosition.Text = "TCP Position";
            // 
            // btnGetRobotPosition
            // 
            this.btnGetRobotPosition.Location = new System.Drawing.Point(9, 195);
            this.btnGetRobotPosition.Name = "btnGetRobotPosition";
            this.btnGetRobotPosition.Size = new System.Drawing.Size(103, 25);
            this.btnGetRobotPosition.TabIndex = 41;
            this.btnGetRobotPosition.Text = "Get TCP Pos";
            this.btnGetRobotPosition.UseVisualStyleBackColor = true;
            this.btnGetRobotPosition.Click += new System.EventHandler(this.btnGetRobotPosition_Click);
            // 
            // btnMoveTcpTest
            // 
            this.btnMoveTcpTest.Location = new System.Drawing.Point(9, 223);
            this.btnMoveTcpTest.Name = "btnMoveTcpTest";
            this.btnMoveTcpTest.Size = new System.Drawing.Size(103, 24);
            this.btnMoveTcpTest.TabIndex = 18;
            this.btnMoveTcpTest.Text = "Move To Pos";
            this.btnMoveTcpTest.UseVisualStyleBackColor = true;
            this.btnMoveTcpTest.Click += new System.EventHandler(this.btnMoveTcpTest_Click);
            // 
            // nudTCPrZ
            // 
            this.nudTCPrZ.DecimalPlaces = 4;
            this.nudTCPrZ.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudTCPrZ.Location = new System.Drawing.Point(32, 163);
            this.nudTCPrZ.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudTCPrZ.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nudTCPrZ.Name = "nudTCPrZ";
            this.nudTCPrZ.Size = new System.Drawing.Size(80, 22);
            this.nudTCPrZ.TabIndex = 17;
            // 
            // nudTCPrY
            // 
            this.nudTCPrY.DecimalPlaces = 4;
            this.nudTCPrY.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudTCPrY.Location = new System.Drawing.Point(32, 134);
            this.nudTCPrY.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudTCPrY.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nudTCPrY.Name = "nudTCPrY";
            this.nudTCPrY.Size = new System.Drawing.Size(80, 22);
            this.nudTCPrY.TabIndex = 16;
            // 
            // nudTCPrX
            // 
            this.nudTCPrX.DecimalPlaces = 4;
            this.nudTCPrX.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudTCPrX.Location = new System.Drawing.Point(32, 106);
            this.nudTCPrX.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudTCPrX.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nudTCPrX.Name = "nudTCPrX";
            this.nudTCPrX.Size = new System.Drawing.Size(80, 22);
            this.nudTCPrX.TabIndex = 15;
            // 
            // nudTCPZ
            // 
            this.nudTCPZ.DecimalPlaces = 4;
            this.nudTCPZ.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudTCPZ.Location = new System.Drawing.Point(32, 78);
            this.nudTCPZ.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.nudTCPZ.Minimum = new decimal(new int[] {
            99999,
            0,
            0,
            -2147483648});
            this.nudTCPZ.Name = "nudTCPZ";
            this.nudTCPZ.Size = new System.Drawing.Size(80, 22);
            this.nudTCPZ.TabIndex = 14;
            // 
            // nudTCPY
            // 
            this.nudTCPY.DecimalPlaces = 4;
            this.nudTCPY.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudTCPY.Location = new System.Drawing.Point(32, 50);
            this.nudTCPY.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.nudTCPY.Minimum = new decimal(new int[] {
            99999,
            0,
            0,
            -2147483648});
            this.nudTCPY.Name = "nudTCPY";
            this.nudTCPY.Size = new System.Drawing.Size(80, 22);
            this.nudTCPY.TabIndex = 13;
            // 
            // nudTCPX
            // 
            this.nudTCPX.DecimalPlaces = 4;
            this.nudTCPX.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudTCPX.Location = new System.Drawing.Point(32, 23);
            this.nudTCPX.Maximum = new decimal(new int[] {
            99999,
            0,
            0,
            0});
            this.nudTCPX.Minimum = new decimal(new int[] {
            99999,
            0,
            0,
            -2147483648});
            this.nudTCPX.Name = "nudTCPX";
            this.nudTCPX.Size = new System.Drawing.Size(80, 22);
            this.nudTCPX.TabIndex = 12;
            // 
            // lblTpRyTitle
            // 
            this.lblTpRyTitle.AutoSize = true;
            this.lblTpRyTitle.Location = new System.Drawing.Point(7, 140);
            this.lblTpRyTitle.Name = "lblTpRyTitle";
            this.lblTpRyTitle.Size = new System.Drawing.Size(21, 16);
            this.lblTpRyTitle.TabIndex = 11;
            this.lblTpRyTitle.Text = "rY";
            // 
            // lblTpRzTitle
            // 
            this.lblTpRzTitle.AutoSize = true;
            this.lblTpRzTitle.Location = new System.Drawing.Point(8, 169);
            this.lblTpRzTitle.Name = "lblTpRzTitle";
            this.lblTpRzTitle.Size = new System.Drawing.Size(19, 16);
            this.lblTpRzTitle.TabIndex = 10;
            this.lblTpRzTitle.Text = "rZ";
            // 
            // lblTpYTitle
            // 
            this.lblTpYTitle.AutoSize = true;
            this.lblTpYTitle.Location = new System.Drawing.Point(11, 55);
            this.lblTpYTitle.Name = "lblTpYTitle";
            this.lblTpYTitle.Size = new System.Drawing.Size(17, 16);
            this.lblTpYTitle.TabIndex = 9;
            this.lblTpYTitle.Text = "Y";
            // 
            // lblTpRxTitle
            // 
            this.lblTpRxTitle.AutoSize = true;
            this.lblTpRxTitle.Location = new System.Drawing.Point(7, 112);
            this.lblTpRxTitle.Name = "lblTpRxTitle";
            this.lblTpRxTitle.Size = new System.Drawing.Size(19, 16);
            this.lblTpRxTitle.TabIndex = 8;
            this.lblTpRxTitle.Text = "rX";
            // 
            // lblTpZTitle
            // 
            this.lblTpZTitle.AutoSize = true;
            this.lblTpZTitle.Location = new System.Drawing.Point(12, 83);
            this.lblTpZTitle.Name = "lblTpZTitle";
            this.lblTpZTitle.Size = new System.Drawing.Size(15, 16);
            this.lblTpZTitle.TabIndex = 7;
            this.lblTpZTitle.Text = "Z";
            // 
            // lblTpXTitle
            // 
            this.lblTpXTitle.AutoSize = true;
            this.lblTpXTitle.Location = new System.Drawing.Point(11, 26);
            this.lblTpXTitle.Name = "lblTpXTitle";
            this.lblTpXTitle.Size = new System.Drawing.Size(15, 16);
            this.lblTpXTitle.TabIndex = 6;
            this.lblTpXTitle.Text = "X";
            // 
            // gbxAnglePosition
            // 
            this.gbxAnglePosition.Controls.Add(this.btnGetMotorAngle);
            this.gbxAnglePosition.Controls.Add(this.btnMoveAngleTest);
            this.gbxAnglePosition.Controls.Add(this.lblApWrist3Title);
            this.gbxAnglePosition.Controls.Add(this.lblApWrist2Title);
            this.gbxAnglePosition.Controls.Add(this.lblApWrist1Title);
            this.gbxAnglePosition.Controls.Add(this.lblApElbowTitle);
            this.gbxAnglePosition.Controls.Add(this.lblApShoulderTitle);
            this.gbxAnglePosition.Controls.Add(this.lblApBaseTitle);
            this.gbxAnglePosition.Controls.Add(this.nudAnglerZ);
            this.gbxAnglePosition.Controls.Add(this.nudAnglerY);
            this.gbxAnglePosition.Controls.Add(this.nudAnglerX);
            this.gbxAnglePosition.Controls.Add(this.nudAngleZ);
            this.gbxAnglePosition.Controls.Add(this.nudAngleY);
            this.gbxAnglePosition.Controls.Add(this.nudAngleX);
            this.gbxAnglePosition.Location = new System.Drawing.Point(412, 413);
            this.gbxAnglePosition.Name = "gbxAnglePosition";
            this.gbxAnglePosition.Size = new System.Drawing.Size(184, 256);
            this.gbxAnglePosition.TabIndex = 44;
            this.gbxAnglePosition.TabStop = false;
            this.gbxAnglePosition.Text = "Angle Position";
            // 
            // btnGetMotorAngle
            // 
            this.btnGetMotorAngle.Location = new System.Drawing.Point(9, 195);
            this.btnGetMotorAngle.Name = "btnGetMotorAngle";
            this.btnGetMotorAngle.Size = new System.Drawing.Size(153, 24);
            this.btnGetMotorAngle.TabIndex = 41;
            this.btnGetMotorAngle.Text = "Get Motor Angle";
            this.btnGetMotorAngle.UseVisualStyleBackColor = true;
            this.btnGetMotorAngle.Click += new System.EventHandler(this.btnGetMotorAngle_Click);
            // 
            // btnMoveAngleTest
            // 
            this.btnMoveAngleTest.Location = new System.Drawing.Point(9, 223);
            this.btnMoveAngleTest.Name = "btnMoveAngleTest";
            this.btnMoveAngleTest.Size = new System.Drawing.Size(153, 24);
            this.btnMoveAngleTest.TabIndex = 40;
            this.btnMoveAngleTest.Text = "Move To Angle";
            this.btnMoveAngleTest.UseVisualStyleBackColor = true;
            this.btnMoveAngleTest.Click += new System.EventHandler(this.btnMoveAngleTest_Click);
            // 
            // lblApWrist3Title
            // 
            this.lblApWrist3Title.AutoSize = true;
            this.lblApWrist3Title.Location = new System.Drawing.Point(15, 169);
            this.lblApWrist3Title.Name = "lblApWrist3Title";
            this.lblApWrist3Title.Size = new System.Drawing.Size(50, 16);
            this.lblApWrist3Title.TabIndex = 39;
            this.lblApWrist3Title.Text = "Wrist 3";
            // 
            // lblApWrist2Title
            // 
            this.lblApWrist2Title.AutoSize = true;
            this.lblApWrist2Title.Location = new System.Drawing.Point(15, 140);
            this.lblApWrist2Title.Name = "lblApWrist2Title";
            this.lblApWrist2Title.Size = new System.Drawing.Size(50, 16);
            this.lblApWrist2Title.TabIndex = 38;
            this.lblApWrist2Title.Text = "Wrist 2";
            // 
            // lblApWrist1Title
            // 
            this.lblApWrist1Title.AutoSize = true;
            this.lblApWrist1Title.Location = new System.Drawing.Point(15, 108);
            this.lblApWrist1Title.Name = "lblApWrist1Title";
            this.lblApWrist1Title.Size = new System.Drawing.Size(50, 16);
            this.lblApWrist1Title.TabIndex = 37;
            this.lblApWrist1Title.Text = "Wrist 1";
            // 
            // lblApElbowTitle
            // 
            this.lblApElbowTitle.AutoSize = true;
            this.lblApElbowTitle.Location = new System.Drawing.Point(19, 81);
            this.lblApElbowTitle.Name = "lblApElbowTitle";
            this.lblApElbowTitle.Size = new System.Drawing.Size(43, 16);
            this.lblApElbowTitle.TabIndex = 36;
            this.lblApElbowTitle.Text = "Elbow";
            // 
            // lblApShoulderTitle
            // 
            this.lblApShoulderTitle.AutoSize = true;
            this.lblApShoulderTitle.Location = new System.Drawing.Point(7, 51);
            this.lblApShoulderTitle.Name = "lblApShoulderTitle";
            this.lblApShoulderTitle.Size = new System.Drawing.Size(59, 16);
            this.lblApShoulderTitle.TabIndex = 35;
            this.lblApShoulderTitle.Text = "Shoulder";
            // 
            // lblApBaseTitle
            // 
            this.lblApBaseTitle.AutoSize = true;
            this.lblApBaseTitle.Location = new System.Drawing.Point(27, 24);
            this.lblApBaseTitle.Name = "lblApBaseTitle";
            this.lblApBaseTitle.Size = new System.Drawing.Size(38, 16);
            this.lblApBaseTitle.TabIndex = 34;
            this.lblApBaseTitle.Text = "Base";
            // 
            // nudAnglerZ
            // 
            this.nudAnglerZ.DecimalPlaces = 4;
            this.nudAnglerZ.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudAnglerZ.Location = new System.Drawing.Point(71, 165);
            this.nudAnglerZ.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudAnglerZ.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nudAnglerZ.Name = "nudAnglerZ";
            this.nudAnglerZ.Size = new System.Drawing.Size(91, 22);
            this.nudAnglerZ.TabIndex = 17;
            // 
            // nudAnglerY
            // 
            this.nudAnglerY.DecimalPlaces = 4;
            this.nudAnglerY.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudAnglerY.Location = new System.Drawing.Point(71, 136);
            this.nudAnglerY.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudAnglerY.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nudAnglerY.Name = "nudAnglerY";
            this.nudAnglerY.Size = new System.Drawing.Size(91, 22);
            this.nudAnglerY.TabIndex = 16;
            // 
            // nudAnglerX
            // 
            this.nudAnglerX.DecimalPlaces = 4;
            this.nudAnglerX.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudAnglerX.Location = new System.Drawing.Point(71, 107);
            this.nudAnglerX.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudAnglerX.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nudAnglerX.Name = "nudAnglerX";
            this.nudAnglerX.Size = new System.Drawing.Size(91, 22);
            this.nudAnglerX.TabIndex = 15;
            // 
            // nudAngleZ
            // 
            this.nudAngleZ.DecimalPlaces = 4;
            this.nudAngleZ.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudAngleZ.Location = new System.Drawing.Point(71, 78);
            this.nudAngleZ.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudAngleZ.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nudAngleZ.Name = "nudAngleZ";
            this.nudAngleZ.Size = new System.Drawing.Size(91, 22);
            this.nudAngleZ.TabIndex = 14;
            // 
            // nudAngleY
            // 
            this.nudAngleY.DecimalPlaces = 4;
            this.nudAngleY.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudAngleY.Location = new System.Drawing.Point(71, 50);
            this.nudAngleY.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudAngleY.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nudAngleY.Name = "nudAngleY";
            this.nudAngleY.Size = new System.Drawing.Size(91, 22);
            this.nudAngleY.TabIndex = 13;
            // 
            // nudAngleX
            // 
            this.nudAngleX.DecimalPlaces = 4;
            this.nudAngleX.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.nudAngleX.Location = new System.Drawing.Point(71, 22);
            this.nudAngleX.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.nudAngleX.Minimum = new decimal(new int[] {
            360,
            0,
            0,
            -2147483648});
            this.nudAngleX.Name = "nudAngleX";
            this.nudAngleX.Size = new System.Drawing.Size(91, 22);
            this.nudAngleX.TabIndex = 12;
            // 
            // gbxRobotParams
            // 
            this.gbxRobotParams.Controls.Add(this.lblRpAngle);
            this.gbxRobotParams.Controls.Add(this.lblRpAngleTitle);
            this.gbxRobotParams.Controls.Add(this.lblRpTcp);
            this.gbxRobotParams.Controls.Add(this.lblRpTcpTitle);
            this.gbxRobotParams.Controls.Add(this.lblRpTitle);
            this.gbxRobotParams.Location = new System.Drawing.Point(224, 13);
            this.gbxRobotParams.Name = "gbxRobotParams";
            this.gbxRobotParams.Size = new System.Drawing.Size(372, 243);
            this.gbxRobotParams.TabIndex = 45;
            this.gbxRobotParams.TabStop = false;
            this.gbxRobotParams.Text = "Robot Params";
            // 
            // lblRpAngle
            // 
            this.lblRpAngle.AutoSize = true;
            this.lblRpAngle.Location = new System.Drawing.Point(126, 56);
            this.lblRpAngle.Name = "lblRpAngle";
            this.lblRpAngle.Size = new System.Drawing.Size(21, 176);
            this.lblRpAngle.TabIndex = 49;
            this.lblRpAngle.Text = "X\r\n\r\nY\r\n\r\nZ\r\n\r\nrX\r\n\r\nrY\r\n\r\nrZ";
            // 
            // lblRpAngleTitle
            // 
            this.lblRpAngleTitle.AutoSize = true;
            this.lblRpAngleTitle.Location = new System.Drawing.Point(126, 33);
            this.lblRpAngleTitle.Name = "lblRpAngleTitle";
            this.lblRpAngleTitle.Size = new System.Drawing.Size(41, 16);
            this.lblRpAngleTitle.TabIndex = 48;
            this.lblRpAngleTitle.Text = "Angle";
            // 
            // lblRpTcp
            // 
            this.lblRpTcp.AutoSize = true;
            this.lblRpTcp.Location = new System.Drawing.Point(53, 56);
            this.lblRpTcp.Name = "lblRpTcp";
            this.lblRpTcp.Size = new System.Drawing.Size(21, 176);
            this.lblRpTcp.TabIndex = 47;
            this.lblRpTcp.Text = "X\r\n\r\nY\r\n\r\nZ\r\n\r\nrX\r\n\r\nrY\r\n\r\nrZ";
            // 
            // lblRpTcpTitle
            // 
            this.lblRpTcpTitle.AutoSize = true;
            this.lblRpTcpTitle.Location = new System.Drawing.Point(53, 33);
            this.lblRpTcpTitle.Name = "lblRpTcpTitle";
            this.lblRpTcpTitle.Size = new System.Drawing.Size(33, 16);
            this.lblRpTcpTitle.TabIndex = 46;
            this.lblRpTcpTitle.Text = "TCP";
            // 
            // lblRpTitle
            // 
            this.lblRpTitle.AutoSize = true;
            this.lblRpTitle.Location = new System.Drawing.Point(6, 56);
            this.lblRpTitle.Name = "lblRpTitle";
            this.lblRpTitle.Size = new System.Drawing.Size(21, 176);
            this.lblRpTitle.TabIndex = 6;
            this.lblRpTitle.Text = "X\r\n\r\nY\r\n\r\nZ\r\n\r\nrX\r\n\r\nrY\r\n\r\nrZ";
            // 
            // lblAccTitle
            // 
            this.lblAccTitle.AutoSize = true;
            this.lblAccTitle.Location = new System.Drawing.Point(398, 352);
            this.lblAccTitle.Name = "lblAccTitle";
            this.lblAccTitle.Size = new System.Drawing.Size(92, 16);
            this.lblAccTitle.TabIndex = 46;
            this.lblAccTitle.Text = "Acc (rad/(s^2))";
            // 
            // lblSpeedTitle
            // 
            this.lblSpeedTitle.AutoSize = true;
            this.lblSpeedTitle.Location = new System.Drawing.Point(404, 380);
            this.lblSpeedTitle.Name = "lblSpeedTitle";
            this.lblSpeedTitle.Size = new System.Drawing.Size(86, 16);
            this.lblSpeedTitle.TabIndex = 47;
            this.lblSpeedTitle.Text = "Speed (rad/s)";
            // 
            // txtAcc
            // 
            this.txtAcc.Location = new System.Drawing.Point(496, 349);
            this.txtAcc.Name = "txtAcc";
            this.txtAcc.Size = new System.Drawing.Size(100, 22);
            this.txtAcc.TabIndex = 48;
            this.txtAcc.Text = "0.15";
            // 
            // txtSpeed
            // 
            this.txtSpeed.Location = new System.Drawing.Point(496, 377);
            this.txtSpeed.Name = "txtSpeed";
            this.txtSpeed.Size = new System.Drawing.Size(100, 22);
            this.txtSpeed.TabIndex = 49;
            this.txtSpeed.Text = "0.15";
            // 
            // frmUrRobotDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 681);
            this.Controls.Add(this.txtSpeed);
            this.Controls.Add(this.txtAcc);
            this.Controls.Add(this.lblSpeedTitle);
            this.Controls.Add(this.lblAccTitle);
            this.Controls.Add(this.gbxRobotParams);
            this.Controls.Add(this.gbxAnglePosition);
            this.Controls.Add(this.gbxTcpPosition);
            this.Controls.Add(this.btnTcpRzm);
            this.Controls.Add(this.btnTcpRzp);
            this.Controls.Add(this.btnTcpRym);
            this.Controls.Add(this.btnTcpRyp);
            this.Controls.Add(this.btnTcpRxm);
            this.Controls.Add(this.btnTcpRxp);
            this.Controls.Add(this.btnTcpZm);
            this.Controls.Add(this.btnTcpZp);
            this.Controls.Add(this.btnTcpYm);
            this.Controls.Add(this.btnTcpYp);
            this.Controls.Add(this.btnTcpXm);
            this.Controls.Add(this.btnTcpXp);
            this.Controls.Add(this.rtfCtrlSystem);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnReleaseBreake);
            this.Controls.Add(this.btnPowerOff);
            this.Controls.Add(this.btnPowerOn);
            this.Controls.Add(this.btnDisconnect);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.btnTestJson);
            this.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmUrRobotDemo";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmUrRobotDemo_FormClosed);
            this.Load += new System.EventHandler(this.frmUrRobotDemo_Load);
            this.gbxTcpPosition.ResumeLayout(false);
            this.gbxTcpPosition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPrZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPrY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPrX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTCPX)).EndInit();
            this.gbxAnglePosition.ResumeLayout(false);
            this.gbxAnglePosition.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnglerZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnglerY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnglerX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngleZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngleY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAngleX)).EndInit();
            this.gbxRobotParams.ResumeLayout(false);
            this.gbxRobotParams.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTestJson;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.Button btnPowerOn;
        private System.Windows.Forms.Button btnPowerOff;
        private System.Windows.Forms.Button btnReleaseBreake;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.RichTextBox rtfCtrlSystem;
        private System.Windows.Forms.Button btnTcpXp;
        private System.Windows.Forms.Button btnTcpXm;
        private System.Windows.Forms.Button btnTcpYm;
        private System.Windows.Forms.Button btnTcpYp;
        private System.Windows.Forms.Button btnTcpZm;
        private System.Windows.Forms.Button btnTcpZp;
        private System.Windows.Forms.Button btnTcpRzm;
        private System.Windows.Forms.Button btnTcpRzp;
        private System.Windows.Forms.Button btnTcpRym;
        private System.Windows.Forms.Button btnTcpRyp;
        private System.Windows.Forms.Button btnTcpRxm;
        private System.Windows.Forms.Button btnTcpRxp;
        internal System.Windows.Forms.GroupBox gbxTcpPosition;
        internal System.Windows.Forms.Button btnGetRobotPosition;
        internal System.Windows.Forms.Button btnMoveTcpTest;
        internal System.Windows.Forms.NumericUpDown nudTCPrZ;
        internal System.Windows.Forms.NumericUpDown nudTCPrY;
        internal System.Windows.Forms.NumericUpDown nudTCPrX;
        internal System.Windows.Forms.NumericUpDown nudTCPZ;
        internal System.Windows.Forms.NumericUpDown nudTCPY;
        internal System.Windows.Forms.NumericUpDown nudTCPX;
        internal System.Windows.Forms.Label lblTpRyTitle;
        internal System.Windows.Forms.Label lblTpRzTitle;
        internal System.Windows.Forms.Label lblTpYTitle;
        internal System.Windows.Forms.Label lblTpRxTitle;
        internal System.Windows.Forms.Label lblTpZTitle;
        internal System.Windows.Forms.Label lblTpXTitle;
        internal System.Windows.Forms.GroupBox gbxAnglePosition;
        internal System.Windows.Forms.Button btnGetMotorAngle;
        internal System.Windows.Forms.Button btnMoveAngleTest;
        internal System.Windows.Forms.Label lblApWrist3Title;
        internal System.Windows.Forms.Label lblApWrist2Title;
        internal System.Windows.Forms.Label lblApWrist1Title;
        internal System.Windows.Forms.Label lblApElbowTitle;
        internal System.Windows.Forms.Label lblApShoulderTitle;
        internal System.Windows.Forms.Label lblApBaseTitle;
        internal System.Windows.Forms.NumericUpDown nudAnglerZ;
        internal System.Windows.Forms.NumericUpDown nudAnglerY;
        internal System.Windows.Forms.NumericUpDown nudAnglerX;
        internal System.Windows.Forms.NumericUpDown nudAngleZ;
        internal System.Windows.Forms.NumericUpDown nudAngleY;
        internal System.Windows.Forms.NumericUpDown nudAngleX;
        internal System.Windows.Forms.GroupBox gbxRobotParams;
        internal System.Windows.Forms.Label lblRpTitle;
        internal System.Windows.Forms.Label lblRpTcpTitle;
        internal System.Windows.Forms.Label lblRpAngle;
        internal System.Windows.Forms.Label lblRpAngleTitle;
        internal System.Windows.Forms.Label lblRpTcp;
        internal System.Windows.Forms.Label lblAccTitle;
        internal System.Windows.Forms.Label lblSpeedTitle;
        private System.Windows.Forms.TextBox txtAcc;
        private System.Windows.Forms.TextBox txtSpeed;
    }
}


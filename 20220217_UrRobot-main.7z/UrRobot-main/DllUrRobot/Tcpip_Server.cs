﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Collections;

namespace TCPIP
{
    public class Tcpip_Server
    {

        public delegate void errorClientDiscHandler();
        public event errorClientDiscHandler errorClientDiscEvent;

        public delegate void errorClientCmdDiscHandler();
        public event errorClientCmdDiscHandler errorClientCmdDiscEvent;

        public delegate void errorClientUIsendCmdDiscHandler();
        public event errorClientUIsendCmdDiscHandler errorClientUIsendCmdDiscEvent;

        //public delegate void cmdStartHandler();
        //public event cmdStartHandler cmdStartEvent(string cmdStr);

        public delegate void monitorAxisDataHandler(string cmdStr);
        public event monitorAxisDataHandler monitorAxisDataEvent;

        System.Timers.Timer tmr_sendingAxisDataToRos;

        private static string _IP = "192.168.0.1";
        private static int _RefreshDataPort = 5000;
        private static int _SendCmdPort = 4500;
        private static int _UIsendCmdPort = 4000;

        public string IP
        {
            get { return _IP; }
            set { _IP = value; }
        }
        public int RefreshDataPort
        {
            get { return _RefreshDataPort; }
            set { _RefreshDataPort = value; }
        }
        public int SendCmdPort
        {
            get { return _SendCmdPort; }
            set { _SendCmdPort = value; }
        }
        public int UIsendCmdPort
        {
            get { return _UIsendCmdPort; }
            set { _UIsendCmdPort = value; }
        }
        public bool _isContinousSending;
        public bool ContinousSending
        {
            get { return _isContinousSending; }
            set { _isContinousSending = value; }
        }
        private bool _Process_Cancel = false; // 流程取消
        public bool Process_Cancel
        {
            get { return _Process_Cancel; }
            set { _Process_Cancel = value; }
        }
        TcpListener refreshDatalistener = null;
        TcpClient refreshDataclient = null;

        TcpListener sendCmdlistener = null;
        TcpClient sendCmdclient = null;

        TcpListener UIsendCmdlistener = null;
        TcpClient UIsendCmdclient = null;

        private Task taskRunFlowControl;//用於管控流程

        public class cls_RtnObj
        {
            //public object ReturnValue;
            public bool WorkFinished;
            public bool ErrorOccure;
            public string ErrorString;
            public cls_RtnObj()
            {
                //ReturnValue = null;
                WorkFinished = false;
                ErrorOccure = false;
                ErrorString = "";
            }
            public void SetWorkFinish(string ErrStr = "")
            {
                ErrorOccure = ErrStr != "";
                ErrorString = ErrStr;
                WorkFinished = true;
            }
        }
        public class cls_FlowParameters
        {
            public int MotionCount;
            public int StepID;
            public int NextID;
            public bool IsOn;
            public bool Finished;
            public bool ErrorOccure;
            public string ErrorString;
            public string StepMsg;
            public object InputObject;  // 傳入之參數
            public string Illustration;
            public DateTime DelayTime;  // 2016.11.10 新增
            public DateTime HoldTime;  // 2016.11.10 新增
            //public DateTime CheckTime;  // 2016.11.10 新增
            public string RosSendingData;
            public bool RosToPc_Begin;
            public bool RosToPc_SendingTable;
            public bool RosToPc_Finished;
            public int ReceiveCount;
            public int index;
            public cls_FlowParameters()
            {
                MotionCount = 0;
                StepID = 0;
                NextID = 0;
                IsOn = false;
                Finished = false;
                ErrorOccure = false;
                ErrorString = string.Empty;
                StepMsg = string.Empty;
                InputObject = null;
                Illustration = string.Empty;
                RosSendingData = string.Empty;
                RosToPc_Begin = false;
                RosToPc_SendingTable = false;
                RosToPc_Finished = false;
                ReceiveCount = 0;
                index = 0;
            }
            public void NewStart(bool Action = true)
            {
                MotionCount = 0;
                StepID = 0;
                NextID = 0;
                IsOn = Action;
                Finished = false;
                ErrorOccure = false;
                ErrorString = string.Empty;
                InputObject = null;
                Illustration = "Process New Start";
                RosSendingData = string.Empty;
                RosToPc_Begin = false;
                RosToPc_SendingTable = false;
                RosToPc_Finished = false;
                ReceiveCount = 0;
                index = 0;
            }
            public void Cancel()
            {
                this.SetProcessFinish("Process been Cancled");
            }
            public void SetProcessFinish(string ErrString = "")
            {
                if (ErrString == string.Empty)
                {
                    MotionCount = 0;
                    IsOn = false;
                    Finished = true;
                    ErrorOccure = false;
                    ErrorString = "";
                    InputObject = null;
                    StepID = 0;
                    RosSendingData = string.Empty;
                    RosToPc_Begin = false;
                    RosToPc_SendingTable = false;
                    RosToPc_Finished = false;
                    ReceiveCount = 0;
                    index = 0;
                }
                else
                {
                    MotionCount = 0;
                    IsOn = false;
                    Finished = true;
                    ErrorOccure = true;
                    ErrorString = ErrString;
                    InputObject = null;
                    StepID = 0;
                    Illustration = "Process Error :" + ErrString;
                    RosSendingData = string.Empty;
                    RosToPc_Begin = false;
                    RosToPc_SendingTable = false;
                    RosToPc_Finished = false;
                    ReceiveCount = 0;
                    index = 0;
                }
            }
        }
        byte[] sendCmdbuffer;
        public void Connect()
        {
            try
            {
                IPAddress ipAddress = IPAddress.Parse(_IP);
                refreshDatalistener = new TcpListener(ipAddress, _RefreshDataPort); // generally use ports > 1024
                refreshDatalistener.Start();
                refreshDataclient = new TcpClient();
                refreshDataclient = refreshDatalistener.AcceptTcpClient();
                refreshDataserver = new Thread(refreshDataServer);
                refreshDataserver.Start();
                tmr_sendingAxisDataToRos.Enabled = true;
            }
            catch (Exception ex)
            {
                Application.DoEvents();
            }
        }

        private void Tmr_sendingAxisDataToRos_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                if (isSendingAxisData) return;
                isSendingAxisData = true;
                int ret = 0;
                ret = SendingAxisData();
                isSendingAxisData = false;
            }
            catch (Exception)
            {
                tmr_sendingAxisDataToRos.Enabled = false;
                if (refreshDataclient.Client.Connected) refreshDataclient.Client.Disconnect(true);
                tcpListenerThread.Abort();
                refreshDatalistener.Stop();
                errorClientDiscEvent?.Invoke();
                isSendingAxisData = false;
                //throw;
            }

        }

        public void ConnectCmdListner()
        {
            try
            {
                IPAddress ipAddress = IPAddress.Parse(_IP);
                sendCmdlistener = new TcpListener(ipAddress, _SendCmdPort); // generally use ports > 1024
                sendCmdlistener.Start();
                sendCmdclient = new TcpClient();
                //sendCmdbuffer = new byte[32768];
                sendCmdbuffer = new byte[204800];
                sendCmdclient = sendCmdlistener.AcceptTcpClient();
                refreshCmdserver = new Thread(refreshCmdServer);
                refreshCmdserver.Start();
                //var waitSendCmdClient = new Task(waitSendCmdClientConnect);
                //waitSendCmdClient.Start();
            }
            catch (Exception ex)
            {
                Application.DoEvents();
            }
        }

        private void ConnectUIsendCmdListener()
        {
            try
            {
                IPAddress ipAddress = IPAddress.Parse(_IP);
                UIsendCmdlistener = new TcpListener(ipAddress, _UIsendCmdPort); // generally use ports > 1024
                UIsendCmdlistener.Start();
                UIsendCmdclient = new TcpClient();
                UIsendCmdbuffer = new byte[204800];
                UIsendCmdclient = UIsendCmdlistener.AcceptTcpClient();
                refreshUICmdServer = new Thread(refreshUIsendCmdServer);
                refreshUICmdServer.Start();
            }
            catch (Exception ex)
            {
                Application.DoEvents();
            }
        }

        Thread refreshDataserver;
        Thread refreshCmdserver;
        Thread refreshUICmdServer;

        private bool isReceiving = false;
        public void refreshDataServer()
        {
            int ret = 0;
            try
            {
                while (true)
                {
                    //---incoming client connected---
                    if (isReceiving) return;
                    isReceiving = true;
                    //---get the incoming data through a network stream---
                    NetworkStream nwStream = refreshDataclient.GetStream();
                    byte[] buffer = new byte[refreshDataclient.ReceiveBufferSize];
                    //---read incoming stream---
                    int bytesRead = nwStream.Read(buffer, 0, refreshDataclient.ReceiveBufferSize);
                    //---convert the data received into a string---
                    if (bytesRead == 0)
                    {
                        isReceiving = false;
                        refreshDataclient.Client.Disconnect(true);
                        tcpListenerThread.Abort();
                        refreshDatalistener.Stop();
                        tmr_sendingAxisDataToRos.Enabled = false;
                        errorClientDiscEvent?.Invoke();
                        return;
                    }
                    string dataReceived = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    //---write back the text to the client---
                    ret = RosFeedbackPcsData(dataReceived);
                    //ret = FeedBackData(dataReceived);
                    isReceiving = false;
                }
            }
            catch (Exception ex)
            {
                isReceiving = false;
            }
        }
        bool isSendingAxisData;
        private void sendAxisData()
        {
            try
            {
                while (true)
                {
                    if (isSendingAxisData) return;
                    isSendingAxisData = true;
                    int ret = 0;
                    ret = SendingAxisData();
                    isSendingAxisData = false;
                }
            }
            catch (Exception)
            {
                if (refreshDataclient.Client.Connected) refreshDataclient.Client.Disconnect(true);
                tcpListenerThread.Abort();
                refreshDatalistener.Stop();
                errorClientDiscEvent?.Invoke();
                isSendingAxisData = false;
            }
        }
        private bool isReceiving2 = false;
        public void refreshCmdServer()
        {
            int ret = 0;
            try
            {
                while (true)
                {
                    //---incoming client connected---
                    if (isReceiving2) return;
                    isReceiving2 = true;
                    //---get the incoming data through a network stream---
                    NetworkStream nwStream = sendCmdclient.GetStream();
                    //---read incoming stream---
                    int bytesRead = nwStream.Read(sendCmdbuffer, 0, sendCmdbuffer.Length);
                    //---convert the data received into a string---
                    if (bytesRead == 0)
                    {
                        isReceiving2 = false;
                        sendCmdclient.Client.Disconnect(true);
                        SendCmdTcpListenerThread.Abort();
                        sendCmdlistener.Stop();
                        errorClientCmdDiscEvent?.Invoke();
                        return;
                    }
                    string dataReceived = Encoding.ASCII.GetString(sendCmdbuffer, 0, bytesRead);
                    //---write back the text to the client---
                    ret = RosFeedbackCmdData(dataReceived);
                    ((IList)sendCmdbuffer).Clear();
                    isReceiving2 = false;
                }
            }
            catch (Exception ex)
            {
                isReceiving2 = false;
            }
        }
        byte[] UIsendCmdbuffer;
        private bool isReceiving3 = false;
        public void refreshUIsendCmdServer()
        {
            int ret = 0;
            try
            {
                while (true)
                {
                    //---incoming client connected---
                    if (isReceiving3) return;
                    isReceiving3 = true;
                    //---get the incoming data through a network stream---
                    NetworkStream nwStream = UIsendCmdclient.GetStream();
                    //---read incoming stream---
                    int bytesRead = nwStream.Read(UIsendCmdbuffer, 0, UIsendCmdbuffer.Length);
                    //---convert the data received into a string---
                    if (bytesRead == 0)
                    {
                        isReceiving3 = false;
                        UIsendCmdclient.Client.Disconnect(true);
                        UIsendCmdTcpListenerThread.Abort();
                        UIsendCmdlistener.Stop();
                        errorClientUIsendCmdDiscEvent?.Invoke();
                        return;
                    }
                    string dataReceived = Encoding.ASCII.GetString(UIsendCmdbuffer, 0, bytesRead);
                    //---write back the text to the client---
                    ret = RosFeedbackUIsendCmdPcsData(dataReceived);
                    ((IList)UIsendCmdbuffer).Clear();
                    isReceiving3 = false;
                }
                //listener.Stop();
            }
            catch (Exception ex)
            {
                isReceiving3 = false;
            }
        }

        private Thread tcpListenerThread;
        private Thread SendCmdTcpListenerThread;
        private Thread UIsendCmdTcpListenerThread;
        public void reStartListenerThread()
        {
            tcpListenerThread = new Thread(new ThreadStart(Connect));
            tcpListenerThread.IsBackground = true;
            tcpListenerThread.Start();
        }
        public void reStartCmdListenerThread()
        {
            SendCmdTcpListenerThread = new Thread(new ThreadStart(ConnectCmdListner));
            SendCmdTcpListenerThread.IsBackground = true;
            SendCmdTcpListenerThread.Start();
        }
        public void reStartUIsendCmdListenerThread()
        {
            UIsendCmdTcpListenerThread = new Thread(new ThreadStart(ConnectUIsendCmdListener));
            UIsendCmdTcpListenerThread.IsBackground = true;
            UIsendCmdTcpListenerThread.Start();
        }

        public Tcpip_Server(string IP, int RefreshDataPort, int SendCmdPort)
        {
            _IP = IP;
            _RefreshDataPort = RefreshDataPort;
            _SendCmdPort = SendCmdPort;

            tcpListenerThread = new Thread(new ThreadStart(Connect));
            tcpListenerThread.IsBackground = true;
            tcpListenerThread.Start();

            //SendCmdTcpListenerThread = new Thread(new ThreadStart(ConnectCmdListner));
            //SendCmdTcpListenerThread.IsBackground = true;
            //SendCmdTcpListenerThread.Start();

            UIsendCmdTcpListenerThread = new Thread(new ThreadStart(ConnectUIsendCmdListener));
            UIsendCmdTcpListenerThread.IsBackground = true;
            UIsendCmdTcpListenerThread.Start();

            tmr_sendingAxisDataToRos = new System.Timers.Timer();
            tmr_sendingAxisDataToRos.Elapsed += Tmr_sendingAxisDataToRos_Elapsed; ;
            tmr_sendingAxisDataToRos.Interval = 5;

        }
        private Stopwatch _sw = new Stopwatch();
        private int SendingAxisData()
        {
            int rtn = -1;
            byte[] data;
            NetworkStream stream = refreshDataclient.GetStream();
            try
            {
                string sendMessage = "";
                sendMessage = "Read";
                data = System.Text.Encoding.ASCII.GetBytes(sendMessage);
                // Send the message to the connected TcpServer.
                stream.Write(data, 0, data.Length);
                rtn = 0;
                return rtn;
            }
            catch (Exception ex)
            {
                Debug.Print(ex.Message);
                return -1;
                //throw;
            }
        }
        private int RosFeedbackUIsendCmdPcsData(string receiveData)
        {
            int rtn = -1;
            try
            {
                if ((receiveData == "Ready") || (receiveData == "Ready\n"))
                    rtn = 0;
                return rtn;
            }
            catch (Exception)
            {
                return -1;
                //throw;
            }
        }
        private int RosFeedbackPcsData(string receiveData)
        {
            int rtn = -1;
            try
            {
                monitorAxisDataEvent?.Invoke(receiveData);

                rtn = 0;
                return rtn;
            }
            catch (Exception ex)
            {
                Console.WriteLine(string.Format("[ERR] {0}",ex.Message));
                return -1;
                //throw;
            }
        }

        public static int calculateCount;
        private int RosFeedbackCmdData(string sendingData)
        {
            int rtn = -1;
            try
            {

                if (sendingData.Contains("OutOfLimit") || sendingData.Contains("ErrPose"))
                {
                    string sendMessage2 = "";
                    sendMessage2 = "OutOfLimit";
                    data = System.Text.Encoding.ASCII.GetBytes(sendMessage2);
                    stream = sendCmdclient.GetStream();
                    stream.Write(data, 0, data.Length);
                    //MessageBox.Show("Over Limit");
                    return rtn;
                }
                rtn = 0;
                return rtn;
            }
            catch (Exception)
            {
                return -1;
                //throw;
            }
        }

        public NetworkStream stream;
        public void SendCmd(string sendData)
        {
            try
            {
                stream = UIsendCmdclient.GetStream();
                byte[] data;

                data = Encoding.ASCII.GetBytes(sendData);
                //Send the message to the connected TcpServer.
                stream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                Application.DoEvents();
                //throw;
            }
        }
        byte[] data;
        private string[] AnalysisRosData(string sendingData)
        {
            string[] rtn = sendingData.Split(';');
            if (sendingData.Contains("(") && sendingData.Contains(")"))
            {
                for (int i = 0; i < rtn.Length; i++)
                { rtn[i] = rtn[i].Replace("(", "").Replace(")", ""); }
            }
            else if (sendingData.Contains("[") && sendingData.Contains("]"))
            {
                for (int i = 0; i < rtn.Length; i++)
                { rtn[i] = rtn[i].Replace("[", "").Replace("]", ""); }
            }
            return rtn;
        }

        public void requestRosStopCmd()
        {
            try
            {
                string sendMessage = "";
                sendMessage = "Stop";
                data = System.Text.Encoding.ASCII.GetBytes(sendMessage);
                //Send the message to the connected TcpServer.
                stream = sendCmdclient.GetStream();
                stream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
            }
        }
        public void disconnectAllTcp()
        {
            if (refreshDataclient.Client.Connected)
            {
                refreshDataclient.Client.Disconnect(true);
                tcpListenerThread.Abort();
                refreshDatalistener.Stop();
                tmr_sendingAxisDataToRos.Enabled = false;
            }
            if (sendCmdclient.Client.Connected)
            {
                sendCmdclient.Client.Disconnect(true);
                SendCmdTcpListenerThread.Abort();
                sendCmdlistener.Stop();
            }
            if (UIsendCmdclient.Client.Connected)
            {
                UIsendCmdclient.Client.Disconnect(true);
                UIsendCmdTcpListenerThread.Abort();
                UIsendCmdlistener.Stop();
            }
        }
        public static double[] analysisCmd(string cmdStr)
        {
            try
            {
                string[] tmpStr1 = cmdStr.Split('\n');
                int indexStart = tmpStr1[0].IndexOf("s_") + 2;
                int indexEnd = tmpStr1[0].IndexOf("_e");
                string tmpStr2 = tmpStr1[0].Substring(indexStart, indexEnd - indexStart);
                tmpStr2 = tmpStr2.Replace(';',',');
                string[] tmpStr = tmpStr2.Split(',');
                //return tmpStr;
                double[] rtn = new double[6]; //扣掉8個DO位置
                for (int i = tmpStr.Length  - 6; i < tmpStr.Length; i++)
                {
                    switch (i)
                    {
                        case 54:
                            rtn[0] = Math.Round((double.Parse(tmpStr[i])) * 1000, 7);
                            break;
                        case 55:
                            rtn[1] = Math.Round((double.Parse(tmpStr[i])) * 1000, 7);
                            break;
                        case 56:
                            rtn[2] = Math.Round((double.Parse(tmpStr[i])) * 1000, 7);
                            break;
                        case 57: rtn[3] = Math.Round((double.Parse(tmpStr[i])) * 180 / Math.PI, 7); break; //ROS回傳的單位為公尺，UI顯示為mm故乘上1000
                        case 58: rtn[4] = Math.Round((double.Parse(tmpStr[i])) * 180 / Math.PI, 7); break; //ROS回傳的單位為公尺，UI顯示為mm故乘上1000
                        case 59: rtn[5] = Math.Round((double.Parse(tmpStr[i])) * 180 / Math.PI, 7); break; //ROS回傳的單位為公尺，UI顯示為mm故乘上1000
                    }
                }
                return rtn;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Application.DoEvents();
                throw;
            }
        }
    }
}
